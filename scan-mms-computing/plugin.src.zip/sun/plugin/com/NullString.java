package sun.plugin.com;

class NullString
{
}

/* Location:           /home/wahid/Downloads/webscanning/plugin.jar
 * Qualified Name:     sun.plugin.com.NullString
 * JD-Core Version:    0.6.2
 */