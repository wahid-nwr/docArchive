package sun.plugin.javascript;

import netscape.javascript.JSObject;

public abstract interface JSContext
{
  public abstract JSObject getJSObject();
}

/* Location:           /home/wahid/Downloads/webscanning/plugin.jar
 * Qualified Name:     sun.plugin.javascript.JSContext
 * JD-Core Version:    0.6.2
 */