package sun.plugin.javascript.navig;

public class Anchor extends JSObject
{
  protected Anchor(int paramInt, String paramString)
  {
    super(paramInt, paramString);
  }
}

/* Location:           /home/wahid/Downloads/webscanning/plugin.jar
 * Qualified Name:     sun.plugin.javascript.navig.Anchor
 * JD-Core Version:    0.6.2
 */