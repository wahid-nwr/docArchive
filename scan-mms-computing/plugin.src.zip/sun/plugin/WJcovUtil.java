package sun.plugin;

public class WJcovUtil
{
  public static native boolean dumpJcovData();
}

/* Location:           /home/wahid/Downloads/webscanning/plugin.jar
 * Qualified Name:     sun.plugin.WJcovUtil
 * JD-Core Version:    0.6.2
 */