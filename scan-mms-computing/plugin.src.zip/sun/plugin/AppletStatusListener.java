package sun.plugin;

public abstract interface AppletStatusListener
{
  public abstract void statusChanged(int paramInt);
}

/* Location:           /home/wahid/Downloads/webscanning/plugin.jar
 * Qualified Name:     sun.plugin.AppletStatusListener
 * JD-Core Version:    0.6.2
 */