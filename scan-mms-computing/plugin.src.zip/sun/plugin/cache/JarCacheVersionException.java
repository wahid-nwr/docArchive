package sun.plugin.cache;

public class JarCacheVersionException extends Exception
{
  JarCacheVersionException()
  {
  }

  JarCacheVersionException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /home/wahid/Downloads/webscanning/plugin.jar
 * Qualified Name:     sun.plugin.cache.JarCacheVersionException
 * JD-Core Version:    0.6.2
 */