package sun.plugin.dom.exception;

import org.w3c.dom.DOMException;

public class HierarchyRequestException extends DOMException
{
  public HierarchyRequestException(String paramString)
  {
    super((short)3, paramString);
  }
}

/* Location:           /home/wahid/Downloads/webscanning/plugin.jar
 * Qualified Name:     sun.plugin.dom.exception.HierarchyRequestException
 * JD-Core Version:    0.6.2
 */