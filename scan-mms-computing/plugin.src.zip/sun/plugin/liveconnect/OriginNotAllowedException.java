package sun.plugin.liveconnect;

public class OriginNotAllowedException extends Exception
{
  OriginNotAllowedException()
  {
  }

  OriginNotAllowedException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /home/wahid/Downloads/webscanning/plugin.jar
 * Qualified Name:     sun.plugin.liveconnect.OriginNotAllowedException
 * JD-Core Version:    0.6.2
 */