package netscape.security;

public class ForbiddenTargetException extends RuntimeException
{
  public ForbiddenTargetException()
  {
  }

  public ForbiddenTargetException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /home/wahid/Downloads/webscanning/plugin.jar
 * Qualified Name:     netscape.security.ForbiddenTargetException
 * JD-Core Version:    0.6.2
 */