/*     */ package ij.plugin;
/*     */ 
/*     */ class Timer2
/*     */ {
/* 131 */   int j = 0;
/* 132 */   static int k = 0;
/*     */ 
/* 134 */   public int getJ() { return this.j; } 
/* 135 */   public final int getJFinal() { return this.j; } 
/* 136 */   public static int getJClass() { return k; }
/*     */ 
/*     */ }

/* Location:           /home/wahid/Downloads/webscanning/ij.jar
 * Qualified Name:     ij.plugin.Timer2
 * JD-Core Version:    0.6.2
 */