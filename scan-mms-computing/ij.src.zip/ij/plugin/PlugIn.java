package ij.plugin;

public abstract interface PlugIn
{
  public abstract void run(String paramString);
}

/* Location:           /home/wahid/Downloads/webscanning/ij.jar
 * Qualified Name:     ij.plugin.PlugIn
 * JD-Core Version:    0.6.2
 */