/*    */ package ij.plugin;
/*    */ 
/*    */ import ij.text.TextWindow;
/*    */ 
/*    */ public class TextFileReader
/*    */   implements PlugIn
/*    */ {
/*    */   public void run(String arg)
/*    */   {
/* 15 */     new TextWindow(arg, 400, 450);
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/webscanning/ij.jar
 * Qualified Name:     ij.plugin.TextFileReader
 * JD-Core Version:    0.6.2
 */