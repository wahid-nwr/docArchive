package ij.macro;

class ReturnException extends RuntimeException
{
  double value;
  String str;
  Variable[] array;
  int arraySize;
}

/* Location:           /home/wahid/Downloads/webscanning/ij.jar
 * Qualified Name:     ij.macro.ReturnException
 * JD-Core Version:    0.6.2
 */