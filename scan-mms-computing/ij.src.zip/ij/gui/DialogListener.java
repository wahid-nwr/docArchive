package ij.gui;

import java.awt.AWTEvent;

public abstract interface DialogListener
{
  public abstract boolean dialogItemChanged(GenericDialog paramGenericDialog, AWTEvent paramAWTEvent);
}

/* Location:           /home/wahid/Downloads/webscanning/ij.jar
 * Qualified Name:     ij.gui.DialogListener
 * JD-Core Version:    0.6.2
 */