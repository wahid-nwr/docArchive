// INTERNAL ERROR //

/* Location:           /home/wahid/Downloads/webscanning/ij.jar
 * Qualified Name:     ij.gui.PlotWindow
 * JD-Core Version:    0.6.2
 */