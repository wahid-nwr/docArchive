package ij;

public abstract interface CommandListener
{
  public abstract String commandExecuting(String paramString);
}

/* Location:           /home/wahid/Downloads/webscanning/ij.jar
 * Qualified Name:     ij.CommandListener
 * JD-Core Version:    0.6.2
 */