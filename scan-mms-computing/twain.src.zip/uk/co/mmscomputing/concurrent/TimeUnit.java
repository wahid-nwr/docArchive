/*   */ package uk.co.mmscomputing.concurrent;
/*   */ 
/*   */ public class TimeUnit
/*   */ {
/* 4 */   public static final TimeUnit MILLISECONDS = new TimeUnit();
/*   */ }

/* Location:           /home/wahid/Downloads/webscanning/twain.jar
 * Qualified Name:     uk.co.mmscomputing.concurrent.TimeUnit
 * JD-Core Version:    0.6.2
 */