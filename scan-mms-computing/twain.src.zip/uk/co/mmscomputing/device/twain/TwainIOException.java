/*   */ package uk.co.mmscomputing.device.twain;
/*   */ 
/*   */ import uk.co.mmscomputing.device.scanner.ScannerIOException;
/*   */ 
/*   */ public class TwainIOException extends ScannerIOException
/*   */   implements TwainConstants
/*   */ {
/*   */   public TwainIOException(String paramString)
/*   */   {
/* 7 */     super(paramString);
/*   */   }
/*   */ }

/* Location:           /home/wahid/Downloads/webscanning/twain.jar
 * Qualified Name:     uk.co.mmscomputing.device.twain.TwainIOException
 * JD-Core Version:    0.6.2
 */