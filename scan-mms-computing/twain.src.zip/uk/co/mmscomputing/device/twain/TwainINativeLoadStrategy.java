package uk.co.mmscomputing.device.twain;

public abstract interface TwainINativeLoadStrategy
{
  public abstract boolean load(Class paramClass, String paramString);
}

/* Location:           /home/wahid/Downloads/webscanning/twain.jar
 * Qualified Name:     uk.co.mmscomputing.device.twain.TwainINativeLoadStrategy
 * JD-Core Version:    0.6.2
 */