/*   */ package uk.co.mmscomputing.device.twain;
/*   */ 
/*   */ public class TwainUserCancelException extends TwainIOException
/*   */ {
/*   */   public TwainUserCancelException()
/*   */   {
/* 5 */     super("User cancelled next scan.");
/*   */   }
/*   */ }

/* Location:           /home/wahid/Downloads/webscanning/twain.jar
 * Qualified Name:     uk.co.mmscomputing.device.twain.TwainUserCancelException
 * JD-Core Version:    0.6.2
 */