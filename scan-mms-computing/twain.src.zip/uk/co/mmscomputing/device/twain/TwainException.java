/*   */ package uk.co.mmscomputing.device.twain;
/*   */ 
/*   */ public class TwainException extends TwainIOException
/*   */ {
/*   */   public TwainException(String paramString)
/*   */   {
/* 5 */     super(paramString);
/*   */   }
/*   */ }

/* Location:           /home/wahid/Downloads/webscanning/twain.jar
 * Qualified Name:     uk.co.mmscomputing.device.twain.TwainException
 * JD-Core Version:    0.6.2
 */