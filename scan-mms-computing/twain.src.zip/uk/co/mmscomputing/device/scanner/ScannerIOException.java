/*   */ package uk.co.mmscomputing.device.scanner;
/*   */ 
/*   */ import java.io.IOException;
/*   */ 
/*   */ public class ScannerIOException extends IOException
/*   */ {
/*   */   public ScannerIOException(String paramString)
/*   */   {
/* 8 */     super(paramString);
/*   */   }
/*   */ }

/* Location:           /home/wahid/Downloads/webscanning/twain.jar
 * Qualified Name:     uk.co.mmscomputing.device.scanner.ScannerIOException
 * JD-Core Version:    0.6.2
 */