package uk.co.mmscomputing.util.metadata;

public abstract interface MetadataListener
{
  public abstract void update(Object paramObject, Metadata paramMetadata);
}

/* Location:           /home/wahid/Downloads/webscanning/twain.jar
 * Qualified Name:     uk.co.mmscomputing.util.metadata.MetadataListener
 * JD-Core Version:    0.6.2
 */