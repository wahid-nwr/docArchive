package leadtools.sane.server;

public abstract interface ISaneScanningService extends ISaneService, IImageProcessingService, ICommandService
{
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.sane.server.jar
 * Qualified Name:     leadtools.sane.server.ISaneScanningService
 * JD-Core Version:    0.6.2
 */