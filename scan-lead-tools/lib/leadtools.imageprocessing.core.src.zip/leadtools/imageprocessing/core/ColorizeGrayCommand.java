/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterColor;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ import leadtools.ltkrn;
/*    */ 
/*    */ public class ColorizeGrayCommand extends RasterCommand
/*    */ {
/*    */   private RasterImage _destinationImage;
/*    */   private ColorizeGrayCommandData[] _grayColors;
/*    */ 
/*    */   public ColorizeGrayCommand()
/*    */   {
/* 14 */     this._destinationImage = null;
/* 15 */     this._grayColors = null;
/*    */   }
/*    */ 
/*    */   public ColorizeGrayCommand(ColorizeGrayCommandData[] grayColors) {
/* 19 */     this._destinationImage = null;
/* 20 */     this._grayColors = grayColors;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 25 */     return "Colorize Gray";
/*    */   }
/*    */ 
/*    */   public ColorizeGrayCommandData[] getGrayColors() {
/* 29 */     return this._grayColors;
/*    */   }
/*    */ 
/*    */   public void setGrayColors(ColorizeGrayCommandData[] value) {
/* 33 */     this._grayColors = value;
/*    */   }
/*    */ 
/*    */   public RasterImage getDestinationImage() {
/* 37 */     return this._destinationImage;
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 42 */     int ret = L_ERROR.SUCCESS.getValue();
/* 43 */     LTGrayColorStruct[] gryClrs = null;
/* 44 */     this._destinationImage = null;
/* 45 */     long destBitmap = ltkrn.AllocBitmapHandle();
/*    */     try
/*    */     {
/*    */       int x;
/* 48 */       if (this._grayColors != null)
/*    */       {
/* 50 */         gryClrs = new LTGrayColorStruct[this._grayColors.length];
/* 51 */         for (x = 0; x < gryClrs.length; x++)
/*    */         {
/* 53 */           gryClrs[x] = new LTGrayColorStruct();
/* 54 */           gryClrs[x]._rgbBlue = this._grayColors[x].getColor().getB();
/* 55 */           gryClrs[x]._rgbGreen = this._grayColors[x].getColor().getG();
/* 56 */           gryClrs[x]._rgbRed = this._grayColors[x].getColor().getR();
/* 57 */           gryClrs[x]._uThreshold = this._grayColors[x].getThreshold();
/*    */         }
/* 59 */         ret = ltimgcor.ColorizeGrayBitmap(destBitmap, bitmap, gryClrs, gryClrs.length, 0);
/*    */       }
/*    */       else
/*    */       {
/* 63 */         ret = ltimgcor.ColorizeGrayBitmap(destBitmap, bitmap, null, 16, 0);
/*    */       }
/*    */ 
/* 66 */       if (ret == L_ERROR.SUCCESS.getValue())
/*    */       {
/* 68 */         this._destinationImage = RasterImage.createFromBitmapHandle(destBitmap);
/*    */       }
/*    */ 
/* 71 */       return ret;
/*    */     }
/*    */     finally {
/* 74 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/* 75 */       ltkrn.FreeBitmapHandle(destBitmap);
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.ColorizeGrayCommand
 * JD-Core Version:    0.6.2
 */