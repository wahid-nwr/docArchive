/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterByteOrder;
/*    */ import leadtools.RasterColor16;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class WindowLevelExtCommand extends RasterCommand
/*    */ {
/*    */   private RasterColor16[] _lookupTable;
/*    */   private int _lowBit;
/*    */   private int _highBit;
/*    */   private RasterByteOrder _order;
/*    */ 
/*    */   public WindowLevelExtCommand()
/*    */   {
/* 17 */     this._lookupTable = new RasterColor16[1];
/* 18 */     this._lowBit = 0;
/* 19 */     this._highBit = 15;
/* 20 */     this._order = RasterByteOrder.BGR;
/*    */   }
/*    */ 
/*    */   public WindowLevelExtCommand(int lowBit, int highBit, RasterColor16[] lookupTable, RasterByteOrder order) {
/* 24 */     this._lookupTable = lookupTable;
/* 25 */     this._lowBit = lowBit;
/* 26 */     this._highBit = highBit;
/* 27 */     this._order = order;
/*    */   }
/*    */ 
/*    */   public int getLowBit() {
/* 31 */     return this._lowBit;
/*    */   }
/*    */   public void setLowBit(int value) {
/* 34 */     this._lowBit = value;
/*    */   }
/*    */   public int getHighBit() {
/* 37 */     return this._highBit;
/*    */   }
/*    */   public void setHighBit(int value) {
/* 40 */     this._highBit = value;
/*    */   }
/*    */ 
/*    */   public RasterColor16[] getLookupTable() {
/* 44 */     return this._lookupTable;
/*    */   }
/*    */   public void setLookupTable(RasterColor16[] value) {
/* 47 */     this._lookupTable = value;
/*    */   }
/*    */ 
/*    */   public RasterByteOrder getOrder() {
/* 51 */     return this._order;
/*    */   }
/*    */   public void setOrder(RasterByteOrder value) {
/* 54 */     this._order = value;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 59 */     return "WindowLevelExt";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 64 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 67 */       int length = this._lookupTable != null ? this._lookupTable.length : 0;
/*    */       short[] lutR;
/* 69 */       if (length != 0) {
/* 70 */         lutR = null;
/* 71 */         short[] lutG = null;
/* 72 */         short[] lutB = null;
/*    */ 
/* 74 */         lutR = new short[length];
/* 75 */         lutG = new short[length];
/* 76 */         lutB = new short[length];
/*    */ 
/* 78 */         for (int i = 0; i < length; i++) {
/* 79 */           lutR[i] = this._lookupTable[i].getR();
/* 80 */           lutG[i] = this._lookupTable[i].getG();
/* 81 */           lutB[i] = this._lookupTable[i].getB();
/*    */         }
/*    */ 
/* 84 */         ret = ltimgcor.WindowLevelBitmapExt(bitmap, this._lowBit, this._highBit, lutR, lutG, lutB, length, this._order.getValue(), 0);
/*    */       }
/*    */       else {
/* 87 */         ret = ltimgcor.WindowLevelBitmapExt(bitmap, this._lowBit, this._highBit, null, null, null, 0, this._order.getValue(), 0);
/*    */       }
/* 89 */       return ret;
/*    */     }
/*    */     finally {
/* 92 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.WindowLevelExtCommand
 * JD-Core Version:    0.6.2
 */