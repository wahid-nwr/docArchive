/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum LineRemoveCommandFlags
/*    */ {
/*  5 */   NONE(0), 
/*  6 */   USE_DPI(1), 
/*  7 */   SINGLE_REGION(2), 
/*  8 */   LEAD_REGION(4), 
/*  9 */   CALLBACK_REGION(8), 
/* 10 */   IMAGE_UNCHANGED(16), 
/* 11 */   REMOVE_ENTIRE(512), 
/* 12 */   USE_GAP(1024), 
/* 13 */   USE_VARIANCE(2048);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, LineRemoveCommandFlags> mappings;
/*    */ 
/* 19 */   private static HashMap<Integer, LineRemoveCommandFlags> getMappings() { if (mappings == null)
/*    */     {
/* 21 */       synchronized (LineRemoveCommandFlags.class)
/*    */       {
/* 23 */         if (mappings == null)
/*    */         {
/* 25 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 29 */     return mappings;
/*    */   }
/*    */ 
/*    */   private LineRemoveCommandFlags(int value)
/*    */   {
/* 34 */     this.intValue = value;
/* 35 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue()
/*    */   {
/* 40 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static LineRemoveCommandFlags forValue(int value)
/*    */   {
/* 45 */     return (LineRemoveCommandFlags)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.LineRemoveCommandFlags
 * JD-Core Version:    0.6.2
 */