/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ 
/*    */ public enum RemoveStatus
/*    */ {
/*  4 */   REMOVE(1), 
/*  5 */   NO_REMOVE(2), 
/*  6 */   CANCEL(L_ERROR.ERROR_USER_ABORT.getValue());
/*    */ 
/*    */   private int intValue;
/*    */ 
/*    */   private RemoveStatus(int value) {
/* 11 */     this.intValue = value;
/*    */   }
/*    */ 
/*    */   public int getValue()
/*    */   {
/* 16 */     return this.intValue;
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.RemoveStatus
 * JD-Core Version:    0.6.2
 */