/*     */ package leadtools.imageprocessing.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import leadtools.L_ERROR;
/*     */ import leadtools.RasterImage;
/*     */ import leadtools.RasterImageChangedFlags;
/*     */ import leadtools.RasterRegion;
/*     */ import leadtools.imageprocessing.RasterCommand;
/*     */ import leadtools.ltkrn;
/*     */ 
/*     */ public class LineRemoveCommand extends RasterCommand
/*     */ {
/*     */   private int _flags;
/*     */   private int _minimumLineLength;
/*     */   private int _maximumLineWidth;
/*     */   private int _wall;
/*     */   private int _maximumWallPercent;
/*     */   private int _gapLength;
/*     */   private int _variance;
/*     */   private LineRemoveCommandType _type;
/*     */   private RasterRegion _region;
/*     */   private RasterImage _imageRegion;
/*     */   private RasterImage _image;
/*     */   private ArrayList<LineRemoveCommandListener> _lineRemove;
/*     */ 
/*     */   public void addLineRemoveCommandListener(LineRemoveCommandListener listener)
/*     */   {
/*  28 */     this._lineRemove.add(listener);
/*     */   }
/*     */ 
/*     */   public void removeLineRemoveCommandListener(LineRemoveCommandListener listener) {
/*  32 */     this._lineRemove.remove(listener);
/*     */   }
/*     */ 
/*     */   public int getFlags() {
/*  36 */     return this._flags;
/*     */   }
/*     */ 
/*     */   public void setFlags(int value) {
/*  40 */     this._flags = value;
/*     */   }
/*     */ 
/*     */   public int getMinimumLineLength() {
/*  44 */     return this._minimumLineLength;
/*     */   }
/*     */ 
/*     */   public void setMinimumLineLength(int value) {
/*  48 */     this._minimumLineLength = value;
/*     */   }
/*     */ 
/*     */   public int getMaximumLineWidth() {
/*  52 */     return this._maximumLineWidth;
/*     */   }
/*     */ 
/*     */   public void setMaximumLineWidth(int value) {
/*  56 */     this._maximumLineWidth = value;
/*     */   }
/*     */ 
/*     */   public int getWall() {
/*  60 */     return this._wall;
/*     */   }
/*     */ 
/*     */   public void setWall(int value) {
/*  64 */     this._wall = value;
/*     */   }
/*     */ 
/*     */   public int getMaximumWallPercent() {
/*  68 */     return this._maximumWallPercent;
/*     */   }
/*     */ 
/*     */   public void setMaximumWallPercent(int value) {
/*  72 */     this._maximumWallPercent = value;
/*     */   }
/*     */ 
/*     */   public int getGapLength() {
/*  76 */     return this._gapLength;
/*     */   }
/*     */ 
/*     */   public void setGapLength(int value) {
/*  80 */     this._gapLength = value;
/*     */   }
/*     */ 
/*     */   public int getVariance() {
/*  84 */     return this._variance;
/*     */   }
/*     */ 
/*     */   public void setVariance(int value) {
/*  88 */     this._variance = value;
/*     */   }
/*     */ 
/*     */   public LineRemoveCommandType getType() {
/*  92 */     return this._type;
/*     */   }
/*     */ 
/*     */   public void setType(LineRemoveCommandType value) {
/*  96 */     this._type = value;
/*     */   }
/*     */ 
/*     */   public RasterRegion getRegion() {
/* 100 */     return this._region;
/*     */   }
/*     */ 
/*     */   public RasterImage getImageRegion() {
/* 104 */     return this._imageRegion;
/*     */   }
/*     */ 
/*     */   public LineRemoveCommand() {
/* 108 */     this._flags = (LineRemoveCommandFlags.USE_GAP.getValue() | LineRemoveCommandFlags.USE_VARIANCE.getValue());
/* 109 */     this._minimumLineLength = 400;
/* 110 */     this._maximumLineWidth = 9;
/* 111 */     this._wall = 15;
/* 112 */     this._maximumWallPercent = 10;
/* 113 */     this._gapLength = 3;
/* 114 */     this._variance = 3;
/* 115 */     this._type = LineRemoveCommandType.HORIZONTAL;
/* 116 */     this._region = null;
/* 117 */     this._imageRegion = null;
/* 118 */     this._lineRemove = new ArrayList();
/*     */   }
/*     */ 
/*     */   public LineRemoveCommand(int flags, int minimumLineLength, int maximumLineWidth, int wall, int maximumWallPercent, int gapLength, int variance, LineRemoveCommandType type) {
/* 122 */     this._flags = flags;
/* 123 */     this._minimumLineLength = minimumLineLength;
/* 124 */     this._maximumLineWidth = maximumLineWidth;
/* 125 */     this._wall = wall;
/* 126 */     this._maximumWallPercent = maximumWallPercent;
/* 127 */     this._gapLength = gapLength;
/* 128 */     this._variance = variance;
/* 129 */     this._type = type;
/* 130 */     this._lineRemove = new ArrayList();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 135 */     return "Line Remove";
/*     */   }
/*     */ 
/*     */   private final int DoCallback(int leadRegion, int iStartRow, int iStartCol, int iLength)
/*     */   {
/* 141 */     int ret = L_ERROR.SUCCESS.getValue();
/*     */ 
/* 143 */     Iterator i$ = this._lineRemove.iterator(); if (i$.hasNext()) { LineRemoveCommandListener listener = (LineRemoveCommandListener)i$.next();
/* 144 */       LineRemoveCommandEvent args = new LineRemoveCommandEvent(this, this._image, leadRegion != 0 ? new RasterRegion(leadRegion, false) : null, iStartRow, iStartCol, iLength);
/* 145 */       listener.onLineRemoveEvent(args);
/* 146 */       return args.getStatus().getValue();
/*     */     }
/*     */ 
/* 149 */     return ret;
/*     */   }
/*     */ 
/*     */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*     */   {
/* 154 */     int ret = L_ERROR.SUCCESS.getValue();
/* 155 */     long regionImage = 0L;
/*     */     try
/*     */     {
/* 158 */       this._image = image;
/* 159 */       LineRemoveStruct lineRemove = new LineRemoveStruct();
/*     */ 
/* 161 */       lineRemove._uFlags = this._flags;
/* 162 */       lineRemove._iMinLineLength = this._minimumLineLength;
/* 163 */       lineRemove._iMaxLineWidth = this._maximumLineWidth;
/* 164 */       lineRemove._iWall = this._wall;
/* 165 */       lineRemove._iMaxWallPercent = this._maximumWallPercent;
/* 166 */       lineRemove._iGapLength = this._gapLength;
/* 167 */       lineRemove._iVariance = this._variance;
/* 168 */       lineRemove._uRemoveFlags = this._type.getValue();
/*     */ 
/* 171 */       if (((this._flags & LineRemoveCommandFlags.SINGLE_REGION.getValue()) == LineRemoveCommandFlags.SINGLE_REGION.getValue()) && ((this._flags & LineRemoveCommandFlags.LEAD_REGION.getValue()) == LineRemoveCommandFlags.LEAD_REGION.getValue()))
/*     */       {
/* 174 */         regionImage = ltkrn.AllocBitmapHandle();
/* 175 */         lineRemove._bitmapRegion = regionImage;
/*     */       }
/*     */ 
/* 178 */       ret = ltimgcor.LineRemoveBitmap(bitmap, lineRemove, this._lineRemove.size() > 0 ? this : null, 0);
/* 179 */       if (ret == L_ERROR.SUCCESS.getValue()) {
/* 180 */         this._imageRegion = null;
/* 181 */         this._region = null;
/*     */ 
/* 184 */         if (((this._flags & LineRemoveCommandFlags.SINGLE_REGION.getValue()) == LineRemoveCommandFlags.SINGLE_REGION.getValue()) && ((this._flags & LineRemoveCommandFlags.LEAD_REGION.getValue()) == LineRemoveCommandFlags.LEAD_REGION.getValue()))
/*     */         {
/* 186 */           this._imageRegion = RasterImage.createFromBitmapHandle(regionImage);
/*     */         }
/* 189 */         else if (((this._flags & LineRemoveCommandFlags.SINGLE_REGION.getValue()) == LineRemoveCommandFlags.SINGLE_REGION.getValue()) && 
/* 190 */           (lineRemove._leadregion != 0L)) {
/* 191 */           this._region = new RasterRegion(lineRemove._leadregion, true);
/* 192 */           ltkrn.DeleteLeadRgn(lineRemove._leadregion);
/*     */         }
/*     */       }
/*     */ 
/* 196 */       return ret;
/*     */     }
/*     */     finally {
/* 199 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/* 200 */       if (regionImage != 0L)
/* 201 */         ltkrn.FreeBitmapHandle(regionImage);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.LineRemoveCommand
 * JD-Core Version:    0.6.2
 */