/*     */ package leadtools.imageprocessing.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import leadtools.L_ERROR;
/*     */ import leadtools.LeadRect;
/*     */ import leadtools.RasterImage;
/*     */ import leadtools.RasterImageChangedFlags;
/*     */ import leadtools.imageprocessing.RasterCommand;
/*     */ import leadtools.ltkrn;
/*     */ 
/*     */ public class AutoZoningCommand extends RasterCommand
/*     */ {
/*     */   private List<LeadZone> _zones;
/*     */   private int _options;
/*     */   private DitheringType _ditheringtype;
/*     */   private DotMatrixType _dotmatrixtype;
/*     */   private List<LeadRect> _underlines;
/*     */   private List<LeadRect> _checkboxes;
/*     */   private List<LeadRect> _strikelines;
/*     */   private RasterImage _tableimage;
/*     */ 
/*     */   public List<LeadRect> getUnderLines()
/*     */   {
/*  26 */     return this._underlines;
/*     */   }
/*     */ 
/*     */   public List<LeadRect> getCheckBoxes() {
/*  30 */     return this._checkboxes;
/*     */   }
/*     */ 
/*     */   public List<LeadRect> getStrikeLines() {
/*  34 */     return this._strikelines;
/*     */   }
/*     */ 
/*     */   public RasterImage getTableImage() {
/*  38 */     return this._tableimage;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  43 */     return "Auto Zoning";
/*     */   }
/*     */ 
/*     */   boolean isRotated90(RasterImage image) {
/*  47 */     boolean[] rotated90 = new boolean[1];
/*  48 */     ltimgcor.BasicOrientation(image.getBitmapList(), rotated90);
/*  49 */     return rotated90[0];
/*     */   }
/*     */ 
/*     */   public AutoZoningCommand()
/*     */   {
/*  54 */     this._zones = new ArrayList();
/*  55 */     this._tableimage = null;
/*  56 */     this._underlines = new ArrayList();
/*  57 */     this._checkboxes = new ArrayList();
/*  58 */     this._strikelines = new ArrayList();
/*  59 */     this._options = (AutoZoningOptions.DETECT_ALL.getValue() | AutoZoningOptions.DONT_ALLOW_OVERLAP.getValue() | AutoZoningOptions.DETECT_ACCURATE_ZONES.getValue());
/*  60 */     this._ditheringtype = DitheringType.UNDITHERED;
/*  61 */     this._dotmatrixtype = DotMatrixType.NONE;
/*     */   }
/*     */ 
/*     */   public AutoZoningCommand(int options)
/*     */   {
/*  66 */     this._zones = new ArrayList();
/*  67 */     this._tableimage = null;
/*  68 */     this._underlines = new ArrayList();
/*  69 */     this._checkboxes = new ArrayList();
/*  70 */     this._strikelines = new ArrayList();
/*  71 */     this._options = options;
/*  72 */     this._ditheringtype = DitheringType.UNDITHERED;
/*  73 */     this._dotmatrixtype = DotMatrixType.NONE;
/*     */   }
/*     */ 
/*     */   public DitheringType getDitherType()
/*     */   {
/*  78 */     return this._ditheringtype;
/*     */   }
/*     */ 
/*     */   public DotMatrixType getDotMatrix() {
/*  82 */     return this._dotmatrixtype;
/*     */   }
/*     */ 
/*     */   public List<LeadZone> getZones() {
/*  86 */     return this._zones;
/*     */   }
/*     */ 
/*     */   public int getOptions() {
/*  90 */     return this._options;
/*     */   }
/*     */ 
/*     */   public void setOptions(int value) {
/*  94 */     this._options = value;
/*     */   }
/*     */ 
/*     */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*     */   {
/*  99 */     int ret = L_ERROR.SUCCESS.getValue();
/* 100 */     long[] tableImage = new long[1];
/*     */ 
/* 102 */     tableImage[0] = ltkrn.AllocBitmapHandle();
/*     */     try
/*     */     {
/* 105 */       AutoZoneData autoZone = new AutoZoneData();
/* 106 */       autoZone._ditheringType = this._ditheringtype.getValue();
/* 107 */       autoZone._dotMatrixType = this._dotmatrixtype.getValue();
/*     */ 
/* 109 */       ret = ltimgcor.AutoZoneBitmap(bitmap, autoZone, this._options, tableImage);
/* 110 */       if (tableImage[0] != 0L) {
/* 111 */         this._tableimage = RasterImage.createFromBitmapHandle(tableImage[0]);
/*     */       }
/*     */ 
/* 114 */       if ((autoZone._undelineRects != null) && 
/* 115 */         (autoZone._underLinesType != null)) {
/* 116 */         for (int i = 0; i < autoZone._underLineCount; i++) {
/* 117 */           LeadRect rc = new LeadRect(autoZone._undelineRects[i].getLeft(), autoZone._undelineRects[i].getTop(), autoZone._undelineRects[i].getWidth(), autoZone._undelineRects[i].getHeight());
/*     */ 
/* 119 */           if (autoZone._underLinesType[i] == 1) {
/* 120 */             this._strikelines.add(rc);
/*     */           }
/*     */           else {
/* 123 */             this._underlines.add(rc);
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 129 */       if (autoZone._checkBoxesRects != null)
/*     */       {
/* 131 */         for (int i = 0; i < autoZone._checkBoxesCount; i++)
/*     */         {
/* 133 */           LeadRect rc = new LeadRect(autoZone._checkBoxesRects[i].getLeft(), autoZone._checkBoxesRects[i].getTop(), autoZone._checkBoxesRects[i].getWidth(), autoZone._checkBoxesRects[i].getHeight());
/* 134 */           this._checkboxes.add(rc);
/*     */         }
/*     */       }
/*     */ 
/* 138 */       this._ditheringtype = DitheringType.forValue(autoZone._ditheringType);
/* 139 */       this._dotmatrixtype = DotMatrixType.forValue(autoZone._dotMatrixType);
/*     */       int nRealIndex;
/* 141 */       if ((ret == L_ERROR.SUCCESS.getValue()) && (autoZone._zones != null))
/*     */       {
/* 144 */         for (int zoneIndex = 0; zoneIndex < autoZone._count; zoneIndex++)
/*     */         {
/* 146 */           for (nRealIndex = 0; nRealIndex < autoZone._count; nRealIndex++)
/*     */           {
/* 148 */             if (autoZone._zones[nRealIndex]._index == zoneIndex) {
/*     */               break;
/*     */             }
/*     */           }
/* 152 */           LeadZone zone = new LeadZone();
/* 153 */           zone.setBounds(new LeadRect(autoZone._zones[nRealIndex]._location.getLeft(), autoZone._zones[nRealIndex]._location.getTop(), autoZone._zones[nRealIndex]._location.getWidth(), autoZone._zones[nRealIndex]._location.getHeight()));
/*     */ 
/* 158 */           zone.setType(LeadZoneType.forValue(autoZone._zones[nRealIndex]._zoneType));
/*     */ 
/* 161 */           switch (zone.getType().getValue())
/*     */           {
/*     */           case 2:
/* 166 */             LeadZoneTableData tableData = new LeadZoneTableData();
/* 167 */             TABLEZONEDATA tableZone = autoZone._zones[nRealIndex]._tableZoneData;
/*     */ 
/* 169 */             tableData.setRows(tableZone._rows);
/* 170 */             tableData.setColumns(tableZone._columns);
/*     */ 
/* 172 */             int cellCount = tableZone._cellsCount;
/*     */ 
/* 174 */             for (int iii = 0; iii < cellCount; iii++) {
/* 175 */               LeadRect rc = new LeadRect(tableZone._cells[iii].getLeft(), tableZone._cells[iii].getTop(), tableZone._cells[iii].getWidth(), tableZone._cells[iii].getHeight());
/* 176 */               tableData.getCells().add(rc);
/*     */ 
/* 178 */               rc = new LeadRect(tableZone._BoundsToDraw[iii].getLeft(), tableZone._BoundsToDraw[iii].getTop(), tableZone._BoundsToDraw[iii].getRight(), tableZone._BoundsToDraw[iii].getBottom());
/*     */ 
/* 182 */               tableData.getBoundsToDraw().add(rc);
/*     */ 
/* 184 */               tableData.getCellTypes().add(LeadZoneType.forValue(tableZone._cellTypes[iii]));
/*     */ 
/* 186 */               tableData.getInsideCells().add(new ArrayList());
/*     */ 
/* 188 */               if ((tableZone._insideCellsNumber != null) && 
/* 189 */                 (tableZone._insideCellsNumber[iii] != 0)) {
/* 190 */                 for (int ix = 0; ix < tableZone._insideCellsNumber[iii]; ix++)
/*     */                 {
/* 192 */                   LeadRect rc1 = new LeadRect(tableZone._insideRects[iii][ix].getLeft(), tableZone._insideRects[iii][ix].getTop(), tableZone._insideRects[iii][ix].getWidth(), tableZone._insideRects[iii][ix].getHeight());
/*     */ 
/* 196 */                   ((ArrayList)tableData.getInsideCells().get(iii)).add(rc1);
/*     */                 }
/*     */ 
/*     */               }
/*     */ 
/*     */             }
/*     */ 
/* 203 */             zone.setTableData(tableData);
/*     */ 
/* 205 */             break;
/*     */           case 0:
/* 210 */             LeadZoneTextData textData = new LeadZoneTextData();
/* 211 */             TEXTZONEDATA textZone = autoZone._zones[nRealIndex]._textZoneData;
/*     */ 
/* 213 */             for (int iii = 0; iii < textZone._textLinesCount; iii++)
/*     */             {
/* 215 */               LeadRect rc = new LeadRect(textZone._textLines[iii].getLeft(), textZone._textLines[iii].getTop(), textZone._textLines[iii].getWidth(), textZone._textLines[iii].getHeight());
/* 216 */               textData.getTextLines().add(rc);
/*     */             }
/*     */ 
/* 220 */             zone.setTextData(textData);
/*     */ 
/* 222 */             break;
/*     */           case 1:
/*     */           }
/*     */ 
/* 231 */           this._zones.add(zone);
/*     */         }
/*     */       }
/* 234 */       return ret;
/*     */     }
/*     */     finally {
/* 237 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.AutoZoningCommand
 * JD-Core Version:    0.6.2
 */