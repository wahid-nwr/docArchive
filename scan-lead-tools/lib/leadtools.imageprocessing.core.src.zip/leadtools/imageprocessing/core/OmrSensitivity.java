/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum OmrSensitivity
/*    */ {
/*  4 */   HIGHEST(0), 
/*  5 */   HIGH(1), 
/*  6 */   LOW(2), 
/*  7 */   LOWEST(3);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, OmrSensitivity> mappings;
/*    */ 
/* 12 */   private static HashMap<Integer, OmrSensitivity> getMappings() { if (mappings == null) {
/* 13 */       synchronized (OmrSensitivity.class) {
/* 14 */         if (mappings == null) {
/* 15 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 19 */     return mappings; }
/*    */ 
/*    */   private OmrSensitivity(int value)
/*    */   {
/* 23 */     this.intValue = value;
/* 24 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue() {
/* 28 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static OmrSensitivity forValue(int value) {
/* 32 */     return (OmrSensitivity)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.OmrSensitivity
 * JD-Core Version:    0.6.2
 */