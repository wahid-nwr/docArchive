/*     */ package leadtools.imageprocessing.core;
/*     */ 
/*     */ import leadtools.LeadRect;
/*     */ 
/*     */ class OMRZONEDATA
/*     */ {
/*     */   LeadRect _rcBounds;
/*     */   int _nState;
/*     */   int _uConfidence;
/*     */ 
/*     */   public OMRZONEDATA()
/*     */   {
/* 123 */     this._rcBounds = new LeadRect(0, 0, 0, 0);
/* 124 */     this._nState = 0;
/* 125 */     this._uConfidence = 0;
/*     */   }
/*     */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.OMRZONEDATA
 * JD-Core Version:    0.6.2
 */