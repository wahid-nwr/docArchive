/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import leadtools.ArgumentOutOfRangeException;
/*    */ import leadtools.LeadRect;
/*    */ 
/*    */ public class LeadZoneTableData
/*    */ {
/*    */   private List<LeadRect> _cells;
/*    */   private List<LeadZoneType> _celltypes;
/*    */   private List<ArrayList<LeadRect>> _insidecells;
/*    */   private List<LeadRect> _boundstodraw;
/*    */   private int _rows;
/*    */   private int _columns;
/*    */ 
/*    */   public List<LeadZoneType> getCellTypes()
/*    */   {
/* 17 */     return this._celltypes;
/*    */   }
/*    */ 
/*    */   public List<ArrayList<LeadRect>> getInsideCells() {
/* 21 */     return this._insidecells;
/*    */   }
/*    */ 
/*    */   public List<LeadRect> getBoundsToDraw()
/*    */   {
/* 26 */     return this._boundstodraw;
/*    */   }
/*    */ 
/*    */   public LeadZoneTableData()
/*    */   {
/* 34 */     this._cells = new ArrayList();
/* 35 */     this._celltypes = new ArrayList();
/* 36 */     this._insidecells = new ArrayList();
/* 37 */     this._boundstodraw = new ArrayList();
/*    */ 
/* 39 */     this._rows = 0;
/* 40 */     this._columns = 0;
/*    */   }
/*    */ 
/*    */   public int getColumns() {
/* 44 */     return this._columns;
/*    */   }
/*    */ 
/*    */   public void setColumns(int value) {
/* 48 */     if (value < 0) {
/* 49 */       throw new ArgumentOutOfRangeException("Columns", value, "Must be a value greater or equal to zero");
/*    */     }
/* 51 */     this._columns = value;
/*    */   }
/*    */ 
/*    */   public int getRows() {
/* 55 */     return this._rows;
/*    */   }
/*    */ 
/*    */   public void setRows(int value) {
/* 59 */     if (value < 0) {
/* 60 */       throw new ArgumentOutOfRangeException("Rows", value, "Must be a value greater or equal to zero");
/*    */     }
/* 62 */     this._rows = value;
/*    */   }
/*    */ 
/*    */   public List<LeadRect> getCells() {
/* 66 */     return this._cells;
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.LeadZoneTableData
 * JD-Core Version:    0.6.2
 */