/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.LeadPoint;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ import leadtools.ltkrn;
/*    */ 
/*    */ public class AlignImagesCommand extends RasterCommand
/*    */ {
/*    */   private ArrayList<LeadPoint> _referenceimagepoints;
/*    */   private ArrayList<LeadPoint> _templateimagepoints;
/*    */   private RasterImage _outbitmap;
/*    */   private RasterImage _templateimage;
/*    */   private RegistrationOptions _registrationmethod;
/*    */ 
/*    */   public AlignImagesCommand()
/*    */   {
/* 21 */     this._registrationmethod = RegistrationOptions.UNKNOWN;
/* 22 */     this._referenceimagepoints = new ArrayList();
/* 23 */     this._templateimagepoints = new ArrayList();
/* 24 */     this._outbitmap = null;
/* 25 */     this._templateimage = null;
/*    */   }
/*    */ 
/*    */   public RasterImage getRegisteredImage() {
/* 29 */     return this._outbitmap;
/*    */   }
/*    */ 
/*    */   public void setTemplateImage(RasterImage value) {
/* 33 */     this._templateimage = value;
/*    */   }
/*    */ 
/*    */   public RegistrationOptions getRegistrationMethod() {
/* 37 */     return this._registrationmethod;
/*    */   }
/*    */   public void setRegistrationMethod(RegistrationOptions value) {
/* 40 */     this._registrationmethod = value;
/*    */   }
/*    */ 
/*    */   public ArrayList<LeadPoint> getReferenceImagePoints() {
/* 44 */     return this._referenceimagepoints;
/*    */   }
/*    */   public void setReferenceImagePoints(ArrayList<LeadPoint> value) {
/* 47 */     this._referenceimagepoints = value;
/*    */   }
/*    */ 
/*    */   public ArrayList<LeadPoint> getTemplateImagePoints() {
/* 51 */     return this._templateimagepoints;
/*    */   }
/*    */   public void setTemplateImagePoints(ArrayList<LeadPoint> value) {
/* 54 */     this._templateimagepoints = value;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 59 */     return "Align Images";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 64 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 67 */       if (this._templateimage == null) {
/* 68 */         return L_ERROR.ERROR_INV_PARAMETER.getValue();
/*    */       }
/* 70 */       RasterImage imgList = RasterImage.createFromBitmapList(this._templateimage.getBitmapList());
/* 71 */       RasterImage imgList1 = imgList.clone();
/* 72 */       long tempBitmap = ltkrn.AllocBitmapHandle();
/* 73 */       ret = ltkrn.GetBitmapListItem(imgList1.getBitmapList(), 0, tempBitmap, ltkrn.BITMAPHANDLE_getSizeOf());
/* 74 */       if (ret != L_ERROR.SUCCESS.getValue()) {
/* 75 */         return ret;
/*    */       }
/* 77 */       int pointsCount1 = this._referenceimagepoints.size();
/* 78 */       int pointsCount2 = this._templateimagepoints.size();
/*    */ 
/* 80 */       if ((pointsCount1 != pointsCount2) || (pointsCount1 < 1)) {
/* 81 */         return L_ERROR.ERROR_INV_PARAMETER.getValue();
/*    */       }
/* 83 */       LeadPoint[] refPoints = new LeadPoint[pointsCount1];
/* 84 */       LeadPoint[] tempPoints = new LeadPoint[pointsCount1];
/*    */ 
/* 86 */       if ((refPoints == null) || (tempPoints == null)) {
/* 87 */         return L_ERROR.ERROR_NO_MEMORY.getValue();
/*    */       }
/* 89 */       for (int i = 0; i < pointsCount1; i++) {
/* 90 */         refPoints[i] = new LeadPoint();
/* 91 */         refPoints[i].setX(((LeadPoint)this._referenceimagepoints.get(i)).getX());
/* 92 */         refPoints[i].setY(((LeadPoint)this._referenceimagepoints.get(i)).getY());
/*    */ 
/* 94 */         tempPoints[i] = new LeadPoint();
/* 95 */         tempPoints[i].setX(((LeadPoint)this._templateimagepoints.get(i)).getX());
/* 96 */         tempPoints[i].setY(((LeadPoint)this._templateimagepoints.get(i)).getY());
/*    */       }
/*    */ 
/* 99 */       long[] outBitmap = new long[1];
/* 100 */       outBitmap[0] = ltkrn.AllocBitmapHandle();
/*    */ 
/* 102 */       ret = ltimgcor.AlignImages(bitmap, tempBitmap, outBitmap, refPoints, tempPoints, pointsCount1, this._registrationmethod.getValue());
/*    */       int n;
/* 103 */       if (ret != L_ERROR.SUCCESS.getValue()) {
/* 104 */         return ret;
/*    */       }
/* 106 */       if (outBitmap[0] != 0L) {
/* 107 */         this._outbitmap = RasterImage.createFromBitmapHandle(outBitmap[0]);
/*    */       }
/* 109 */       return ret;
/*    */     }
/*    */     finally {
/* 112 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.AlignImagesCommand
 * JD-Core Version:    0.6.2
 */