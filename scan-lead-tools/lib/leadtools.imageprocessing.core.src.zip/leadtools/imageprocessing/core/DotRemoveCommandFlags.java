/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum DotRemoveCommandFlags
/*    */ {
/*  6 */   NONE(0), 
/*  7 */   USE_DPI(1), 
/*  8 */   SINGLE_REGION(2), 
/*  9 */   LEAD_REGION(4), 
/* 10 */   CALLBACK_REGION(8), 
/* 11 */   IMAGE_UNCHANGED(16), 
/* 12 */   USE_SIZE(32), 
/* 13 */   USE_DIAGONALS(4096);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, DotRemoveCommandFlags> mappings;
/*    */ 
/* 19 */   private static HashMap<Integer, DotRemoveCommandFlags> getMappings() { if (mappings == null)
/*    */     {
/* 21 */       synchronized (DotRemoveCommandFlags.class)
/*    */       {
/* 23 */         if (mappings == null)
/*    */         {
/* 25 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 29 */     return mappings;
/*    */   }
/*    */ 
/*    */   private DotRemoveCommandFlags(int value)
/*    */   {
/* 34 */     this.intValue = value;
/* 35 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue()
/*    */   {
/* 40 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static DotRemoveCommandFlags forValue(int value)
/*    */   {
/* 45 */     return (DotRemoveCommandFlags)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.DotRemoveCommandFlags
 * JD-Core Version:    0.6.2
 */