/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum SmoothCommandBumpNickType
/*    */ {
/*  4 */   BUMP(0), 
/*  5 */   NICK(1);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, SmoothCommandBumpNickType> mappings;
/*    */ 
/* 10 */   private static HashMap<Integer, SmoothCommandBumpNickType> getMappings() { if (mappings == null)
/*    */     {
/* 12 */       synchronized (SmoothCommandBumpNickType.class) {
/* 13 */         if (mappings == null) {
/* 14 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 18 */     return mappings; }
/*    */ 
/*    */   private SmoothCommandBumpNickType(int value)
/*    */   {
/* 22 */     this.intValue = value;
/* 23 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue() {
/* 27 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static SmoothCommandBumpNickType forValue(int value) {
/* 31 */     return (SmoothCommandBumpNickType)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.SmoothCommandBumpNickType
 * JD-Core Version:    0.6.2
 */