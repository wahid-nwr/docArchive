/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ class DicomLutDescriptor
/*    */ {
/*    */   public int _uNumberOfEntries;
/*    */   public int _nFirstStoredPixelValueMapped;
/*    */   public int _uEntryBits;
/*    */ 
/*    */   public DicomLutDescriptor()
/*    */   {
/* 81 */     this._uNumberOfEntries = 0;
/* 82 */     this._nFirstStoredPixelValueMapped = 0;
/* 83 */     this._uEntryBits = 0;
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.DicomLutDescriptor
 * JD-Core Version:    0.6.2
 */