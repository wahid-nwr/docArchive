/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class ZeroToNegativeCommand extends RasterCommand
/*    */ {
/*    */   private int _shiftAmount;
/*    */   private int _minimumInput;
/*    */   private int _maximumInput;
/*    */   private int _minimumOutput;
/*    */   private int _maximumOutput;
/*    */ 
/*    */   public ZeroToNegativeCommand()
/*    */   {
/* 16 */     this._shiftAmount = 0;
/* 17 */     this._minimumInput = 0;
/* 18 */     this._maximumInput = 0;
/* 19 */     this._minimumOutput = 0;
/* 20 */     this._maximumOutput = 0;
/*    */   }
/*    */ 
/*    */   public ZeroToNegativeCommand(int shiftAmount, int minimumInput, int maximumInput, int minimumOutput, int maximumOutput) {
/* 24 */     this._shiftAmount = shiftAmount;
/* 25 */     this._minimumInput = minimumInput;
/* 26 */     this._maximumInput = maximumInput;
/* 27 */     this._minimumOutput = minimumOutput;
/* 28 */     this._maximumOutput = maximumOutput;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 33 */     return "Shift Zero to Negative";
/*    */   }
/*    */ 
/*    */   public int getShiftAmount() {
/* 37 */     return this._shiftAmount;
/*    */   }
/*    */   public void setShiftAmount(int value) {
/* 40 */     this._shiftAmount = value;
/*    */   }
/*    */ 
/*    */   public int getMinimumInput() {
/* 44 */     return this._minimumInput;
/*    */   }
/*    */   public void setMinimumInput(int value) {
/* 47 */     this._minimumInput = value;
/*    */   }
/*    */ 
/*    */   public int getMaximumInput() {
/* 51 */     return this._maximumInput;
/*    */   }
/*    */   public void setMaximumInput(int value) {
/* 54 */     this._maximumInput = value;
/*    */   }
/*    */ 
/*    */   public int getMinimumOutput() {
/* 58 */     return this._minimumOutput;
/*    */   }
/*    */   public void setMinimumOutput(int value) {
/* 61 */     this._minimumOutput = value;
/*    */   }
/*    */ 
/*    */   public int getMaximumOutput() {
/* 65 */     return this._maximumOutput;
/*    */   }
/*    */   public void setMaximumOutput(int value) {
/* 68 */     this._maximumOutput = value;
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 73 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 76 */       ret = ltimgcor.ShiftZeroToNegative(bitmap, this._shiftAmount, this._minimumInput, this._maximumInput, this._minimumOutput, this._maximumOutput, 0);
/*    */ 
/* 84 */       return ret;
/*    */     }
/*    */     finally {
/* 87 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.ZeroToNegativeCommand
 * JD-Core Version:    0.6.2
 */