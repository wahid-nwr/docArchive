/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.LeadRect;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class SRADAnisotropicDiffusionCommand extends RasterCommand
/*    */ {
/*    */   private int _iterations;
/*    */   private int _lambda;
/*    */   private LeadRect _rect;
/*    */ 
/*    */   public SRADAnisotropicDiffusionCommand()
/*    */   {
/* 16 */     this._iterations = 10;
/* 17 */     this._lambda = 14;
/* 18 */     this._rect = LeadRect.getEmpty();
/*    */   }
/*    */ 
/*    */   public SRADAnisotropicDiffusionCommand(int iterations, int lambda, LeadRect rect) {
/* 22 */     this._iterations = iterations;
/* 23 */     this._lambda = lambda;
/* 24 */     this._rect = rect;
/*    */   }
/*    */ 
/*    */   public int getIterations() {
/* 28 */     return this._iterations;
/*    */   }
/*    */ 
/*    */   public void setIterations(int value) {
/* 32 */     this._iterations = value;
/*    */   }
/*    */ 
/*    */   public int getLambda() {
/* 36 */     return this._lambda;
/*    */   }
/*    */ 
/*    */   public void setLambda(int value) {
/* 40 */     this._lambda = value;
/*    */   }
/*    */ 
/*    */   public LeadRect getRect() {
/* 44 */     return this._rect;
/*    */   }
/*    */ 
/*    */   public void setRect(LeadRect value) {
/* 48 */     this._rect = value;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 53 */     return "Speckle Reduction Anisotropic Diffusion";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 58 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/*    */       LeadRect rc;
/*    */       LeadRect rc;
/* 63 */       if (this._rect.isEmpty()) {
/* 64 */         rc = LeadRect.fromLTRB(10, 10, image.getWidth() - 10, image.getHeight() - 10);
/*    */       }
/*    */       else {
/* 67 */         rc = LeadRect.fromLTRB(this._rect.getLeft(), this._rect.getTop(), this._rect.getRight(), this._rect.getBottom());
/*    */       }
/*    */ 
/* 70 */       ret = ltimgcor.SRADAnisotropicDiffusion(bitmap, this._iterations, this._lambda, rc);
/* 71 */       return ret;
/*    */     }
/*    */     finally {
/* 74 */       image.updateCurrentBitmapHandle();
/* 75 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.SRADAnisotropicDiffusionCommand
 * JD-Core Version:    0.6.2
 */