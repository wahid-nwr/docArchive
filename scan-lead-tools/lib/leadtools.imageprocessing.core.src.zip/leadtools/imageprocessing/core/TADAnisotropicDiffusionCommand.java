/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class TADAnisotropicDiffusionCommand extends RasterCommand
/*    */ {
/*    */   private int _iterations;
/*    */   private int _kappa;
/*    */   private int _lambda;
/*    */   private TADAnisotropicDiffusionFlags _flags;
/*    */ 
/*    */   public TADAnisotropicDiffusionCommand()
/*    */   {
/* 16 */     this._iterations = 10;
/* 17 */     this._lambda = 14;
/* 18 */     this._kappa = 30;
/* 19 */     this._flags = TADAnisotropicDiffusionFlags.QUADRATIC_FLUX;
/*    */   }
/*    */ 
/*    */   public TADAnisotropicDiffusionCommand(int iterations, int lambda, int kappa, TADAnisotropicDiffusionFlags flags) {
/* 23 */     this._iterations = iterations;
/* 24 */     this._kappa = kappa;
/* 25 */     this._lambda = lambda;
/* 26 */     this._flags = flags;
/*    */   }
/*    */ 
/*    */   public int getIterations() {
/* 30 */     return this._iterations;
/*    */   }
/*    */ 
/*    */   public void setIterations(int value) {
/* 34 */     this._iterations = value;
/*    */   }
/*    */ 
/*    */   public int getKappa() {
/* 38 */     return this._kappa;
/*    */   }
/*    */ 
/*    */   public void setKappa(int value) {
/* 42 */     this._kappa = value;
/*    */   }
/*    */ 
/*    */   public int getLambda() {
/* 46 */     return this._lambda;
/*    */   }
/*    */ 
/*    */   public void setLambda(int value) {
/* 50 */     this._lambda = value;
/*    */   }
/*    */ 
/*    */   public TADAnisotropicDiffusionFlags getFlags() {
/* 54 */     return this._flags;
/*    */   }
/*    */ 
/*    */   public void setFlags(TADAnisotropicDiffusionFlags value) {
/* 58 */     this._flags = value;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 63 */     return "Tensor Guided Anisotropic Diffusion";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 68 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 71 */       ret = ltimgcor.TADAnisotropicDiffusion(bitmap, this._iterations, this._lambda, this._kappa, this._flags.getValue());
/* 72 */       return ret;
/*    */     }
/*    */     finally {
/* 75 */       image.updateCurrentBitmapHandle();
/* 76 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.TADAnisotropicDiffusionCommand
 * JD-Core Version:    0.6.2
 */