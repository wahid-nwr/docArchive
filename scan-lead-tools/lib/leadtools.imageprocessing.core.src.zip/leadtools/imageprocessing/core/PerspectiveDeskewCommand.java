/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class PerspectiveDeskewCommand extends RasterCommand
/*    */ {
/*    */   public String toString()
/*    */   {
/* 15 */     return "Auto 3D Deskew";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 20 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 23 */       ret = ltimgcor.PerspectiveDeskew(bitmap);
/* 24 */       return ret;
/*    */     }
/*    */     finally {
/* 27 */       changedFlags[0] = (changedFlags[0] | RasterImageChangedFlags.DATA | RasterImageChangedFlags.SIZE);
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.PerspectiveDeskewCommand
 * JD-Core Version:    0.6.2
 */