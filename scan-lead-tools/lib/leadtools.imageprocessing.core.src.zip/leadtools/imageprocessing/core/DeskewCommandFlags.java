/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum DeskewCommandFlags
/*    */ {
/*  5 */   DESKEW_IMAGE(0), 
/*  6 */   RETURN_ANGLE_ONLY(1), 
/*  7 */   FILL_EXPOSED_AREA(0), 
/*  8 */   DO_NOT_FILL_EXPOSED_AREA(16), 
/*  9 */   NO_THRESHOLD(0), 
/* 10 */   THRESHOLD(256), 
/* 11 */   ROTATE_LINEAR(0), 
/* 12 */   ROTATE_RESAMPLE(4096), 
/* 13 */   ROTATE_BICUBIC(8192), 
/* 14 */   DOCUMENT_IMAGE(0), 
/* 15 */   DOCUMENT_AND_PICTURES(65536), 
/* 16 */   USE_NORMAL_ROTATE(0), 
/* 17 */   USE_HIGH_SPEED_ROTATE(1048576), 
/* 18 */   PERFORM_PRE_PROCESSING(0), 
/* 19 */   DO_NOT_PERFORM_PRE_PROCESSING(268435456), 
/* 20 */   USE_SELECTIVE_DETECTION(0), 
/* 21 */   USE_NORMAL_DETECTION(536870912), 
/* 22 */   DO_NOT_USE_CHECK_DESKEW(0), 
/* 23 */   USE_CHECK_DESKEW(16777216), 
/* 24 */   USE_LINE_DETECTION_CHECK_DESKEW(33554432), 
/* 25 */   USE_EXTENDED_DESKEW(67108864);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, DeskewCommandFlags> mappings;
/*    */ 
/* 31 */   private static HashMap<Integer, DeskewCommandFlags> getMappings() { if (mappings == null)
/*    */     {
/* 33 */       synchronized (DeskewCommandFlags.class)
/*    */       {
/* 35 */         if (mappings == null)
/*    */         {
/* 37 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 41 */     return mappings;
/*    */   }
/*    */ 
/*    */   private DeskewCommandFlags(int value)
/*    */   {
/* 46 */     this.intValue = value;
/* 47 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue()
/*    */   {
/* 52 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static DeskewCommandFlags forValue(int value)
/*    */   {
/* 57 */     return (DeskewCommandFlags)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.DeskewCommandFlags
 * JD-Core Version:    0.6.2
 */