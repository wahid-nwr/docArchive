/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class MinMaxValuesCommand extends RasterCommand
/*    */ {
/*    */   private int _minimumValue;
/*    */   private int _maximumValue;
/*    */ 
/*    */   public MinMaxValuesCommand()
/*    */   {
/* 13 */     this._minimumValue = 0;
/* 14 */     this._maximumValue = 0;
/*    */   }
/*    */ 
/*    */   public int getMinimumValue() {
/* 18 */     return this._minimumValue;
/*    */   }
/*    */ 
/*    */   public int getMaximumValue() {
/* 22 */     return this._maximumValue;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 27 */     return "Minimum and Maximum Values";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 32 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 35 */       int[] x = new int[1];
/* 36 */       int[] y = new int[1];
/*    */ 
/* 38 */       ret = ltimgcor.GetMinMaxVal(bitmap, x, y, 0);
/*    */ 
/* 40 */       if (ret == L_ERROR.SUCCESS.getValue()) {
/* 41 */         this._minimumValue = x[0];
/* 42 */         this._maximumValue = y[0];
/*    */       }
/* 44 */       return ret;
/*    */     }
/*    */     finally {
/* 47 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.MinMaxValuesCommand
 * JD-Core Version:    0.6.2
 */