/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.LeadRect;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class OmrCommand extends RasterCommand
/*    */ {
/*    */   private List<OmrZone> _zones;
/*    */   private OmrFrameDetectionMethod _frameDetectionMethod;
/*    */   private OmrSensitivity _sensitivity;
/*    */ 
/*    */   public OmrCommand()
/*    */   {
/* 18 */     this._zones = new ArrayList();
/* 19 */     this._frameDetectionMethod = OmrFrameDetectionMethod.AUTO;
/* 20 */     this._sensitivity = OmrSensitivity.HIGHEST;
/*    */   }
/*    */ 
/*    */   public OmrCommand(OmrFrameDetectionMethod frameDetectionMethod, OmrSensitivity sensitivity) {
/* 24 */     this._zones = new ArrayList();
/* 25 */     this._frameDetectionMethod = frameDetectionMethod;
/* 26 */     this._sensitivity = sensitivity;
/*    */   }
/*    */ 
/*    */   public List<OmrZone> getZones() {
/* 30 */     return this._zones;
/*    */   }
/*    */ 
/*    */   public OmrFrameDetectionMethod getFrameDetectionMethod() {
/* 34 */     return this._frameDetectionMethod;
/*    */   }
/*    */ 
/*    */   public void setFrameDetectionMethod(OmrFrameDetectionMethod value) {
/* 38 */     this._frameDetectionMethod = value;
/*    */   }
/*    */ 
/*    */   public OmrSensitivity getSensitivity() {
/* 42 */     return this._sensitivity;
/*    */   }
/*    */ 
/*    */   public void setSensitivity(OmrSensitivity value) {
/* 46 */     this._sensitivity = value;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 51 */     return "Optical Mark Recognition";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 56 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */ 
/* 58 */     if (this._zones.size() == 0) {
/* 59 */       return L_ERROR.SUCCESS.getValue();
/*    */     }
/* 61 */     OMRZONEDATA[] omrZones = null;
/*    */     try
/*    */     {
/* 64 */       omrZones = new OMRZONEDATA[this._zones.size()];
/*    */ 
/* 66 */       for (int i = 0; i < this._zones.size(); i++) {
/* 67 */         omrZones[i] = new OMRZONEDATA();
/* 68 */         LeadRect rc = ((OmrZone)this._zones.get(i)).getBounds();
/* 69 */         omrZones[i]._rcBounds = new LeadRect(rc.getLeft(), rc.getTop(), rc.getWidth(), rc.getHeight());
/*    */       }
/*    */ 
/* 72 */       int flags = 0;
/*    */ 
/* 74 */       switch (this._frameDetectionMethod.getValue()) {
/*    */       case 1:
/* 76 */         flags |= 1; break;
/*    */       case 2:
/* 77 */         flags |= 2; break;
/*    */       case 0:
/*    */       default:
/* 79 */         flags |= 0;
/*    */       }
/*    */ 
/* 82 */       switch (this._sensitivity.getValue()) {
/*    */       case 1:
/* 84 */         flags |= 16; break;
/*    */       case 2:
/* 85 */         flags |= 32; break;
/*    */       case 3:
/* 86 */         flags |= 64; break;
/*    */       case 0:
/*    */       default:
/* 88 */         flags |= 0;
/*    */       }
/*    */ 
/* 91 */       ret = ltimgcor.OMR(bitmap, omrZones, this._zones.size(), flags);
/*    */       int i;
/* 92 */       if (ret == L_ERROR.SUCCESS.getValue())
/*    */       {
/* 94 */         for (i = 0; i < this._zones.size(); i++)
/*    */         {
/* 96 */           OmrZone zone = (OmrZone)this._zones.get(i);
/* 97 */           zone.setConfidence(omrZones[i]._uConfidence);
/*    */ 
/* 99 */           if (omrZones[i]._nState == 1)
/* 100 */             zone.setState(OmrZoneState.FILLED);
/*    */           else {
/* 102 */             zone.setState(OmrZoneState.UNFILLED);
/*    */           }
/* 104 */           this._zones.set(i, zone);
/*    */         }
/*    */       }
/*    */ 
/* 108 */       return ret;
/*    */     }
/*    */     finally {
/* 111 */       image.updateCurrentBitmapHandle();
/* 112 */       changedFlags[0] = (RasterImageChangedFlags.DATA | RasterImageChangedFlags.PALETTE | RasterImageChangedFlags.SIZE);
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.OmrCommand
 * JD-Core Version:    0.6.2
 */