/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum BarCodeReadPreprocessOptions
/*    */ {
/*  4 */   USE_DEFAULT(0), 
/*  5 */   USE_AUTODOCUMENTBINARIZATION(2);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, BarCodeReadPreprocessOptions> mappings;
/*    */ 
/* 10 */   private static HashMap<Integer, BarCodeReadPreprocessOptions> getMappings() { if (mappings == null) {
/* 11 */       synchronized (BarCodeReadPreprocessOptions.class) {
/* 12 */         if (mappings == null) {
/* 13 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 17 */     return mappings; }
/*    */ 
/*    */   private BarCodeReadPreprocessOptions(int value)
/*    */   {
/* 21 */     this.intValue = value;
/* 22 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue() {
/* 26 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static BarCodeReadPreprocessOptions forValue(int value) {
/* 30 */     return (BarCodeReadPreprocessOptions)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.BarCodeReadPreprocessOptions
 * JD-Core Version:    0.6.2
 */