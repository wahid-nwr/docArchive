/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ public enum ImageColorTypeCommandFlags
/*    */ {
/*  4 */   NONE(0), 
/*  5 */   FAVOR_COLOR(1), 
/*  6 */   FAVOR_GRAY_SCALE(2), 
/*  7 */   FAVOR_BLACK_AND_WHITE(1);
/*    */ 
/*    */   private int intValue;
/*    */ 
/*    */   private ImageColorTypeCommandFlags(int value) {
/* 12 */     this.intValue = value;
/*    */   }
/*    */ 
/*    */   public int getValue() {
/* 16 */     return this.intValue;
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.ImageColorTypeCommandFlags
 * JD-Core Version:    0.6.2
 */