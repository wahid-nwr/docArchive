/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum TADAnisotropicDiffusionFlags
/*    */ {
/*  5 */   EXPONENTIAL_FLUX(1), 
/*  6 */   QUADRATIC_FLUX(2);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, TADAnisotropicDiffusionFlags> mappings;
/*    */ 
/* 11 */   private static HashMap<Integer, TADAnisotropicDiffusionFlags> getMappings() { if (mappings == null) {
/* 12 */       synchronized (TADAnisotropicDiffusionFlags.class) {
/* 13 */         if (mappings == null) {
/* 14 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 18 */     return mappings; }
/*    */ 
/*    */   private TADAnisotropicDiffusionFlags(int value)
/*    */   {
/* 22 */     this.intValue = value;
/* 23 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue() {
/* 27 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static TADAnisotropicDiffusionFlags forValue(int value) {
/* 31 */     return (TADAnisotropicDiffusionFlags)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.TADAnisotropicDiffusionFlags
 * JD-Core Version:    0.6.2
 */