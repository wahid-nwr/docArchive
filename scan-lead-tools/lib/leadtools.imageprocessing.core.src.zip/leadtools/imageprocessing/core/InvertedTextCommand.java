/*     */ package leadtools.imageprocessing.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import leadtools.L_ERROR;
/*     */ import leadtools.LeadRect;
/*     */ import leadtools.RasterImage;
/*     */ import leadtools.RasterImageChangedFlags;
/*     */ import leadtools.RasterRegion;
/*     */ import leadtools.imageprocessing.RasterCommand;
/*     */ import leadtools.ltkrn;
/*     */ 
/*     */ public class InvertedTextCommand extends RasterCommand
/*     */ {
/*     */   private int _flags;
/*     */   private int _minimumInvertWidth;
/*     */   private int _minimumInvertHeight;
/*     */   private int _minimumBlackPercent;
/*     */   private int _maximumBlackPercent;
/*     */   private RasterImage _imageRegion;
/*     */   private RasterRegion _region;
/*     */   private RasterImage _image;
/*     */   private ArrayList<InvertedTextCommandListener> _invertedText;
/*     */ 
/*     */   public void addInvertedTextCommandListener(InvertedTextCommandListener listener)
/*     */   {
/*  26 */     this._invertedText.add(listener);
/*     */   }
/*     */ 
/*     */   public void removeInvertedTextCommandListener(InvertedTextCommandListener listener) {
/*  30 */     this._invertedText.remove(listener);
/*     */   }
/*     */ 
/*     */   public int getFlags() {
/*  34 */     return this._flags;
/*     */   }
/*     */ 
/*     */   public void setFlags(int value) {
/*  38 */     this._flags = value;
/*     */   }
/*     */ 
/*     */   public int getMinimumInvertWidth() {
/*  42 */     return this._minimumInvertWidth;
/*     */   }
/*     */ 
/*     */   public void setMinimumInvertWidth(int value) {
/*  46 */     this._minimumInvertWidth = value;
/*     */   }
/*     */ 
/*     */   public int getMinimumInvertHeight() {
/*  50 */     return this._minimumInvertHeight;
/*     */   }
/*     */ 
/*     */   public void setMinimumInvertHeight(int value) {
/*  54 */     this._minimumInvertHeight = value;
/*     */   }
/*     */ 
/*     */   public int getMinimumBlackPercent() {
/*  58 */     return this._minimumBlackPercent;
/*     */   }
/*     */ 
/*     */   public void setMinimumBlackPercent(int value) {
/*  62 */     this._minimumBlackPercent = value;
/*     */   }
/*     */ 
/*     */   public int getMaximumBlackPercent() {
/*  66 */     return this._maximumBlackPercent;
/*     */   }
/*     */ 
/*     */   public void setMaximumBlackPercent(int value) {
/*  70 */     this._maximumBlackPercent = value;
/*     */   }
/*     */ 
/*     */   public RasterRegion getRegion() {
/*  74 */     return this._region;
/*     */   }
/*     */ 
/*     */   public RasterImage getImageRegion() {
/*  78 */     return this._imageRegion;
/*     */   }
/*     */ 
/*     */   public InvertedTextCommand() {
/*  82 */     this._flags = InvertedTextCommandFlags.USE_DPI.getValue();
/*  83 */     this._minimumInvertWidth = 6000;
/*  84 */     this._minimumInvertHeight = 375;
/*  85 */     this._minimumBlackPercent = 75;
/*  86 */     this._maximumBlackPercent = 95;
/*  87 */     this._region = null;
/*  88 */     this._imageRegion = null;
/*  89 */     this._invertedText = new ArrayList();
/*     */   }
/*     */ 
/*     */   public InvertedTextCommand(int flags, int minimumInvertWidth, int minimumInvertHeight, int minimumBlackPercent, int maximumBlackPercent) {
/*  93 */     this._flags = flags;
/*  94 */     this._minimumInvertWidth = minimumInvertWidth;
/*  95 */     this._minimumInvertHeight = minimumInvertHeight;
/*  96 */     this._minimumBlackPercent = minimumBlackPercent;
/*  97 */     this._maximumBlackPercent = maximumBlackPercent;
/*  98 */     this._invertedText = new ArrayList();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 103 */     return "Inverted Text";
/*     */   }
/*     */ 
/*     */   private final int DoCallback(int leadRegion, int left, int top, int right, int bottom, int iWhiteCount, int iBlackCount)
/*     */   {
/* 109 */     int ret = L_ERROR.SUCCESS.getValue();
/*     */ 
/* 111 */     Iterator i$ = this._invertedText.iterator(); if (i$.hasNext()) { InvertedTextCommandListener listener = (InvertedTextCommandListener)i$.next();
/* 112 */       LeadRect boundingLeadRect = LeadRect.fromLTRB(left, top, right, bottom);
/* 113 */       InvertedTextCommandEvent args = new InvertedTextCommandEvent(this, this._image, leadRegion != 0 ? new RasterRegion(leadRegion, false) : null, boundingLeadRect, iWhiteCount, iBlackCount);
/* 114 */       listener.onInvertedTextEvent(args);
/* 115 */       return args.getStatus().getValue();
/*     */     }
/*     */ 
/* 118 */     return ret;
/*     */   }
/*     */ 
/*     */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*     */   {
/* 123 */     int ret = L_ERROR.SUCCESS.getValue();
/* 124 */     long bitmapRegion = 0L;
/*     */     try
/*     */     {
/* 127 */       this._image = image;
/* 128 */       InvertedTextStruct invertedText = new InvertedTextStruct();
/* 129 */       invertedText._uFlags = this._flags;
/* 130 */       invertedText._iMinInvertWidth = this._minimumInvertWidth;
/* 131 */       invertedText._iMinInvertHeight = this._minimumInvertHeight;
/* 132 */       invertedText._iMinBlackPercent = this._minimumBlackPercent;
/* 133 */       invertedText._iMaxBlackPercent = this._maximumBlackPercent;
/*     */ 
/* 136 */       if (((this._flags & InvertedTextCommandFlags.SINGLE_REGION.getValue()) == InvertedTextCommandFlags.SINGLE_REGION.getValue()) && ((this._flags & InvertedTextCommandFlags.LEAD_REGION.getValue()) == InvertedTextCommandFlags.LEAD_REGION.getValue()))
/*     */       {
/* 139 */         bitmapRegion = ltkrn.AllocBitmapHandle();
/* 140 */         invertedText._bitmapRegion = bitmapRegion;
/*     */       }
/*     */ 
/* 143 */       ret = ltimgcor.InvertedTextBitmap(bitmap, invertedText, this._invertedText.size() > 0 ? this : null, 0);
/* 144 */       if (ret == L_ERROR.SUCCESS.getValue())
/*     */       {
/* 146 */         this._imageRegion = null;
/* 147 */         this._region = null;
/*     */ 
/* 150 */         if (((this._flags & InvertedTextCommandFlags.SINGLE_REGION.getValue()) == InvertedTextCommandFlags.SINGLE_REGION.getValue()) && ((this._flags & InvertedTextCommandFlags.LEAD_REGION.getValue()) == InvertedTextCommandFlags.LEAD_REGION.getValue()))
/*     */         {
/* 153 */           this._imageRegion = RasterImage.createFromBitmapHandle(bitmapRegion);
/*     */         }
/* 156 */         else if ((this._flags & InvertedTextCommandFlags.SINGLE_REGION.getValue()) == InvertedTextCommandFlags.SINGLE_REGION.getValue())
/*     */         {
/* 158 */           if (invertedText._leadregion != 0L) {
/* 159 */             this._region = new RasterRegion(invertedText._leadregion, true);
/* 160 */             ltkrn.DeleteLeadRgn(invertedText._leadregion);
/* 161 */             invertedText._leadregion = 0L;
/*     */           }
/*     */         }
/*     */       }
/* 165 */       return ret;
/*     */     }
/*     */     finally {
/* 168 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/* 169 */       if (bitmapRegion != 0L)
/* 170 */         ltkrn.FreeBitmapHandle(bitmapRegion);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.InvertedTextCommand
 * JD-Core Version:    0.6.2
 */