/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum RegistrationOptions
/*    */ {
/*  5 */   UNKNOWN(0), 
/*  6 */   XY(1), 
/*  7 */   RSXY(2), 
/*  8 */   AFFINE6(3), 
/*  9 */   PERSPECTIVE(4);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, RegistrationOptions> mappings;
/*    */ 
/* 14 */   private static HashMap<Integer, RegistrationOptions> getMappings() { if (mappings == null) {
/* 15 */       synchronized (RegistrationOptions.class) {
/* 16 */         if (mappings == null) {
/* 17 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 21 */     return mappings; }
/*    */ 
/*    */   private RegistrationOptions(int value)
/*    */   {
/* 25 */     this.intValue = value;
/* 26 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue() {
/* 30 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static RegistrationOptions forValue(int value) {
/* 34 */     return (RegistrationOptions)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.RegistrationOptions
 * JD-Core Version:    0.6.2
 */