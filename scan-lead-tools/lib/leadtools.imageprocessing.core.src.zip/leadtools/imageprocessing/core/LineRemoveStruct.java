/*     */ package leadtools.imageprocessing.core;
/*     */ 
/*     */ class LineRemoveStruct
/*     */ {
/*     */   public int _uFlags;
/*     */   public int _iMinLineLength;
/*     */   public int _iMaxLineWidth;
/*     */   public int _iWall;
/*     */   public int _iMaxWallPercent;
/*     */   public int _iGapLength;
/*     */   public int _iVariance;
/*     */   public int _uRemoveFlags;
/*     */   public long _rgn;
/*     */   public long _bitmapRegion;
/*     */   public long _leadregion;
/*     */ 
/*     */   public LineRemoveStruct()
/*     */   {
/* 220 */     this._uFlags = 0;
/* 221 */     this._iMinLineLength = 0;
/* 222 */     this._iMaxLineWidth = 0;
/* 223 */     this._iWall = 0;
/* 224 */     this._iMaxWallPercent = 0;
/* 225 */     this._iGapLength = 0;
/* 226 */     this._iVariance = 0;
/* 227 */     this._uRemoveFlags = 0;
/* 228 */     this._rgn = 0L;
/* 229 */     this._bitmapRegion = 0L;
/* 230 */     this._leadregion = 0L;
/*     */   }
/*     */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.LineRemoveStruct
 * JD-Core Version:    0.6.2
 */