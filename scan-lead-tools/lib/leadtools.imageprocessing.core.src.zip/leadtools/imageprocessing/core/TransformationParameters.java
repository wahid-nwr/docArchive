/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ public class TransformationParameters
/*    */ {
/*    */   private int _xTranslation;
/*    */   private int _yTranslation;
/*    */   private int _angle;
/*    */   private int _xScale;
/*    */   private int _yScale;
/*    */ 
/*    */   public TransformationParameters()
/*    */   {
/* 11 */     this._xTranslation = 0;
/* 12 */     this._yTranslation = 0;
/* 13 */     this._angle = 0;
/* 14 */     this._xScale = 0;
/* 15 */     this._yScale = 0;
/*    */   }
/*    */ 
/*    */   public int getXTranslation() {
/* 19 */     return this._xTranslation;
/*    */   }
/*    */ 
/*    */   public void setXTranslation(int value)
/*    */   {
/* 24 */     this._xTranslation = value;
/*    */   }
/*    */ 
/*    */   public int getYTranslation() {
/* 28 */     return this._yTranslation;
/*    */   }
/*    */ 
/*    */   public void setYTranslation(int value) {
/* 32 */     this._yTranslation = value;
/*    */   }
/*    */ 
/*    */   public int getAngle() {
/* 36 */     return this._angle;
/*    */   }
/*    */ 
/*    */   public void setAngle(int value) {
/* 40 */     this._angle = value;
/*    */   }
/*    */ 
/*    */   public int getXScale() {
/* 44 */     return this._xScale;
/*    */   }
/*    */ 
/*    */   public void setXScale(int value) {
/* 48 */     this._xScale = value;
/*    */   }
/*    */ 
/*    */   public int getYScale() {
/* 52 */     return this._yScale;
/*    */   }
/*    */ 
/*    */   public void setYScale(int value) {
/* 56 */     this._yScale = value;
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.TransformationParameters
 * JD-Core Version:    0.6.2
 */