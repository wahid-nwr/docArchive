/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum MultiscaleEnhancementCommandFlags
/*    */ {
/*  6 */   NONE(0), 
/*  7 */   EDGE_ENHANCEMENT(16), 
/*  8 */   LATITUDE_REDUCTION(32);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, MultiscaleEnhancementCommandFlags> mappings;
/*    */ 
/* 13 */   private static HashMap<Integer, MultiscaleEnhancementCommandFlags> getMappings() { if (mappings == null)
/*    */     {
/* 15 */       synchronized (MultiscaleEnhancementCommandFlags.class)
/*    */       {
/* 17 */         if (mappings == null)
/*    */         {
/* 19 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 23 */     return mappings; }
/*    */ 
/*    */   private MultiscaleEnhancementCommandFlags(int value)
/*    */   {
/* 27 */     this.intValue = value;
/* 28 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue() {
/* 32 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static MultiscaleEnhancementCommandFlags forValue(int value) {
/* 36 */     return (MultiscaleEnhancementCommandFlags)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.MultiscaleEnhancementCommandFlags
 * JD-Core Version:    0.6.2
 */