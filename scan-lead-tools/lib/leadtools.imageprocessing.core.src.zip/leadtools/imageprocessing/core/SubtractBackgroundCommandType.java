/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum SubtractBackgroundCommandType
/*    */ {
/*  4 */   DEPEND_ON_ROLLING_BALL_SIZE(0), 
/*  5 */   NO_SHRINKING(1), 
/*  6 */   ONE_TO_TWO(2), 
/*  7 */   ONE_TO_FOUR(3), 
/*  8 */   ONE_TO_EIGHT(4);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, SubtractBackgroundCommandType> mappings;
/*    */ 
/* 14 */   private static HashMap<Integer, SubtractBackgroundCommandType> getMappings() { if (mappings == null)
/*    */     {
/* 16 */       synchronized (SubtractBackgroundCommandType.class)
/*    */       {
/* 18 */         if (mappings == null)
/*    */         {
/* 20 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 24 */     return mappings;
/*    */   }
/*    */ 
/*    */   private SubtractBackgroundCommandType(int value)
/*    */   {
/* 29 */     this.intValue = value;
/* 30 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue()
/*    */   {
/* 35 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static SubtractBackgroundCommandType forValue(int value)
/*    */   {
/* 40 */     return (SubtractBackgroundCommandType)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.SubtractBackgroundCommandType
 * JD-Core Version:    0.6.2
 */