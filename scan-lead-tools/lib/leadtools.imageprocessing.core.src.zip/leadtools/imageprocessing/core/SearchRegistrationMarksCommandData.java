/*     */ package leadtools.imageprocessing.core;
/*     */ 
/*     */ import leadtools.LeadPoint;
/*     */ import leadtools.LeadRect;
/*     */ 
/*     */ public class SearchRegistrationMarksCommandData
/*     */ {
/*     */   private int _width;
/*     */   private int _height;
/*     */   private int _minimumScale;
/*     */   private int _maximumScale;
/*     */   private LeadRect _rectangle;
/*     */   private int _searchMarkCount;
/*     */   private LeadPoint[] _markDetectedPoints;
/*     */   private int _markDetectedCount;
/*     */   private RegistrationMarkCommandType _type;
/*     */   private SEARCHMARKS _unmanaged;
/*     */ 
/*     */   public SearchRegistrationMarksCommandData()
/*     */   {
/*  24 */     this._width = 0;
/*  25 */     this._height = 0;
/*  26 */     this._minimumScale = 90;
/*  27 */     this._maximumScale = 110;
/*  28 */     this._rectangle = LeadRect.getEmpty();
/*  29 */     this._searchMarkCount = 0;
/*  30 */     this._markDetectedPoints = null;
/*  31 */     this._markDetectedCount = 0;
/*  32 */     this._type = RegistrationMarkCommandType.T_SHAPE;
/*     */ 
/*  35 */     this._unmanaged = new SEARCHMARKS();
/*     */   }
/*     */ 
/*     */   public SearchRegistrationMarksCommandData(int width, int height, int minimumScale, int maximumScale, LeadRect rectangle, int searchMarkCount, LeadPoint[] markDetectedPoints, RegistrationMarkCommandType type) {
/*  39 */     this._width = width;
/*  40 */     this._height = height;
/*  41 */     this._minimumScale = minimumScale;
/*  42 */     this._maximumScale = maximumScale;
/*  43 */     this._rectangle = rectangle;
/*  44 */     this._searchMarkCount = searchMarkCount;
/*  45 */     this._markDetectedPoints = markDetectedPoints;
/*  46 */     this._markDetectedCount = 0;
/*  47 */     this._type = type;
/*     */   }
/*     */ 
/*     */   public int getDataSize() {
/*  51 */     return this._unmanaged._uMarkDetectedCount;
/*     */   }
/*     */ 
/*     */   public LeadPoint[] getData()
/*     */   {
/*  56 */     if (this._unmanaged._uMarkDetectedCount > 0)
/*     */     {
/*  58 */       LeadPoint[] data = new LeadPoint[this._unmanaged._uMarkDetectedCount];
/*  59 */       for (int i = 0; i < data.length; i++) {
/*  60 */         data[i] = new LeadPoint(this._unmanaged._markDetectedPoints[i].getX(), this._unmanaged._markDetectedPoints[i].getY());
/*     */       }
/*  62 */       return data;
/*     */     }
/*     */ 
/*  65 */     return null;
/*     */   }
/*     */ 
/*     */   public void setData(LeadPoint[] value) {
/*  69 */     this._unmanaged._markDetectedPoints = null;
/*  70 */     this._unmanaged._uMarkDetectedCount = 0;
/*     */ 
/*  72 */     if (value != null)
/*     */     {
/*  81 */       this._unmanaged._markDetectedPoints = value;
/*  82 */       this._unmanaged._uMarkDetectedCount = value.length;
/*     */     }
/*     */   }
/*     */ 
/*  86 */   public int getWidth() { return this._width; } 
/*  87 */   public void setWidth(int value) { this._width = value; }
/*     */ 
/*     */   public int getHeight() {
/*  90 */     return this._height;
/*     */   }
/*     */ 
/*     */   public void setHeight(int value) {
/*  94 */     this._height = value;
/*     */   }
/*     */   public int getMinimumScale() {
/*  97 */     return this._minimumScale;
/*     */   }
/*     */ 
/*     */   public void setMinimumScale(int value) {
/* 101 */     this._minimumScale = value;
/*     */   }
/*     */ 
/*     */   public int getMaximumScale() {
/* 105 */     return this._maximumScale;
/*     */   }
/*     */ 
/*     */   public void setMaximumScale(int value) {
/* 109 */     this._maximumScale = value;
/*     */   }
/*     */ 
/*     */   public LeadRect getRectangle() {
/* 113 */     return this._rectangle;
/*     */   }
/*     */ 
/*     */   public void setRectangle(LeadRect value) {
/* 117 */     this._rectangle = value;
/*     */   }
/*     */ 
/*     */   public int getSearchMarkCount() {
/* 121 */     return this._searchMarkCount;
/*     */   }
/*     */ 
/*     */   public void setSearchMarkCount(int value) {
/* 125 */     this._searchMarkCount = value;
/*     */   }
/*     */ 
/*     */   public RegistrationMarkCommandType getType() {
/* 129 */     return RegistrationMarkCommandType.forValue(this._unmanaged._uType);
/*     */   }
/*     */ 
/*     */   public void setType(RegistrationMarkCommandType value) {
/* 133 */     this._unmanaged._uType = value.getValue();
/*     */   }
/*     */   public int getMarkDetectedCount() {
/* 136 */     return this._markDetectedCount;
/*     */   }
/*     */ 
/*     */   public void setMarkDetectedCount(int value) {
/* 140 */     this._markDetectedCount = value;
/*     */   }
/*     */ 
/*     */   public LeadPoint[] getMarkDetectedPoints() {
/* 144 */     return this._markDetectedPoints;
/*     */   }
/*     */ 
/*     */   public void setMarkDetectedPoints(LeadPoint[] value) {
/* 148 */     this._markDetectedPoints = value;
/* 149 */     this._markDetectedCount = (value != null ? value.length : 0);
/*     */   }
/*     */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.SearchRegistrationMarksCommandData
 * JD-Core Version:    0.6.2
 */