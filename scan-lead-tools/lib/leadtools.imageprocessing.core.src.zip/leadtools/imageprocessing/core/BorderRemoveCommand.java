/*     */ package leadtools.imageprocessing.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import leadtools.L_ERROR;
/*     */ import leadtools.LeadRect;
/*     */ import leadtools.RasterImage;
/*     */ import leadtools.RasterImageChangedFlags;
/*     */ import leadtools.RasterRegion;
/*     */ import leadtools.imageprocessing.RasterCommand;
/*     */ import leadtools.ltkrn;
/*     */ 
/*     */ public class BorderRemoveCommand extends RasterCommand
/*     */ {
/*     */   private int _flags;
/*     */   private int _border;
/*     */   private int _percent;
/*     */   private int _whiteNoiseLength;
/*     */   private int _variance;
/*     */   private RasterRegion _region;
/*     */   private RasterImage _imageRegion;
/*     */   private RasterImage _image;
/*     */   private ArrayList<BorderRemoveCommandListener> _borderRemove;
/*     */ 
/*     */   public void addBorderRemoveCommandListener(BorderRemoveCommandListener listener)
/*     */   {
/*  26 */     this._borderRemove.add(listener);
/*     */   }
/*     */ 
/*     */   public void removeBorderRemoveCommandListener(BorderRemoveCommandListener listener) {
/*  30 */     this._borderRemove.remove(listener);
/*     */   }
/*     */ 
/*     */   public int getFlags() {
/*  34 */     return this._flags;
/*     */   }
/*     */ 
/*     */   public void setFlags(int value) {
/*  38 */     this._flags = value;
/*     */   }
/*     */ 
/*     */   public int getBorder() {
/*  42 */     return this._border;
/*     */   }
/*     */ 
/*     */   public void setBorder(int value) {
/*  46 */     this._border = value;
/*     */   }
/*     */ 
/*     */   public int getPercent() {
/*  50 */     return this._percent;
/*     */   }
/*     */ 
/*     */   public void setPercent(int value) {
/*  54 */     this._percent = value;
/*     */   }
/*     */ 
/*     */   public int getWhiteNoiseLength() {
/*  58 */     return this._whiteNoiseLength;
/*     */   }
/*     */   public void setWhiteNoiseLength(int value) {
/*  61 */     this._whiteNoiseLength = value;
/*     */   }
/*     */ 
/*     */   public int getVariance() {
/*  65 */     return this._variance;
/*     */   }
/*     */   public void setVariance(int value) {
/*  68 */     this._variance = value;
/*     */   }
/*     */ 
/*     */   public RasterRegion getRegion() {
/*  72 */     return this._region;
/*     */   }
/*     */ 
/*     */   public RasterImage getImageRegion() {
/*  76 */     return this._imageRegion;
/*     */   }
/*     */ 
/*     */   public BorderRemoveCommand() {
/*  80 */     this._flags = BorderRemoveCommandFlags.NONE.getValue();
/*  81 */     this._border = BorderRemoveBorderFlags.ALL.getValue();
/*  82 */     this._percent = 20;
/*  83 */     this._whiteNoiseLength = 9;
/*  84 */     this._variance = 3;
/*  85 */     this._region = null;
/*  86 */     this._imageRegion = null;
/*  87 */     this._borderRemove = new ArrayList();
/*     */   }
/*     */ 
/*     */   public BorderRemoveCommand(int flags, int border, int percent, int whiteNoiseLength, int variance) {
/*  91 */     this._flags = flags;
/*  92 */     this._border = border;
/*  93 */     this._percent = percent;
/*  94 */     this._whiteNoiseLength = whiteNoiseLength;
/*  95 */     this._variance = variance;
/*     */ 
/*  97 */     this._region = null;
/*  98 */     this._imageRegion = null;
/*  99 */     this._borderRemove = new ArrayList();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 104 */     return "Border Remove";
/*     */   }
/*     */ 
/*     */   private final int DoCallback(int leadRegion, int uBorderToRemove, int left, int top, int right, int bottom)
/*     */   {
/* 110 */     int ret = L_ERROR.SUCCESS.getValue();
/*     */ 
/* 112 */     Iterator i$ = this._borderRemove.iterator(); if (i$.hasNext()) { BorderRemoveCommandListener listener = (BorderRemoveCommandListener)i$.next();
/* 113 */       LeadRect boundingLeadRect = LeadRect.fromLTRB(left, top, right, bottom);
/* 114 */       BorderRemoveCommandEvent args = new BorderRemoveCommandEvent(this, this._image, leadRegion != 0 ? new RasterRegion(leadRegion, false) : null, uBorderToRemove, boundingLeadRect);
/* 115 */       listener.onBorderRemoveEvent(args);
/* 116 */       return args.getStatus().getValue();
/*     */     }
/*     */ 
/* 119 */     return ret;
/*     */   }
/*     */ 
/*     */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*     */   {
/* 124 */     int ret = L_ERROR.SUCCESS.getValue();
/* 125 */     long RegionBitmap = 0L;
/*     */     try
/*     */     {
/* 128 */       this._image = image;
/* 129 */       BorderRemoveStruct br = new BorderRemoveStruct();
/*     */ 
/* 131 */       br._uFlags = this._flags;
/* 132 */       br._uBorderToRemove = this._border;
/* 133 */       br._iBorderPercent = this._percent;
/* 134 */       br._iWhiteNoiseLength = this._whiteNoiseLength;
/* 135 */       br._iVariance = this._variance;
/*     */ 
/* 137 */       if (((this._flags & BorderRemoveCommandFlags.SINGLE_REGION.getValue()) == BorderRemoveCommandFlags.SINGLE_REGION.getValue()) && ((this._flags & BorderRemoveCommandFlags.LEAD_REGION.getValue()) == BorderRemoveCommandFlags.LEAD_REGION.getValue()))
/*     */       {
/* 139 */         RegionBitmap = ltkrn.AllocBitmapHandle();
/* 140 */         br._bitmapRegion = RegionBitmap;
/*     */       }
/*     */ 
/* 143 */       ret = ltimgcor.BorderRemoveBitmap(bitmap, br, this._borderRemove.size() > 0 ? this : null, 0);
/* 144 */       if (ret == L_ERROR.SUCCESS.getValue()) {
/* 145 */         this._imageRegion = null;
/* 146 */         this._region = null;
/*     */ 
/* 149 */         if (((this._flags & BorderRemoveCommandFlags.SINGLE_REGION.getValue()) == BorderRemoveCommandFlags.SINGLE_REGION.getValue()) && ((this._flags & BorderRemoveCommandFlags.LEAD_REGION.getValue()) == BorderRemoveCommandFlags.LEAD_REGION.getValue()))
/*     */         {
/* 151 */           this._imageRegion = RasterImage.createFromBitmapHandle(RegionBitmap, true);
/*     */         }
/* 154 */         else if (((this._flags & BorderRemoveCommandFlags.SINGLE_REGION.getValue()) == BorderRemoveCommandFlags.SINGLE_REGION.getValue()) && 
/* 155 */           (br._uFlags != 0)) {
/* 156 */           this._region = new RasterRegion(br._hRgn, true);
/*     */         }
/*     */       }
/*     */ 
/* 160 */       return ret;
/*     */     }
/*     */     finally {
/* 163 */       if (RegionBitmap != 0L)
/* 164 */         ltkrn.FreeBitmapHandle(RegionBitmap);
/* 165 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.BorderRemoveCommand
 * JD-Core Version:    0.6.2
 */