/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum RegistrationMarkCommandType
/*    */ {
/*  4 */   T_SHAPE(0);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, RegistrationMarkCommandType> mappings;
/*    */ 
/*  9 */   private static HashMap<Integer, RegistrationMarkCommandType> getMappings() { if (mappings == null) {
/* 10 */       synchronized (RegistrationMarkCommandType.class) {
/* 11 */         if (mappings == null) {
/* 12 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 16 */     return mappings; }
/*    */ 
/*    */   private RegistrationMarkCommandType(int value)
/*    */   {
/* 20 */     this.intValue = value;
/* 21 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue() {
/* 25 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static RegistrationMarkCommandType forValue(int value) {
/* 29 */     return (RegistrationMarkCommandType)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.RegistrationMarkCommandType
 * JD-Core Version:    0.6.2
 */