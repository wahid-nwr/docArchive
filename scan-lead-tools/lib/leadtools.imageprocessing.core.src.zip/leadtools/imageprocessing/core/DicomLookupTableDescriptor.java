/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ public class DicomLookupTableDescriptor
/*    */ {
/*    */   private int _firstStoredPixelValueMapped;
/*    */   private int _entryBits;
/*    */ 
/*    */   public DicomLookupTableDescriptor()
/*    */   {
/*  8 */     this._firstStoredPixelValueMapped = 0;
/*  9 */     this._entryBits = 0;
/*    */   }
/*    */ 
/*    */   public DicomLookupTableDescriptor(int firstStoredPixelValueMapped, int entryBits) {
/* 13 */     this._firstStoredPixelValueMapped = firstStoredPixelValueMapped;
/* 14 */     this._entryBits = entryBits;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 19 */     return "Dicom Lookup Table Descriptor";
/*    */   }
/*    */ 
/*    */   public int getFirstStoredPixelValueMapped() {
/* 23 */     return this._firstStoredPixelValueMapped;
/*    */   }
/*    */ 
/*    */   public void setFirstStoredPixelValueMapped(int value) {
/* 27 */     this._firstStoredPixelValueMapped = value;
/*    */   }
/*    */ 
/*    */   public int getEntryBits() {
/* 31 */     return this._entryBits;
/*    */   }
/*    */ 
/*    */   public void setEntryBits(int value) {
/* 35 */     this._entryBits = value;
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.DicomLookupTableDescriptor
 * JD-Core Version:    0.6.2
 */