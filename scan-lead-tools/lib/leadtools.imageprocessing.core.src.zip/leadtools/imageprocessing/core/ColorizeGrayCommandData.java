/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.RasterColor;
/*    */ 
/*    */ public class ColorizeGrayCommandData
/*    */ {
/*    */   private RasterColor _color;
/*    */   private int _threshold;
/*    */ 
/*    */   private void setColorData(RasterColor color, int threshold)
/*    */   {
/* 10 */     this._color = color;
/* 11 */     this._threshold = threshold;
/*    */   }
/*    */ 
/*    */   public ColorizeGrayCommandData() {
/* 15 */     this._color = new RasterColor();
/* 16 */     this._color.setR((byte)0);
/* 17 */     this._color.setG((byte)0);
/* 18 */     this._color.setB((byte)0);
/* 19 */     this._threshold = 128;
/*    */   }
/*    */ 
/*    */   public ColorizeGrayCommandData(RasterColor color, int threshold) {
/* 23 */     setColorData(color, threshold);
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 28 */     StringBuilder s = new StringBuilder();
/* 29 */     s.append(this._color.toString());
/* 30 */     s.append(String.format(", Threshold : %1$s", new Object[] { new Integer(this._threshold).toString() }));
/* 31 */     return s.toString();
/*    */   }
/*    */ 
/*    */   public RasterColor getColor() {
/* 35 */     return this._color;
/*    */   }
/*    */ 
/*    */   public void setColor(RasterColor value) {
/* 39 */     this._color = value;
/*    */   }
/*    */ 
/*    */   public int getThreshold() {
/* 43 */     return this._threshold;
/*    */   }
/*    */ 
/*    */   public void setThreshold(int value) {
/* 47 */     this._threshold = value;
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.ColorizeGrayCommandData
 * JD-Core Version:    0.6.2
 */