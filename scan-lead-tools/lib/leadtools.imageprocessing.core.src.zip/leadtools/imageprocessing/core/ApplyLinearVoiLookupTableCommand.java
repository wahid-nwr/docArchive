/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class ApplyLinearVoiLookupTableCommand extends RasterCommand
/*    */ {
/*    */   private double _center;
/*    */   private double _width;
/*    */   private int _flags;
/*    */ 
/*    */   public ApplyLinearVoiLookupTableCommand()
/*    */   {
/* 14 */     this._center = 1200.0D;
/* 15 */     this._width = 1200.0D;
/* 16 */     this._flags = VoiLookupTableCommandFlags.NONE.getValue();
/*    */   }
/*    */ 
/*    */   public ApplyLinearVoiLookupTableCommand(double center, double width, int flags) {
/* 20 */     this._center = center;
/* 21 */     this._width = width;
/* 22 */     this._flags = flags;
/*    */   }
/*    */ 
/*    */   public int getFlags() {
/* 26 */     return this._flags;
/*    */   }
/*    */ 
/*    */   public void setFlags(int value) {
/* 30 */     this._flags = value;
/*    */   }
/*    */ 
/*    */   public double getCenter() {
/* 34 */     return this._center;
/*    */   }
/*    */ 
/*    */   public void setCenter(double value) {
/* 38 */     this._center = value;
/*    */   }
/*    */ 
/*    */   public double getWidth() {
/* 42 */     return this._width;
/*    */   }
/*    */ 
/*    */   public void setWidth(double value) {
/* 46 */     this._width = value;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 51 */     return "ApplyLinearVoiLookupTableCommand";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 56 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 59 */       ret = ltimgcor.ApplyLinearVOILUT(bitmap, this._center, this._width, this._flags);
/* 60 */       return ret;
/*    */     }
/*    */     finally {
/* 63 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.ApplyLinearVoiLookupTableCommand
 * JD-Core Version:    0.6.2
 */