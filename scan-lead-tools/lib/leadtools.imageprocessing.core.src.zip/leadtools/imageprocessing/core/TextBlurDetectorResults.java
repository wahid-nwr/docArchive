/*     */ package leadtools.imageprocessing.core;
/*     */ 
/*     */ import leadtools.LeadRect;
/*     */ 
/*     */ class TextBlurDetectorResults
/*     */ {
/*     */   int _nonBlurredBlockCount;
/*     */   int _blurredBlockCount;
/*     */   LeadRect[] _nonBlurredBlocks;
/*     */   LeadRect[] _blurredBlocks;
/*     */   LeadRect _combinedTextBlocks;
/*     */ 
/*     */   public TextBlurDetectorResults(int nonBlurredBlockCount, int blurredBlockCount, int left, int top, int right, int bottom)
/*     */   {
/*  79 */     this._nonBlurredBlockCount = nonBlurredBlockCount;
/*  80 */     if (this._nonBlurredBlockCount > 0)
/*  81 */       this._nonBlurredBlocks = new LeadRect[this._nonBlurredBlockCount];
/*     */     else {
/*  83 */       this._nonBlurredBlocks = null;
/*     */     }
/*  85 */     this._blurredBlockCount = blurredBlockCount;
/*  86 */     if (this._blurredBlockCount > 0)
/*  87 */       this._blurredBlocks = new LeadRect[this._blurredBlockCount];
/*     */     else {
/*  89 */       this._blurredBlocks = null;
/*     */     }
/*  91 */     this._combinedTextBlocks = LeadRect.fromLTRB(left, top, right, bottom);
/*     */   }
/*     */ 
/*     */   public void setNonBlurredBlocks(int index, int left, int top, int right, int bottom) {
/*  95 */     if ((index < 0) || (index >= this._nonBlurredBlockCount)) {
/*  96 */       return;
/*     */     }
/*  98 */     this._nonBlurredBlocks[index] = LeadRect.fromLTRB(left, top, right, bottom);
/*     */   }
/*     */ 
/*     */   public void setBlurredBlocks(int index, int left, int top, int right, int bottom) {
/* 102 */     if ((index < 0) || (index >= this._blurredBlockCount)) {
/* 103 */       return;
/*     */     }
/* 105 */     this._blurredBlocks[index] = LeadRect.fromLTRB(left, top, right, bottom);
/*     */   }
/*     */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.TextBlurDetectorResults
 * JD-Core Version:    0.6.2
 */