/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class DespeckleCommand extends RasterCommand
/*    */ {
/*    */   public String toString()
/*    */   {
/* 14 */     return "Despeckle";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 19 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 22 */       ret = ltimgcor.DespeckleBitmap(bitmap, 0);
/* 23 */       return ret;
/*    */     }
/*    */     finally {
/* 26 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.DespeckleCommand
 * JD-Core Version:    0.6.2
 */