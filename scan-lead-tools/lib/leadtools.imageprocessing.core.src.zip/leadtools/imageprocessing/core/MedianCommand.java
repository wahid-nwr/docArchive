/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class MedianCommand extends RasterCommand
/*    */ {
/*    */   private int _dimension;
/*    */ 
/*    */   public MedianCommand()
/*    */   {
/* 12 */     this._dimension = 0;
/*    */   }
/*    */ 
/*    */   public MedianCommand(int dimension) {
/* 16 */     this._dimension = dimension;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 21 */     return "Median";
/*    */   }
/*    */ 
/*    */   public int getDimension() {
/* 25 */     return this._dimension;
/*    */   }
/*    */ 
/*    */   public void setDimension(int value) {
/* 29 */     this._dimension = value;
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 34 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 37 */       ret = ltimgcor.MedianFilterBitmap(bitmap, this._dimension, 0);
/* 38 */       return ret;
/*    */     }
/*    */     finally {
/* 41 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.MedianCommand
 * JD-Core Version:    0.6.2
 */