/*     */ package leadtools.imageprocessing.core;
/*     */ 
/*     */ class SmoothStruct
/*     */ {
/*     */   public int _uFlags;
/*     */   public int _iLength;
/*     */   public long _bitmapRegion;
/*     */   public long _rgn;
/*     */   public long _leadregion;
/*     */ 
/*     */   public SmoothStruct()
/*     */   {
/* 147 */     this._uFlags = 0;
/* 148 */     this._iLength = 0;
/* 149 */     this._bitmapRegion = 0L;
/* 150 */     this._rgn = 0L;
/* 151 */     this._leadregion = 0L;
/*     */   }
/*     */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.SmoothStruct
 * JD-Core Version:    0.6.2
 */