/*     */ package leadtools.imageprocessing.core;
/*     */ 
/*     */ class InvertedTextStruct
/*     */ {
/*     */   public int _uFlags;
/*     */   public int _iMinInvertWidth;
/*     */   public int _iMinInvertHeight;
/*     */   public int _iMinBlackPercent;
/*     */   public int _iMaxBlackPercent;
/*     */   public long _bitmapRegion;
/*     */   public long _rgn;
/*     */   public long _leadregion;
/*     */ 
/*     */   public InvertedTextStruct()
/*     */   {
/* 186 */     this._uFlags = 0;
/* 187 */     this._iMinInvertWidth = 0;
/* 188 */     this._iMinInvertHeight = 0;
/* 189 */     this._iMinBlackPercent = 0;
/* 190 */     this._iMaxBlackPercent = 0;
/* 191 */     this._bitmapRegion = 0L;
/* 192 */     this._rgn = 0L;
/* 193 */     this._leadregion = 0L;
/*     */   }
/*     */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.InvertedTextStruct
 * JD-Core Version:    0.6.2
 */