/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class AutoDocumentBinarizationCommand extends RasterCommand
/*    */ {
/*    */   public String toString()
/*    */   {
/* 13 */     return "AutoDocumentBinarization";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 18 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 21 */       ret = ltimgcor.AutoDocumentBinarization(bitmap);
/* 22 */       return ret;
/*    */     }
/*    */     finally {
/* 25 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.AutoDocumentBinarizationCommand
 * JD-Core Version:    0.6.2
 */