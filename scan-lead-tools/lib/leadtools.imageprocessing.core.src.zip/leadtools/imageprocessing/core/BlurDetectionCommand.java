/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class BlurDetectionCommand extends RasterCommand
/*    */ {
/*    */   private boolean _blurred;
/*    */   private double _blurextent;
/*    */ 
/*    */   public BlurDetectionCommand()
/*    */   {
/* 14 */     this._blurred = false;
/* 15 */     this._blurextent = 1.0D;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 20 */     return "Blur Detection Command";
/*    */   }
/*    */ 
/*    */   public boolean getBlurred() {
/* 24 */     return this._blurred;
/*    */   }
/*    */ 
/*    */   public double getBlurExtent() {
/* 28 */     return this._blurextent;
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 33 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 36 */       boolean[] blurredResult = new boolean[1];
/* 37 */       double[] blurExtentResult = new double[1];
/*    */ 
/* 39 */       blurredResult[0] = false;
/* 40 */       blurExtentResult[0] = 0.0D;
/*    */ 
/* 42 */       ret = ltimgcor.BlurDetection(bitmap, blurredResult, blurExtentResult);
/* 43 */       if (ret == L_ERROR.SUCCESS.getValue()) {
/* 44 */         this._blurred = blurredResult[0];
/* 45 */         this._blurextent = blurExtentResult[0];
/*    */       }
/*    */ 
/* 48 */       return ret;
/*    */     }
/*    */     finally {
/* 51 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.BlurDetectionCommand
 * JD-Core Version:    0.6.2
 */