/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class BlankPageDetectorCommand extends RasterCommand
/*    */ {
/*    */   private boolean _isblank;
/*    */   private int _accuracy;
/*    */   private int _leftmargin;
/*    */   private int _topmargin;
/*    */   private int _rightmargin;
/*    */   private int _bottommargin;
/*    */   private int _flags;
/*    */ 
/*    */   public boolean isBlank()
/*    */   {
/* 18 */     return this._isblank;
/*    */   }
/*    */ 
/*    */   public int getAccuracy() {
/* 22 */     return this._accuracy;
/*    */   }
/*    */ 
/*    */   public int getLeftMargin() {
/* 26 */     return this._leftmargin;
/*    */   }
/*    */ 
/*    */   public void setLeftMargin(int value) {
/* 30 */     this._leftmargin = value;
/*    */   }
/*    */ 
/*    */   public int getTopMargin() {
/* 34 */     return this._topmargin;
/*    */   }
/*    */ 
/*    */   public void setTopMargin(int value) {
/* 38 */     this._topmargin = value;
/*    */   }
/*    */ 
/*    */   public int getRightMargin() {
/* 42 */     return this._rightmargin;
/*    */   }
/*    */ 
/*    */   public void setRightMargin(int value) {
/* 46 */     this._rightmargin = value;
/*    */   }
/*    */ 
/*    */   public int getBottomMargin() {
/* 50 */     return this._bottommargin;
/*    */   }
/*    */ 
/*    */   public void setBottomMargin(int value) {
/* 54 */     this._bottommargin = value;
/*    */   }
/*    */ 
/*    */   public int getFlags() {
/* 58 */     return this._flags;
/*    */   }
/*    */ 
/*    */   public void setFlags(int value) {
/* 62 */     this._flags = value;
/*    */   }
/*    */ 
/*    */   public BlankPageDetectorCommand() {
/* 66 */     this._isblank = false;
/* 67 */     this._accuracy = 0;
/* 68 */     this._leftmargin = 0;
/* 69 */     this._topmargin = 0;
/* 70 */     this._rightmargin = 0;
/* 71 */     this._bottommargin = 0;
/* 72 */     this._flags = (BlankPageDetectorCommandFlags.DETECT_NOISY_PAGE.getValue() | BlankPageDetectorCommandFlags.DONT_USE_BLEED_THROUGH.getValue() | BlankPageDetectorCommandFlags.USE_DEFAULT_MARGINS.getValue());
/*    */   }
/*    */ 
/*    */   public BlankPageDetectorCommand(int flags, int LeftMargin, int TopMargin, int RightMargin, int BottomMargin) {
/* 76 */     this._flags = flags;
/* 77 */     this._isblank = false;
/* 78 */     this._accuracy = 0;
/* 79 */     this._leftmargin = LeftMargin;
/* 80 */     this._topmargin = TopMargin;
/* 81 */     this._rightmargin = RightMargin;
/* 82 */     this._bottommargin = BottomMargin;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 87 */     return "Blank Page Detector";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 92 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 95 */       PageMarginsStruct pageMargin = new PageMarginsStruct();
/* 96 */       pageMargin.setBottomMargin(this._bottommargin);
/* 97 */       pageMargin.setTopMargin(this._topmargin);
/* 98 */       pageMargin.setLeftMargin(this._leftmargin);
/* 99 */       pageMargin.setRightMargin(this._rightmargin);
/*    */ 
/* 101 */       boolean[] isBlank = new boolean[1];
/* 102 */       int[] accuracy = new int[1];
/*    */ 
/* 104 */       ret = ltimgcor.BlankPageDetectorBitmap(bitmap, isBlank, accuracy, pageMargin, this._flags);
/* 105 */       if (ret == L_ERROR.SUCCESS.getValue()) {
/* 106 */         this._isblank = isBlank[0];
/* 107 */         this._accuracy = accuracy[0];
/*    */       }
/* 109 */       return ret;
/*    */     }
/*    */     finally {
/* 112 */       image.updateCurrentBitmapHandle();
/* 113 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.BlankPageDetectorCommand
 * JD-Core Version:    0.6.2
 */