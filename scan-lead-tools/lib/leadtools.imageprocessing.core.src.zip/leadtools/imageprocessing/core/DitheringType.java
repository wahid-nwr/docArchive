/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum DitheringType
/*    */ {
/*  4 */   UNDITHERED(0), 
/*  5 */   TEXT_DITHER(1), 
/*  6 */   WHITE_DITHER(2);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, DitheringType> mappings;
/*    */ 
/* 12 */   private static HashMap<Integer, DitheringType> getMappings() { if (mappings == null)
/*    */     {
/* 14 */       synchronized (DitheringType.class)
/*    */       {
/* 16 */         if (mappings == null)
/*    */         {
/* 18 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 22 */     return mappings; }
/*    */ 
/*    */   private DitheringType(int value)
/*    */   {
/* 26 */     this.intValue = value;
/* 27 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue() {
/* 31 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static DitheringType forValue(int value)
/*    */   {
/* 36 */     return (DitheringType)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.DitheringType
 * JD-Core Version:    0.6.2
 */