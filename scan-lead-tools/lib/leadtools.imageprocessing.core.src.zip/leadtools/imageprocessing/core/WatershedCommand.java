/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.LeadPoint;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class WatershedCommand extends RasterCommand
/*    */ {
/*    */   private ArrayList<ArrayList<LeadPoint>> _pointsArray;
/*    */ 
/*    */   public WatershedCommand()
/*    */   {
/* 16 */     this._pointsArray = null;
/*    */   }
/*    */ 
/*    */   public WatershedCommand(ArrayList<ArrayList<LeadPoint>> pointsArray) {
/* 20 */     this._pointsArray = pointsArray;
/*    */   }
/*    */ 
/*    */   public ArrayList<ArrayList<LeadPoint>> getPointsArray() {
/* 24 */     return this._pointsArray;
/*    */   }
/*    */ 
/*    */   public void setPointsArray(ArrayList<ArrayList<LeadPoint>> value) {
/* 28 */     this._pointsArray = value;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 33 */     return "WatershedCommand";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 38 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 41 */       if (this._pointsArray == null) {
/* 42 */         return L_ERROR.ERROR_INV_PARAMETER.getValue();
/*    */       }
/* 44 */       int nSize = this._pointsArray.size();
/* 45 */       WatershedPoints points = new WatershedPoints(nSize);
/*    */ 
/* 47 */       for (int i = 0; i < nSize; i++) {
/* 48 */         LeadPoint[] tempPoints = new LeadPoint[((ArrayList)this._pointsArray.get(i)).size()];
/* 49 */         points.setPoints(i, (LeadPoint[])((ArrayList)this._pointsArray.get(i)).toArray(tempPoints));
/*    */       }
/*    */ 
/* 52 */       ret = ltimgcor.WatershedBitmap(bitmap, points);
/*    */ 
/* 58 */       return ret;
/*    */     }
/*    */     finally {
/* 61 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.WatershedCommand
 * JD-Core Version:    0.6.2
 */