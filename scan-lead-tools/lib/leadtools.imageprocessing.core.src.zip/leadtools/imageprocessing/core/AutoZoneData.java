/*     */ package leadtools.imageprocessing.core;
/*     */ 
/*     */ import leadtools.LeadRect;
/*     */ 
/*     */ class AutoZoneData
/*     */ {
/*     */   public LEADZONEDATA[] _zones;
/*     */   public int _count;
/*     */   public int _ditheringType;
/*     */   public int _dotMatrixType;
/*     */   public LeadRect[] _undelineRects;
/*     */   public int _underLineCount;
/*     */   public LeadRect[] _checkBoxesRects;
/*     */   public int _checkBoxesCount;
/*     */   public int[] _underLinesType;
/*     */ 
/*     */   public AutoZoneData()
/*     */   {
/* 353 */     this._zones = null;
/* 354 */     this._count = 0;
/* 355 */     this._ditheringType = 0;
/* 356 */     this._dotMatrixType = 0;
/* 357 */     this._undelineRects = null;
/* 358 */     this._underLineCount = 0;
/* 359 */     this._checkBoxesRects = null;
/* 360 */     this._underLinesType = null;
/* 361 */     this._checkBoxesCount = 0;
/*     */   }
/*     */ 
/*     */   public void Init(int zoneCount, int underlineCount, int checkBoxesCount) {
/* 365 */     this._count = zoneCount;
/* 366 */     this._ditheringType = 0;
/* 367 */     this._dotMatrixType = 0;
/* 368 */     this._underLineCount = underlineCount;
/* 369 */     this._underLineCount = checkBoxesCount;
/*     */ 
/* 371 */     if (zoneCount > 0) {
/* 372 */       this._zones = new LEADZONEDATA[zoneCount];
/* 373 */       for (int i = 0; i < zoneCount; i++) {
/* 374 */         this._zones[i] = new LEADZONEDATA();
/*     */       }
/*     */     }
/* 377 */     if (underlineCount > 0) {
/* 378 */       this._undelineRects = new LeadRect[underlineCount];
/* 379 */       this._underLinesType = new int[underlineCount];
/*     */     }
/*     */ 
/* 382 */     if (checkBoxesCount > 0)
/* 383 */       this._checkBoxesRects = new LeadRect[checkBoxesCount];
/*     */   }
/*     */ 
/*     */   public void setRect(int left, int top, int right, int bottom, int index)
/*     */   {
/* 388 */     this._undelineRects[index] = LeadRect.fromLTRB(left, top, right, bottom);
/*     */   }
/*     */ 
/*     */   public void setCheckBoxRect(int left, int top, int right, int bottom, int index) {
/* 392 */     this._checkBoxesRects[index] = LeadRect.fromLTRB(left, top, right, bottom);
/*     */   }
/*     */ 
/*     */   public void setUnderlineType(int index, int value) {
/* 396 */     this._underLinesType[index] = value;
/*     */   }
/*     */ 
/*     */   public LEADZONEDATA getData(int index) {
/* 400 */     return this._zones[index];
/*     */   }
/*     */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.AutoZoneData
 * JD-Core Version:    0.6.2
 */