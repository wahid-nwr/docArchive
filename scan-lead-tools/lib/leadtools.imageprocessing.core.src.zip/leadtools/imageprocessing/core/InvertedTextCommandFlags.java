/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum InvertedTextCommandFlags
/*    */ {
/*  5 */   None(0), 
/*  6 */   USE_DPI(1), 
/*  7 */   SINGLE_REGION(2), 
/*  8 */   LEAD_REGION(4), 
/*  9 */   CALLBACK_REGION(8), 
/* 10 */   IMAGE_UNCHANGED(16), 
/* 11 */   USE_DIAGONALS(4096);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, InvertedTextCommandFlags> mappings;
/*    */ 
/* 17 */   private static HashMap<Integer, InvertedTextCommandFlags> getMappings() { if (mappings == null)
/*    */     {
/* 19 */       synchronized (InvertedTextCommandFlags.class)
/*    */       {
/* 21 */         if (mappings == null)
/*    */         {
/* 23 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 27 */     return mappings;
/*    */   }
/*    */ 
/*    */   private InvertedTextCommandFlags(int value)
/*    */   {
/* 32 */     this.intValue = value;
/* 33 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue()
/*    */   {
/* 38 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static InvertedTextCommandFlags forValue(int value)
/*    */   {
/* 43 */     return (InvertedTextCommandFlags)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.InvertedTextCommandFlags
 * JD-Core Version:    0.6.2
 */