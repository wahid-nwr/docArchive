package leadtools.imageprocessing.core;

public abstract interface InvertedTextCommandListener
{
  public abstract void onInvertedTextEvent(InvertedTextCommandEvent paramInvertedTextCommandEvent);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.InvertedTextCommandListener
 * JD-Core Version:    0.6.2
 */