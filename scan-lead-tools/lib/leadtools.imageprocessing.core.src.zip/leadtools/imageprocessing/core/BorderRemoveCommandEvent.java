/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.LeadEvent;
/*    */ import leadtools.LeadRect;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterRegion;
/*    */ 
/*    */ public class BorderRemoveCommandEvent extends LeadEvent
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private RasterImage _image;
/*    */   private RasterRegion _region;
/*    */   private int _border;
/*    */   private LeadRect _boundingRectangle;
/*    */   private RemoveStatus _status;
/*    */ 
/*    */   public BorderRemoveCommandEvent(Object source, RasterImage image, RasterRegion region, int border, LeadRect boundingRectangle)
/*    */   {
/* 17 */     super(source);
/* 18 */     this._image = image;
/* 19 */     this._region = region;
/* 20 */     this._border = border;
/* 21 */     this._boundingRectangle = boundingRectangle;
/* 22 */     this._status = RemoveStatus.REMOVE;
/*    */   }
/*    */ 
/*    */   public RasterImage getImage() {
/* 26 */     return this._image;
/*    */   }
/*    */ 
/*    */   public RasterRegion getRegion() {
/* 30 */     return this._region;
/*    */   }
/*    */ 
/*    */   public int getBorder() {
/* 34 */     return this._border;
/*    */   }
/*    */ 
/*    */   public LeadRect getBoundingRectangle() {
/* 38 */     return this._boundingRectangle;
/*    */   }
/*    */ 
/*    */   public RemoveStatus getStatus() {
/* 42 */     return this._status;
/*    */   }
/*    */ 
/*    */   public void setStatus(RemoveStatus value) {
/* 46 */     this._status = value;
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.BorderRemoveCommandEvent
 * JD-Core Version:    0.6.2
 */