/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class GetLinearVoiLookupTableCommand extends RasterCommand
/*    */ {
/*    */   private double _center;
/*    */   private double _width;
/*    */   private int _flags;
/*    */ 
/*    */   public GetLinearVoiLookupTableCommand()
/*    */   {
/* 14 */     this._center = 0.0D;
/* 15 */     this._width = 0.0D;
/* 16 */     this._flags = GetLinearVoiLookupTableCommandFlags.NONE.getValue();
/*    */   }
/*    */ 
/*    */   public GetLinearVoiLookupTableCommand(int flags) {
/* 20 */     this._center = 0.0D;
/* 21 */     this._width = 0.0D;
/* 22 */     this._flags = flags;
/*    */   }
/*    */ 
/*    */   public double getCenter() {
/* 26 */     return this._center;
/*    */   }
/*    */ 
/*    */   public double getWidth() {
/* 30 */     return this._width;
/*    */   }
/*    */ 
/*    */   public int getFlags() {
/* 34 */     return this._flags;
/*    */   }
/*    */ 
/*    */   public void setFlags(int value) {
/* 38 */     this._flags = value;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 43 */     return "Get Linear VOI LookupTable";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 48 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 51 */       double[] center = new double[1];
/* 52 */       double[] width = new double[1];
/* 53 */       ret = ltimgcor.GetLinearVOILUT(bitmap, center, width, this._flags);
/* 54 */       if (ret == L_ERROR.SUCCESS.getValue()) {
/* 55 */         this._center = center[0];
/* 56 */         this._width = width[0];
/*    */       }
/*    */ 
/* 59 */       return ret;
/*    */     }
/*    */     finally {
/* 62 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.GetLinearVoiLookupTableCommand
 * JD-Core Version:    0.6.2
 */