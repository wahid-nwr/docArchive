/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class MinimumToZeroCommand extends RasterCommand
/*    */ {
/*    */   private int _shiftAmount;
/*    */ 
/*    */   public int getShiftAmount()
/*    */   {
/* 12 */     return this._shiftAmount;
/*    */   }
/*    */ 
/*    */   public MinimumToZeroCommand() {
/* 16 */     this._shiftAmount = 0;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 21 */     return "Shift Minimum to Zero";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 26 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 29 */       int[] shiftAmount = new int[1];
/* 30 */       ret = ltimgcor.ShiftMinimumToZero(bitmap, shiftAmount, 0);
/*    */ 
/* 32 */       if (ret == L_ERROR.SUCCESS.getValue())
/* 33 */         this._shiftAmount = shiftAmount[0];
/* 34 */       return ret;
/*    */     }
/*    */     finally {
/* 37 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.MinimumToZeroCommand
 * JD-Core Version:    0.6.2
 */