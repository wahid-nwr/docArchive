/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum HalfToneCommandType
/*    */ {
/*  4 */   PRINT(0), 
/*  5 */   VIEW(1), 
/*  6 */   RECTANGULAR(2), 
/*  7 */   CIRCULAR(3), 
/*  8 */   ELLIPTICAL(4), 
/*  9 */   RANDOM(5), 
/* 10 */   LINEAR(6), 
/* 11 */   USER_DEFINED(7);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, HalfToneCommandType> mappings;
/*    */ 
/* 17 */   private static HashMap<Integer, HalfToneCommandType> getMappings() { if (mappings == null)
/*    */     {
/* 19 */       synchronized (HalfToneCommandType.class)
/*    */       {
/* 21 */         if (mappings == null)
/*    */         {
/* 23 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 27 */     return mappings;
/*    */   }
/*    */ 
/*    */   private HalfToneCommandType(int value)
/*    */   {
/* 32 */     this.intValue = value;
/* 33 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue()
/*    */   {
/* 38 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static HalfToneCommandType forValue(int value)
/*    */   {
/* 43 */     return (HalfToneCommandType)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.HalfToneCommandType
 * JD-Core Version:    0.6.2
 */