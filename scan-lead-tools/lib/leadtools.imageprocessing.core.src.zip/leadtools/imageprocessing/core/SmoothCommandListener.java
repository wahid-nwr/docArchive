package leadtools.imageprocessing.core;

public abstract interface SmoothCommandListener
{
  public abstract void onSmoothEvent(SmoothCommandEvent paramSmoothCommandEvent);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.SmoothCommandListener
 * JD-Core Version:    0.6.2
 */