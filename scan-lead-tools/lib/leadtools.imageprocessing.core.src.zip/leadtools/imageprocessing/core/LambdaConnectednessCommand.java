/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class LambdaConnectednessCommand extends RasterCommand
/*    */ {
/*    */   private int _lambda;
/*    */ 
/*    */   public LambdaConnectednessCommand()
/*    */   {
/* 13 */     this._lambda = 5;
/*    */   }
/*    */ 
/*    */   public LambdaConnectednessCommand(int Lambda) {
/* 17 */     this._lambda = Lambda;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 22 */     return "LambdaConnectednessCommand";
/*    */   }
/*    */ 
/*    */   public int getLambda() {
/* 26 */     return this._lambda;
/*    */   }
/*    */ 
/*    */   public void setLambda(int value) {
/* 30 */     this._lambda = value;
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 35 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 38 */       ret = ltimgcor.LambdaConnectedness(bitmap, this._lambda);
/* 39 */       return ret;
/*    */     }
/*    */     finally {
/* 42 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.LambdaConnectednessCommand
 * JD-Core Version:    0.6.2
 */