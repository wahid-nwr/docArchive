/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class CLAHECommand extends RasterCommand
/*    */ {
/*    */   private float _alpha;
/*    */   private int _tilesize;
/*    */   private int _binsnumber;
/*    */   private float _tilehistcliplimit;
/*    */   private int _flags;
/*    */ 
/*    */   public CLAHECommand()
/*    */   {
/* 17 */     this._tilesize = 6;
/* 18 */     this._alpha = 0.65F;
/* 19 */     this._tilehistcliplimit = 0.08F;
/* 20 */     this._binsnumber = 128;
/* 21 */     this._flags = CLAHECommandFlags.APPLY_RAYLIEH_DISTRIBUTION.getValue();
/*    */   }
/*    */ 
/*    */   public CLAHECommand(float alpha, int tileSize, float tileHistClipLimit, int binNumber, int flags) {
/* 25 */     this._tilesize = tileSize;
/* 26 */     this._tilehistcliplimit = tileHistClipLimit;
/* 27 */     this._binsnumber = binNumber;
/* 28 */     this._alpha = alpha;
/* 29 */     this._flags = flags;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 34 */     return "Contrast Limited Adaptive Histogram Equalization";
/*    */   }
/*    */ 
/*    */   public void setTilesNumber(int value) {
/* 38 */     this._tilesize = value;
/*    */   }
/*    */   public int getTilesNumber() {
/* 41 */     return this._tilesize;
/*    */   }
/*    */ 
/*    */   public void setAlphaFactor(float value) {
/* 45 */     this._alpha = value;
/*    */   }
/*    */   public float getAlphaFactor() {
/* 48 */     return this._alpha;
/*    */   }
/*    */ 
/*    */   public void setTileHistClipLimit(float value) {
/* 52 */     this._tilehistcliplimit = value;
/*    */   }
/*    */   public float getTileHistClipLimit() {
/* 55 */     return this._tilehistcliplimit;
/*    */   }
/*    */ 
/*    */   public void setBinNumber(int value) {
/* 59 */     this._binsnumber = value;
/*    */   }
/*    */   public int getBinNumber() {
/* 62 */     return this._binsnumber;
/*    */   }
/*    */ 
/*    */   public void setFlags(int value) {
/* 66 */     this._flags = value;
/*    */   }
/*    */   public int getFlags() {
/* 69 */     return this._flags;
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 74 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 77 */       ret = ltimgcor.CLAHE(bitmap, this._alpha, this._tilesize, this._tilehistcliplimit, this._binsnumber, this._flags);
/* 78 */       return ret;
/*    */     }
/*    */     finally {
/* 81 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.CLAHECommand
 * JD-Core Version:    0.6.2
 */