/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum OmrZoneState
/*    */ {
/*  4 */   UNFILLED(0), 
/*  5 */   FILLED(1);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, OmrZoneState> mappings;
/*    */ 
/* 10 */   private static HashMap<Integer, OmrZoneState> getMappings() { if (mappings == null) {
/* 11 */       synchronized (OmrZoneState.class) {
/* 12 */         if (mappings == null) {
/* 13 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 17 */     return mappings; }
/*    */ 
/*    */   private OmrZoneState(int value)
/*    */   {
/* 21 */     this.intValue = value;
/* 22 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue() {
/* 26 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static OmrZoneState forValue(int value) {
/* 30 */     return (OmrZoneState)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.OmrZoneState
 * JD-Core Version:    0.6.2
 */