/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum AutoBinarizeCommandFlags
/*    */ {
/*  5 */   USE_AUTO_PRE_PROCESSING(0), 
/*  6 */   DONT_USE_PRE_PROCESSING(1), 
/*  7 */   USE_BACK_GROUND_ELIMINATION(2), 
/*  8 */   USE_COLOR_LEVELING(4), 
/*  9 */   USE_AUTO_THRESHOLD(0), 
/* 10 */   USE_USER_THRESHOLD(16), 
/* 11 */   USE_PERCENTILE_THRESHOLD(32), 
/* 12 */   USE_MEDIAN_THRESHOLD(64);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, AutoBinarizeCommandFlags> mappings;
/*    */ 
/* 18 */   private static HashMap<Integer, AutoBinarizeCommandFlags> getMappings() { if (mappings == null)
/*    */     {
/* 20 */       synchronized (AutoBinarizeCommandFlags.class)
/*    */       {
/* 22 */         if (mappings == null)
/*    */         {
/* 24 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 28 */     return mappings;
/*    */   }
/*    */ 
/*    */   private AutoBinarizeCommandFlags(int value)
/*    */   {
/* 33 */     this.intValue = value;
/* 34 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue()
/*    */   {
/* 39 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static AutoBinarizeCommandFlags forValue(int value)
/*    */   {
/* 44 */     return (AutoBinarizeCommandFlags)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.AutoBinarizeCommandFlags
 * JD-Core Version:    0.6.2
 */