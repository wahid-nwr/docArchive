/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.LeadRect;
/*    */ 
/*    */ public class LeadZone
/*    */ {
/*    */   private LeadZoneType _type;
/*    */   private LeadRect _bounds;
/*    */   private LeadZoneTableData _tableData;
/*    */   private LeadZoneTextData _textData;
/*    */ 
/*    */   public LeadZone()
/*    */   {
/* 13 */     this._type = LeadZoneType.GRAPHIC;
/* 14 */     this._bounds = new LeadRect(0, 0, 0, 0);
/* 15 */     this._tableData = null;
/* 16 */     this._textData = null;
/*    */   }
/*    */ 
/*    */   public LeadZoneType getType() {
/* 20 */     return this._type;
/*    */   }
/*    */ 
/*    */   public void setType(LeadZoneType value) {
/* 24 */     this._type = value;
/*    */   }
/*    */ 
/*    */   public LeadRect getBounds() {
/* 28 */     return this._bounds;
/*    */   }
/*    */ 
/*    */   public void setBounds(LeadRect value) {
/* 32 */     this._bounds = value;
/*    */   }
/*    */ 
/*    */   public LeadZoneTableData getTableData()
/*    */   {
/* 37 */     return this._tableData;
/*    */   }
/*    */ 
/*    */   public void setTableData(LeadZoneTableData value) {
/* 41 */     this._tableData = value;
/*    */   }
/*    */ 
/*    */   public LeadZoneTextData getTextData()
/*    */   {
/* 46 */     return this._textData;
/*    */   }
/*    */ 
/*    */   public void setTextData(LeadZoneTextData value) {
/* 50 */     this._textData = value;
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.LeadZone
 * JD-Core Version:    0.6.2
 */