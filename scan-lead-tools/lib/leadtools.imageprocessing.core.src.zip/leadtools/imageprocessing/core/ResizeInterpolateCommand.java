/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class ResizeInterpolateCommand extends RasterCommand
/*    */ {
/*    */   private int _width;
/*    */   private int _height;
/*    */   private ResizeInterpolateCommandType _resizeType;
/*    */ 
/*    */   public ResizeInterpolateCommand()
/*    */   {
/* 14 */     this._width = 0;
/* 15 */     this._height = 0;
/* 16 */     this._resizeType = ResizeInterpolateCommandType.NORMAL;
/*    */   }
/*    */ 
/*    */   public ResizeInterpolateCommand(int width, int height, ResizeInterpolateCommandType resizeType) {
/* 20 */     this._width = width;
/* 21 */     this._height = height;
/* 22 */     this._resizeType = resizeType;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 27 */     return "Resize Command";
/*    */   }
/*    */   public int getWidth() {
/* 30 */     return this._width;
/*    */   }
/*    */   public void setWidth(int value) {
/* 33 */     this._width = value;
/*    */   }
/*    */   public int getHeight() {
/* 36 */     return this._height;
/*    */   }
/*    */   public void setHeight(int value) {
/* 39 */     this._height = value;
/*    */   }
/*    */ 
/*    */   public ResizeInterpolateCommandType getResizeType() {
/* 43 */     return this._resizeType;
/*    */   }
/*    */ 
/*    */   public void setResizeType(ResizeInterpolateCommandType value) {
/* 47 */     this._resizeType = value;
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 52 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 55 */       ret = ltimgcor.SizeBitmapInterpolate(bitmap, this._width, this._height, this._resizeType.getValue());
/* 56 */       return ret;
/*    */     }
/*    */     finally {
/* 59 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.ResizeInterpolateCommand
 * JD-Core Version:    0.6.2
 */