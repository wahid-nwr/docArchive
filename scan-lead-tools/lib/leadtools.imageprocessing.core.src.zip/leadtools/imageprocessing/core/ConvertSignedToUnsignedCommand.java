/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class ConvertSignedToUnsignedCommand extends RasterCommand
/*    */ {
/*    */   private ConvertSignedToUnsignedCommandType _type;
/*    */ 
/*    */   public ConvertSignedToUnsignedCommand()
/*    */   {
/* 12 */     this._type = ConvertSignedToUnsignedCommandType.SHIFT_RANGE_ONLY;
/*    */   }
/*    */ 
/*    */   public ConvertSignedToUnsignedCommand(ConvertSignedToUnsignedCommandType type) {
/* 16 */     this._type = type;
/*    */   }
/*    */ 
/*    */   public ConvertSignedToUnsignedCommandType getType() {
/* 20 */     return this._type;
/*    */   }
/*    */ 
/*    */   public void setType(ConvertSignedToUnsignedCommandType value) {
/* 24 */     this._type = value;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 29 */     return "Convert Signed to Unsigned";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 34 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 37 */       ret = ltimgcor.ConvertBitmapSignedToUnsigned(bitmap, this._type.getValue(), 0);
/* 38 */       return ret;
/*    */     }
/*    */     finally {
/* 41 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.ConvertSignedToUnsignedCommand
 * JD-Core Version:    0.6.2
 */