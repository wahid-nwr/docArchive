/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class ConvertUnsignedToSignedCommand extends RasterCommand
/*    */ {
/*    */   private ConvertUnsignedToSignedCommandType _type;
/*    */ 
/*    */   public ConvertUnsignedToSignedCommand()
/*    */   {
/* 12 */     this._type = ConvertUnsignedToSignedCommandType.PROCESS_RANGE_ONLY;
/*    */   }
/*    */ 
/*    */   public ConvertUnsignedToSignedCommand(ConvertUnsignedToSignedCommandType type) {
/* 16 */     this._type = type;
/*    */   }
/*    */ 
/*    */   public ConvertUnsignedToSignedCommandType getType() {
/* 20 */     return this._type;
/*    */   }
/*    */ 
/*    */   public void setType(ConvertUnsignedToSignedCommandType value) {
/* 24 */     this._type = value;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 29 */     return "Convert Unsigned to Signed";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 34 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 37 */       ret = ltimgcor.ConvertBitmapUnsignedToSigned(bitmap, this._type.getValue());
/* 38 */       return ret;
/*    */     }
/*    */     finally {
/* 41 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.ConvertUnsignedToSignedCommand
 * JD-Core Version:    0.6.2
 */