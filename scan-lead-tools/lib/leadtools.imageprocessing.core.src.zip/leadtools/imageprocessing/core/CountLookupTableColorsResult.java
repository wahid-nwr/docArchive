/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ public class CountLookupTableColorsResult
/*    */ {
/*    */   private int _numberOfEntries;
/*    */   private int _firstIndex;
/*    */ 
/*    */   public CountLookupTableColorsResult()
/*    */   {
/*  8 */     this._numberOfEntries = 0;
/*  9 */     this._firstIndex = 0;
/*    */   }
/*    */ 
/*    */   public int getNumberOfEntries() {
/* 13 */     return this._numberOfEntries;
/*    */   }
/*    */ 
/*    */   public void setNumberOfEntries(int value) {
/* 17 */     this._numberOfEntries = value;
/*    */   }
/*    */ 
/*    */   public int getFirstIndex() {
/* 21 */     return this._firstIndex;
/*    */   }
/*    */ 
/*    */   public void setFirstIndex(int value) {
/* 25 */     this._firstIndex = value;
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.CountLookupTableColorsResult
 * JD-Core Version:    0.6.2
 */