/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum LeadZoneType
/*    */ {
/*  4 */   TEXT(0), 
/*  5 */   GRAPHIC(1), 
/*  6 */   TABLE(2);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, LeadZoneType> mappings;
/*    */ 
/* 12 */   private static HashMap<Integer, LeadZoneType> getMappings() { if (mappings == null)
/*    */     {
/* 14 */       synchronized (LeadZoneType.class)
/*    */       {
/* 16 */         if (mappings == null)
/*    */         {
/* 18 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 22 */     return mappings; }
/*    */ 
/*    */   private LeadZoneType(int value)
/*    */   {
/* 26 */     this.intValue = value;
/* 27 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue() {
/* 31 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static LeadZoneType forValue(int value)
/*    */   {
/* 36 */     return (LeadZoneType)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.LeadZoneType
 * JD-Core Version:    0.6.2
 */