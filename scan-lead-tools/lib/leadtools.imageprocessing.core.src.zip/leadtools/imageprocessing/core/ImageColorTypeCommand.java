/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class ImageColorTypeCommand extends RasterCommand
/*    */ {
/*    */   private ImageColorTypeCommandFlags _flag;
/*    */   private ImageColorType _colorType;
/*    */   private int _confidence;
/*    */ 
/*    */   public ImageColorTypeCommand()
/*    */   {
/* 14 */     this._flag = ImageColorTypeCommandFlags.NONE;
/*    */   }
/*    */ 
/*    */   public ImageColorTypeCommand(ImageColorTypeCommandFlags flag) {
/* 18 */     this._flag = flag;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 23 */     return "Image Color Type";
/*    */   }
/*    */ 
/*    */   public ImageColorTypeCommandFlags getFlag() {
/* 27 */     return this._flag;
/*    */   }
/*    */ 
/*    */   public void setFlag(ImageColorTypeCommandFlags value) {
/* 31 */     this._flag = value;
/*    */   }
/*    */ 
/*    */   public ImageColorType getColorType() {
/* 35 */     return this._colorType;
/*    */   }
/*    */ 
/*    */   public int getConfidence() {
/* 39 */     return this._confidence;
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 44 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 47 */       int[] uType = new int[1];
/* 48 */       int[] nConfidence = new int[1];
/*    */ 
/* 50 */       ret = ltimgcor.GetBitmapColorType(bitmap, uType, nConfidence, this._flag.getValue());
/* 51 */       if (ret == L_ERROR.SUCCESS.getValue())
/*    */       {
/* 53 */         this._colorType = ImageColorType.forValue(uType[0]);
/* 54 */         this._confidence = nConfidence[0];
/*    */       }
/*    */ 
/* 57 */       return ret;
/*    */     }
/*    */     finally {
/* 60 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.ImageColorTypeCommand
 * JD-Core Version:    0.6.2
 */