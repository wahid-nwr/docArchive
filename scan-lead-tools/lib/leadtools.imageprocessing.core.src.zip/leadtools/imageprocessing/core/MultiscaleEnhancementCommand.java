/*     */ package leadtools.imageprocessing.core;
/*     */ 
/*     */ import leadtools.L_ERROR;
/*     */ import leadtools.RasterImage;
/*     */ import leadtools.RasterImageChangedFlags;
/*     */ import leadtools.imageprocessing.RasterCommand;
/*     */ 
/*     */ public class MultiscaleEnhancementCommand extends RasterCommand
/*     */ {
/*     */   private int _contrast;
/*     */   private int _edgeLevels;
/*     */   private int _edgeCoefficient;
/*     */   private int _latitudeLevels;
/*     */   private int _latitudeCoefficient;
/*     */   private MultiscaleEnhancementCommandType _type;
/*     */   private int _flags;
/*     */ 
/*     */   public MultiscaleEnhancementCommand()
/*     */   {
/*  18 */     this._contrast = 1500;
/*  19 */     int u = 2147483647;
/*  20 */     this._edgeLevels = u;
/*  21 */     this._edgeCoefficient = u;
/*  22 */     this._latitudeLevels = u;
/*  23 */     this._latitudeCoefficient = u;
/*  24 */     this._type = MultiscaleEnhancementCommandType.GAUSSIAN;
/*  25 */     this._flags = MultiscaleEnhancementCommandFlags.NONE.getValue();
/*     */   }
/*     */ 
/*     */   public MultiscaleEnhancementCommand(int contrast) {
/*  29 */     int u = 2147483647;
/*  30 */     this._contrast = contrast;
/*  31 */     this._edgeLevels = u;
/*  32 */     this._edgeCoefficient = u;
/*  33 */     this._latitudeLevels = u;
/*  34 */     this._latitudeCoefficient = u;
/*  35 */     this._type = MultiscaleEnhancementCommandType.GAUSSIAN;
/*  36 */     this._flags = MultiscaleEnhancementCommandFlags.NONE.getValue();
/*     */   }
/*     */ 
/*     */   public MultiscaleEnhancementCommand(int contrast, MultiscaleEnhancementCommandType type, int flags) {
/*  40 */     int u = 2147483647;
/*  41 */     this._contrast = contrast;
/*  42 */     this._edgeLevels = u;
/*  43 */     this._edgeCoefficient = u;
/*  44 */     this._latitudeLevels = u;
/*  45 */     this._latitudeCoefficient = u;
/*  46 */     this._type = type;
/*  47 */     this._flags = flags;
/*     */   }
/*     */ 
/*     */   public MultiscaleEnhancementCommand(int contrast, int edgeLevels, int edgeCoefficient, int latitudeLevels, int latitudeCoefficient, MultiscaleEnhancementCommandType type, int flags) {
/*  51 */     this._contrast = contrast;
/*  52 */     this._edgeLevels = edgeLevels;
/*  53 */     this._edgeCoefficient = edgeCoefficient;
/*  54 */     this._latitudeLevels = latitudeLevels;
/*  55 */     this._latitudeCoefficient = latitudeCoefficient;
/*  56 */     this._type = type;
/*  57 */     this._flags = flags;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  62 */     return "MultiscaleEnhancement";
/*     */   }
/*     */ 
/*     */   public int getContrast() {
/*  66 */     return this._contrast;
/*     */   }
/*     */ 
/*     */   public void setContrast(int value) {
/*  70 */     this._contrast = value;
/*     */   }
/*     */ 
/*     */   public int getEdgeLevels() {
/*  74 */     return this._edgeLevels;
/*     */   }
/*     */   public void setEdgeLevels(int value) {
/*  77 */     this._edgeLevels = value;
/*     */   }
/*     */ 
/*     */   public int getEdgeCoefficient() {
/*  81 */     return this._edgeCoefficient;
/*     */   }
/*     */ 
/*     */   public void setEdgeCoefficient(int value) {
/*  85 */     this._edgeCoefficient = value;
/*     */   }
/*     */ 
/*     */   public int getLatitudeLevels() {
/*  89 */     return this._latitudeLevels;
/*     */   }
/*     */ 
/*     */   public void setLatitudeLevels(int value) {
/*  93 */     this._latitudeLevels = value;
/*     */   }
/*     */ 
/*     */   public int getLatitudeCoefficient() {
/*  97 */     return this._latitudeCoefficient;
/*     */   }
/*     */ 
/*     */   public void setLatitudeCoefficient(int value) {
/* 101 */     this._latitudeCoefficient = value;
/*     */   }
/*     */ 
/*     */   public int getFlags() {
/* 105 */     return this._flags;
/*     */   }
/*     */ 
/*     */   public void setFlags(int value) {
/* 109 */     this._flags = value;
/*     */   }
/*     */ 
/*     */   public MultiscaleEnhancementCommandType getType() {
/* 113 */     return this._type;
/*     */   }
/*     */   public void setType(MultiscaleEnhancementCommandType value) {
/* 116 */     this._type = value;
/*     */   }
/*     */ 
/*     */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*     */   {
/* 121 */     int ret = L_ERROR.SUCCESS.getValue();
/*     */     try
/*     */     {
/* 124 */       ret = ltimgcor.MultiScaleEnhancementBitmap(bitmap, this._contrast, this._edgeLevels, this._edgeCoefficient, this._latitudeLevels, this._latitudeCoefficient, this._type.getValue() | this._flags);
/*     */ 
/* 126 */       return ret;
/*     */     }
/*     */     finally {
/* 129 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.MultiscaleEnhancementCommand
 * JD-Core Version:    0.6.2
 */