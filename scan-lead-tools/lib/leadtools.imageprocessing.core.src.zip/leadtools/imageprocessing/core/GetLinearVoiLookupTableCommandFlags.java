/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum GetLinearVoiLookupTableCommandFlags
/*    */ {
/*  5 */   NONE(0);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, GetLinearVoiLookupTableCommandFlags> mappings;
/*    */ 
/* 11 */   private static HashMap<Integer, GetLinearVoiLookupTableCommandFlags> getMappings() { if (mappings == null)
/*    */     {
/* 13 */       synchronized (GetLinearVoiLookupTableCommandFlags.class)
/*    */       {
/* 15 */         if (mappings == null)
/*    */         {
/* 17 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 21 */     return mappings;
/*    */   }
/*    */ 
/*    */   private GetLinearVoiLookupTableCommandFlags(int value)
/*    */   {
/* 26 */     this.intValue = value;
/* 27 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue()
/*    */   {
/* 32 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static GetLinearVoiLookupTableCommandFlags forValue(int value)
/*    */   {
/* 37 */     return (GetLinearVoiLookupTableCommandFlags)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.GetLinearVoiLookupTableCommandFlags
 * JD-Core Version:    0.6.2
 */