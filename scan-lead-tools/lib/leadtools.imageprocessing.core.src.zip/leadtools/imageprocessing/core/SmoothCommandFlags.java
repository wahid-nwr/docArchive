/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum SmoothCommandFlags
/*    */ {
/*  5 */   NONE(0), 
/*  6 */   SINGLE_REGION(2), 
/*  7 */   LEAD_REGION(4), 
/*  8 */   IMAGE_UNCHANGED(16), 
/*  9 */   FAVOR_LONG(256);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, SmoothCommandFlags> mappings;
/*    */ 
/* 14 */   private static HashMap<Integer, SmoothCommandFlags> getMappings() { if (mappings == null)
/*    */     {
/* 16 */       synchronized (SmoothCommandFlags.class) {
/* 17 */         if (mappings == null) {
/* 18 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 22 */     return mappings; }
/*    */ 
/*    */   private SmoothCommandFlags(int value)
/*    */   {
/* 26 */     this.intValue = value;
/* 27 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue() {
/* 31 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static SmoothCommandFlags forValue(int value) {
/* 35 */     return (SmoothCommandFlags)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.SmoothCommandFlags
 * JD-Core Version:    0.6.2
 */