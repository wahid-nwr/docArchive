/*     */ package leadtools.imageprocessing.core;
/*     */ 
/*     */ import leadtools.RasterImage;
/*     */ 
/*     */ public class FourierTransformInformation
/*     */ {
/*     */   private FTARRAY _unmanaged;
/*     */ 
/*     */   public FourierTransformInformation()
/*     */   {
/*  28 */     this._unmanaged = new FTARRAY();
/*     */   }
/*     */ 
/*     */   public FourierTransformInformation(RasterImage image) {
/*  32 */     int imageSize = image.getWidth() * image.getHeight();
/*  33 */     this._unmanaged = new FTARRAY();
/*  34 */     this._unmanaged.acxData = new LCOMPLEX[imageSize];
/*  35 */     for (int i = 0; i < imageSize; i++) {
/*  36 */       this._unmanaged.acxData[i] = new LCOMPLEX();
/*     */     }
/*  38 */     this._unmanaged.uHeight = image.getHeight();
/*  39 */     this._unmanaged.uWidth = image.getWidth();
/*     */   }
/*     */ 
/*     */   public FourierTransformInformation clone() {
/*  43 */     FourierTransformInformation fti = new FourierTransformInformation();
/*  44 */     fti._unmanaged.uWidth = this._unmanaged.uWidth;
/*  45 */     fti._unmanaged.uHeight = this._unmanaged.uHeight;
/*  46 */     fti._unmanaged.acxData = new LCOMPLEX[this._unmanaged.acxData.length];
/*  47 */     for (int i = 0; i < fti._unmanaged.acxData.length; i++) {
/*  48 */       fti._unmanaged.acxData[i].i = this._unmanaged.acxData[i].i;
/*  49 */       fti._unmanaged.acxData[i].r = this._unmanaged.acxData[i].r;
/*     */     }
/*  51 */     return fti;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  56 */     return "Fourier Transform Information";
/*     */   }
/*     */ 
/*     */   FTARRAY getUnmanaged() {
/*  60 */     return this._unmanaged;
/*     */   }
/*     */ 
/*     */   public void setData(Complex[] data)
/*     */   {
/*  65 */     if ((this._unmanaged.acxData != null) && (this._unmanaged.uWidth != 0) && (this._unmanaged.uHeight != 0)) {
/*  66 */       int imageSize = this._unmanaged.uHeight * this._unmanaged.uWidth;
/*     */ 
/*  68 */       for (int i = 0; i < imageSize; i++)
/*     */       {
/*  70 */         this._unmanaged.acxData[i].r = data[i].getR();
/*  71 */         this._unmanaged.acxData[i].i = data[i].getI();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getDataSize() {
/*  77 */     return this._unmanaged.uWidth * this._unmanaged.uHeight;
/*     */   }
/*     */ 
/*     */   LCOMPLEX[] getDataPointer() {
/*  81 */     return this._unmanaged.acxData;
/*     */   }
/*     */ 
/*     */   public int getWidth() {
/*  85 */     return this._unmanaged.uWidth;
/*     */   }
/*     */ 
/*     */   public int getHeight() {
/*  89 */     return this._unmanaged.uHeight;
/*     */   }
/*     */ 
/*     */   public Complex[] getData()
/*     */   {
/*     */     Complex[] data;
/*     */     int i;
/*  95 */     if ((this._unmanaged.acxData != null) && (this._unmanaged.uWidth != 0) && (this._unmanaged.uHeight != 0))
/*     */     {
/*  97 */       int imageSize = this._unmanaged.uHeight * this._unmanaged.uWidth;
/*  98 */       data = new Complex[imageSize];
/*  99 */       for (i = 0; i < imageSize; )
/*     */       {
/* 101 */         data[i] = new Complex(this._unmanaged.acxData[i].r, this._unmanaged.acxData[i].i);
/*     */ 
/*  99 */         i++; continue;
/*     */ 
/* 105 */         data = null;
/*     */       }
/*     */     }
/*     */     Complex[] data;
/* 106 */     return data;
/*     */   }
/*     */ 
/*     */   public Complex getDataOf(int x, int y) {
/* 110 */     LCOMPLEX ptr = this._unmanaged.acxData[(x * this._unmanaged.uWidth * y)];
/* 111 */     return new Complex(ptr.r, ptr.i);
/*     */   }
/*     */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.FourierTransformInformation
 * JD-Core Version:    0.6.2
 */