/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class DigitalSubtractCommand extends RasterCommand
/*    */ {
/*    */   private RasterImage _maskImage;
/*    */   private int _flags;
/*    */ 
/*    */   public DigitalSubtractCommand()
/*    */   {
/* 13 */     this._maskImage = null;
/* 14 */     this._flags = DigitalSubtractCommandFlags.NONE.getValue();
/*    */   }
/*    */ 
/*    */   public DigitalSubtractCommand(RasterImage maskImage, int flags) {
/* 18 */     this._maskImage = new RasterImage(maskImage);
/* 19 */     this._flags = flags;
/*    */   }
/*    */ 
/*    */   public int getFlags() {
/* 23 */     return this._flags;
/*    */   }
/*    */ 
/*    */   public void setFlags(int value) {
/* 27 */     this._flags = value;
/*    */   }
/*    */ 
/*    */   public RasterImage getMaskImage() {
/* 31 */     return this._maskImage;
/*    */   }
/*    */ 
/*    */   public void setMaskImage(RasterImage value) {
/* 35 */     this._maskImage = value;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 40 */     return "Digital Subtract";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 45 */     int ret = L_ERROR.SUCCESS.getValue();
/* 46 */     long maskImage = 0L;
/*    */ 
/* 48 */     if (this._maskImage != null) {
/* 49 */       maskImage = this._maskImage.getCurrentBitmapHandle();
/*    */     }
/*    */     try
/*    */     {
/* 53 */       ret = ltimgcor.DigitalSubtractBitmap(bitmap, maskImage, this._flags);
/* 54 */       return ret;
/*    */     }
/*    */     finally {
/* 57 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.DigitalSubtractCommand
 * JD-Core Version:    0.6.2
 */