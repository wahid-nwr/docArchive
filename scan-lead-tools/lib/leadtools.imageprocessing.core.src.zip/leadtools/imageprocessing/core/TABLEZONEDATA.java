/*     */ package leadtools.imageprocessing.core;
/*     */ 
/*     */ import leadtools.LeadRect;
/*     */ 
/*     */ class TABLEZONEDATA
/*     */ {
/*     */   int _cellsCount;
/*     */   int _rows;
/*     */   int _columns;
/*     */   LeadRect[] _cells;
/*     */   int[] _cellTypes;
/*     */   int[] _insideCellsNumber;
/*     */   LeadRect[][] _insideRects;
/*     */   LeadRect[] _BoundsToDraw;
/*     */ 
/*     */   public TABLEZONEDATA()
/*     */   {
/* 273 */     this._cellsCount = 0;
/* 274 */     this._rows = 0;
/* 275 */     this._columns = 0;
/* 276 */     this._cells = null;
/* 277 */     this._cellTypes = null;
/* 278 */     this._insideCellsNumber = null;
/* 279 */     this._insideRects = ((LeadRect[][])null);
/* 280 */     this._BoundsToDraw = null;
/*     */   }
/*     */ 
/*     */   public void setCellRect(int index, int left, int top, int right, int bottom) {
/* 284 */     if ((this._cellsCount <= 0) || (index < 0) || (index >= this._cellsCount)) {
/* 285 */       return;
/*     */     }
/* 287 */     if (this._cells == null) {
/* 288 */       this._cells = new LeadRect[this._cellsCount];
/* 289 */       this._insideRects = new LeadRect[this._cellsCount][];
/*     */     }
/*     */ 
/* 292 */     if ((this._insideCellsNumber != null) && (this._insideRects != null) && 
/* 293 */       (this._insideCellsNumber[index] != 0)) {
/* 294 */       this._insideRects[index] = new LeadRect[this._insideCellsNumber[index]];
/*     */     }
/*     */ 
/* 297 */     this._cells[index] = LeadRect.fromLTRB(left, top, right, bottom);
/*     */   }
/*     */ 
/*     */   public void setBoundsToDraw(int index, int left, int top, int right, int bottom) {
/* 301 */     if ((this._cellsCount <= 0) || (index < 0) || (index >= this._cellsCount)) {
/* 302 */       return;
/*     */     }
/* 304 */     if (this._BoundsToDraw == null) {
/* 305 */       this._BoundsToDraw = new LeadRect[this._cellsCount];
/*     */     }
/*     */ 
/* 308 */     this._BoundsToDraw[index] = LeadRect.fromLTRB(left, top, right, bottom);
/*     */   }
/*     */ 
/*     */   public void setInsideCellRect(int index, int cellIndex, int left, int top, int right, int bottom) {
/* 312 */     if ((index < 0) || (index >= this._cellsCount) || (this._insideCellsNumber[index] <= 0)) {
/* 313 */       return;
/*     */     }
/* 315 */     if ((this._cellsCount <= 0) || (cellIndex < 0) || (cellIndex >= this._insideCellsNumber[index])) {
/* 316 */       return;
/*     */     }
/* 318 */     if ((this._insideCellsNumber == null) || (this._insideRects == null)) {
/* 319 */       return;
/*     */     }
/* 321 */     this._insideRects[index][cellIndex] = LeadRect.fromLTRB(left, top, right, bottom);
/*     */   }
/*     */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.TABLEZONEDATA
 * JD-Core Version:    0.6.2
 */