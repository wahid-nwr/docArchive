package leadtools.imageprocessing.core;

public abstract interface DotRemoveCommandListener
{
  public abstract void onDotRemoveEvent(DotRemoveCommandEvent paramDotRemoveCommandEvent);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.DotRemoveCommandListener
 * JD-Core Version:    0.6.2
 */