/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.LeadPoint;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ import leadtools.ltkrn;
/*    */ 
/*    */ public class KeyStoneCommand extends RasterCommand
/*    */ {
/*    */   private ArrayList<LeadPoint> _polyPoints;
/*    */   private RasterImage _outbitmap;
/*    */ 
/*    */   public KeyStoneCommand()
/*    */   {
/* 18 */     this._polyPoints = new ArrayList();
/* 19 */     this._outbitmap = null;
/*    */   }
/*    */ 
/*    */   public KeyStoneCommand(ArrayList<LeadPoint> polygonPoints) {
/* 23 */     this._polyPoints = polygonPoints;
/* 24 */     this._outbitmap = null;
/*    */   }
/*    */ 
/*    */   public RasterImage getTransformedBitmap() {
/* 28 */     return this._outbitmap;
/*    */   }
/*    */ 
/*    */   public ArrayList<LeadPoint> getPolygonPoints() {
/* 32 */     return this._polyPoints;
/*    */   }
/*    */ 
/*    */   public void setPolygonPoints(ArrayList<LeadPoint> value) {
/* 36 */     this._polyPoints = value;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 41 */     return "KeyStone Command";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 46 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 49 */       if (this._polyPoints.size() < 4) {
/* 50 */         return L_ERROR.ERROR_INV_PARAMETER.getValue();
/*    */       }
/* 52 */       long[] outBitmap = new long[1];
/* 53 */       outBitmap[0] = ltkrn.AllocBitmapHandle();
/*    */ 
/* 55 */       LeadPoint[] points = new LeadPoint[4];
/*    */ 
/* 57 */       for (int i = 0; i < 4; i++) {
/* 58 */         points[i] = ((LeadPoint)this._polyPoints.get(i)).clone();
/*    */       }
/*    */ 
/* 61 */       ret = ltimgcor.Keystone(bitmap, points, outBitmap);
/* 62 */       if (ret != L_ERROR.SUCCESS.getValue()) {
/* 63 */         return ret;
/*    */       }
/* 65 */       if (outBitmap[0] != 0L) {
/* 66 */         this._outbitmap = RasterImage.createFromBitmapHandle(outBitmap[0], false);
/* 67 */         ltkrn.FreeBitmapHandle(outBitmap[0]);
/*    */       }
/*    */ 
/* 70 */       return ret;
/*    */     }
/*    */     finally {
/* 73 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.KeyStoneCommand
 * JD-Core Version:    0.6.2
 */