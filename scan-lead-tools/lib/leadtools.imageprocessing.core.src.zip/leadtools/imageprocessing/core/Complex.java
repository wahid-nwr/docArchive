/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ public class Complex
/*    */ {
/*    */   private double _r;
/*    */   private double _i;
/*    */ 
/*    */   private Complex(int dummy)
/*    */   {
/*  8 */     this._r = 0.0D;
/*  9 */     this._i = 0.0D;
/*    */   }
/*    */ 
/*    */   public Complex(double r, double i) {
/* 13 */     this._r = r;
/* 14 */     this._i = i;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 20 */     return "Complex";
/*    */   }
/*    */ 
/*    */   public static Complex getEmpty() {
/* 24 */     return new Complex(0);
/*    */   }
/*    */ 
/*    */   public double getR() {
/* 28 */     return this._r;
/*    */   }
/*    */   public void setR(double value) {
/* 31 */     this._r = value;
/*    */   }
/*    */ 
/*    */   public double getI() {
/* 35 */     return this._i;
/*    */   }
/*    */   public void setI(double value) {
/* 38 */     this._i = value;
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.Complex
 * JD-Core Version:    0.6.2
 */