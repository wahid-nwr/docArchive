package leadtools.imageprocessing.core;

class LCOMPLEX
{
  public double r;
  public double i;
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.LCOMPLEX
 * JD-Core Version:    0.6.2
 */