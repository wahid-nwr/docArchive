/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum OmrFrameDetectionMethod
/*    */ {
/*  4 */   AUTO(0), 
/*  5 */   WITHOUT_FRAME(1), 
/*  6 */   WITH_FRAME(2);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, OmrFrameDetectionMethod> mappings;
/*    */ 
/* 11 */   private static HashMap<Integer, OmrFrameDetectionMethod> getMappings() { if (mappings == null) {
/* 12 */       synchronized (OmrFrameDetectionMethod.class) {
/* 13 */         if (mappings == null) {
/* 14 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 18 */     return mappings; }
/*    */ 
/*    */   private OmrFrameDetectionMethod(int value)
/*    */   {
/* 22 */     this.intValue = value;
/* 23 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue() {
/* 27 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static OmrFrameDetectionMethod forValue(int value) {
/* 31 */     return (OmrFrameDetectionMethod)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.OmrFrameDetectionMethod
 * JD-Core Version:    0.6.2
 */