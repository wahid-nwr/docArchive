/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class ApplyLinearModalityLookupTableCommand extends RasterCommand
/*    */ {
/*    */   private double _intercept;
/*    */   private double _slope;
/*    */   private int _flags;
/*    */ 
/*    */   public ApplyLinearModalityLookupTableCommand()
/*    */   {
/* 14 */     this._intercept = 0.0D;
/* 15 */     this._slope = 2.0D;
/* 16 */     this._flags = ModalityLookupTableCommandFlags.NONE.getValue();
/*    */   }
/*    */ 
/*    */   public ApplyLinearModalityLookupTableCommand(double intercept, double slope, int flags)
/*    */   {
/* 21 */     this._intercept = intercept;
/* 22 */     this._slope = slope;
/* 23 */     this._flags = flags;
/*    */   }
/*    */ 
/*    */   public int getFlags() {
/* 27 */     return this._flags;
/*    */   }
/*    */ 
/*    */   public void setFlags(int value) {
/* 31 */     this._flags = value;
/*    */   }
/*    */ 
/*    */   public double getIntercept() {
/* 35 */     return this._intercept;
/*    */   }
/*    */ 
/*    */   public void setIntercept(double value) {
/* 39 */     this._intercept = value;
/*    */   }
/*    */ 
/*    */   public double getSlope() {
/* 43 */     return this._slope;
/*    */   }
/*    */ 
/*    */   public void setSlope(double value) {
/* 47 */     this._slope = value;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 52 */     return "ApplyLinearModalityLookUpTable";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 57 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 60 */       ret = ltimgcor.ApplyLinearModalityLUT(bitmap, this._intercept, this._slope, this._flags);
/*    */ 
/* 62 */       return ret;
/*    */     } finally {
/* 64 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.ApplyLinearModalityLookupTableCommand
 * JD-Core Version:    0.6.2
 */