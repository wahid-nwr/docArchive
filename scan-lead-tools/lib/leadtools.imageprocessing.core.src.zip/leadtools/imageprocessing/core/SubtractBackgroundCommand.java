/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class SubtractBackgroundCommand extends RasterCommand
/*    */ {
/*    */   private int _rollingBall;
/*    */   private SubtractBackgroundCommandType _shrinkingSize;
/*    */   private int _brightnessFactor;
/*    */   private int _flags;
/*    */ 
/*    */   public SubtractBackgroundCommand()
/*    */   {
/* 15 */     this._shrinkingSize = SubtractBackgroundCommandType.DEPEND_ON_ROLLING_BALL_SIZE;
/* 16 */     this._brightnessFactor = 150;
/* 17 */     this._rollingBall = 100;
/* 18 */     this._flags = (SubtractBackgroundCommandFlags.BACKGROUND_IS_BRIGHTER.getValue() | SubtractBackgroundCommandFlags.SUBTRACTED_IMAGE.getValue());
/*    */   }
/*    */ 
/*    */   public SubtractBackgroundCommand(int rollingBall, SubtractBackgroundCommandType shrinkingSize, int brightnessFactor, int flags) {
/* 22 */     this._shrinkingSize = shrinkingSize;
/* 23 */     this._brightnessFactor = brightnessFactor;
/* 24 */     this._flags = flags;
/* 25 */     this._rollingBall = rollingBall;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 30 */     return "SubtractBackground";
/*    */   }
/*    */ 
/*    */   public int getRollingBall() {
/* 34 */     return this._rollingBall;
/*    */   }
/*    */ 
/*    */   public void setRollingBall(int value) {
/* 38 */     this._rollingBall = value;
/*    */   }
/*    */ 
/*    */   public int getBrightnessFactor() {
/* 42 */     return this._brightnessFactor;
/*    */   }
/*    */ 
/*    */   public void setBrightnessFactor(int value) {
/* 46 */     this._brightnessFactor = value;
/*    */   }
/*    */ 
/*    */   public int getFlags() {
/* 50 */     return this._flags;
/*    */   }
/*    */ 
/*    */   public void setFlags(int value) {
/* 54 */     this._flags = value;
/*    */   }
/*    */ 
/*    */   public SubtractBackgroundCommandType getShrinkingSize() {
/* 58 */     return this._shrinkingSize;
/*    */   }
/*    */ 
/*    */   public void setShrinkingSize(SubtractBackgroundCommandType value) {
/* 62 */     this._shrinkingSize = value;
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 67 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 70 */       ret = ltimgcor.SubtractBackgroundBitmap(bitmap, this._rollingBall, this._shrinkingSize.getValue(), this._brightnessFactor, this._flags);
/*    */ 
/* 76 */       return ret;
/*    */     }
/*    */     finally {
/* 79 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.SubtractBackgroundCommand
 * JD-Core Version:    0.6.2
 */