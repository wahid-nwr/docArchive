/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class AutoBinarizeCommand extends RasterCommand
/*    */ {
/*    */   private int _factor;
/*    */   private int _flags;
/*    */ 
/*    */   public int getFactor()
/*    */   {
/* 13 */     return this._factor;
/*    */   }
/*    */ 
/*    */   public void setFactor(int value) {
/* 17 */     this._factor = value;
/*    */   }
/*    */ 
/*    */   public int getFlags() {
/* 21 */     return this._flags;
/*    */   }
/*    */ 
/*    */   public void setFlags(int value) {
/* 25 */     this._flags = value;
/*    */   }
/*    */ 
/*    */   public AutoBinarizeCommand()
/*    */   {
/* 30 */     this._factor = 0;
/* 31 */     this._flags = (AutoBinarizeCommandFlags.USE_AUTO_PRE_PROCESSING.getValue() | AutoBinarizeCommandFlags.USE_AUTO_THRESHOLD.getValue());
/*    */   }
/*    */ 
/*    */   public AutoBinarizeCommand(int factor, int flags)
/*    */   {
/* 36 */     this._factor = factor;
/* 37 */     this._flags = flags;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 43 */     return "AutoBinarize";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 48 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 51 */       ret = ltimgcor.AutoBinarizeBitmap(bitmap, this._factor, this._flags);
/* 52 */       return ret;
/*    */     }
/*    */     finally {
/* 55 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.AutoBinarizeCommand
 * JD-Core Version:    0.6.2
 */