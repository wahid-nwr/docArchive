/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum HighQualityRotateCommandFlags
/*    */ {
/*  5 */   NONE(0), 
/*  6 */   CROP(0), 
/*  7 */   RESIZE(1), 
/*  8 */   FASTEST(0), 
/*  9 */   BEST_QUALITY(16);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, HighQualityRotateCommandFlags> mappings;
/*    */ 
/* 15 */   private static HashMap<Integer, HighQualityRotateCommandFlags> getMappings() { if (mappings == null)
/*    */     {
/* 17 */       synchronized (HighQualityRotateCommandFlags.class)
/*    */       {
/* 19 */         if (mappings == null)
/*    */         {
/* 21 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 25 */     return mappings;
/*    */   }
/*    */ 
/*    */   private HighQualityRotateCommandFlags(int value)
/*    */   {
/* 30 */     this.intValue = value;
/* 31 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue()
/*    */   {
/* 36 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static HighQualityRotateCommandFlags forValue(int value)
/*    */   {
/* 41 */     return (HighQualityRotateCommandFlags)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.HighQualityRotateCommandFlags
 * JD-Core Version:    0.6.2
 */