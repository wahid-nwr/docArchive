/*     */ package leadtools.imageprocessing.core;
/*     */ 
/*     */ import leadtools.L_ERROR;
/*     */ import leadtools.LeadPoint;
/*     */ import leadtools.RasterColor;
/*     */ import leadtools.RasterColor16;
/*     */ import leadtools.RasterException;
/*     */ import leadtools.RasterImage;
/*     */ 
/*     */ public class CoreUtilities
/*     */ {
/*     */   public static CountLookupTableColorsResult countLookupTableColors(RasterColor[] lookupTable, CountLookupTableColorsType type)
/*     */   {
/*  14 */     int length = lookupTable != null ? lookupTable.length : 0;
/*     */ 
/*  16 */     RasterColor[] pLUT = new RasterColor[length];
/*  17 */     for (int i = 0; i < length; i++)
/*  18 */       pLUT[i] = lookupTable[i].clone();
/*     */     try
/*     */     {
/*  21 */       int[] numberOfEntries = new int[1];
/*  22 */       int[] firstIndex = new int[1];
/*     */ 
/*  24 */       int ret = ltimgcor.CountLUTColors(pLUT, length, numberOfEntries, firstIndex, type.getValue());
/*     */ 
/*  31 */       if (ret == L_ERROR.SUCCESS.getValue()) {
/*  32 */         result = new CountLookupTableColorsResult();
/*  33 */         result.setNumberOfEntries(numberOfEntries[0]);
/*  34 */         result.setFirstIndex(firstIndex[0]);
/*     */ 
/*  36 */         CountLookupTableColorsResult localCountLookupTableColorsResult1 = result; return localCountLookupTableColorsResult1;
/*     */       }
/*     */ 
/*  39 */       RasterException.checkErrorCode(ret);
/*     */ 
/*  41 */       CountLookupTableColorsResult result = null; return result;
/*     */     }
/*     */     finally {
/*     */     }
/*     */   }
/*     */ 
/*     */   public static CountLookupTableColorsResult countLookupTableColorsExt(RasterColor16[] lookupTable, CountLookupTableColorsType type) {
/*  48 */     int length = lookupTable != null ? lookupTable.length : 0;
/*     */ 
/*  50 */     RasterColor16[] pLUT = new RasterColor16[length];
/*  51 */     for (int i = 0; i < length; i++)
/*  52 */       pLUT[i] = lookupTable[i].clone();
/*     */     try
/*     */     {
/*  55 */       int[] numberOfEntries = new int[1];
/*  56 */       int[] firstIndex = new int[1];
/*     */ 
/*  58 */       int ret = ltimgcor.CountLUTColorsExt(pLUT, length, numberOfEntries, firstIndex, type.getValue());
/*     */ 
/*  65 */       if (ret == L_ERROR.SUCCESS.getValue()) {
/*  66 */         result = new CountLookupTableColorsResult();
/*  67 */         result.setNumberOfEntries(numberOfEntries[0]);
/*  68 */         result.setFirstIndex(firstIndex[0]);
/*     */ 
/*  70 */         CountLookupTableColorsResult localCountLookupTableColorsResult1 = result; return localCountLookupTableColorsResult1;
/*     */       }
/*     */ 
/*  73 */       RasterException.checkErrorCode(ret);
/*     */ 
/*  75 */       CountLookupTableColorsResult result = null; return result;
/*     */     } finally {
/*     */     }
/*     */   }
/*     */ 
/*     */   public static TransformationParameters getTransformationParameters(RasterImage image, LeadPoint[] referencePoints, LeadPoint[] transformedPoints) {
/*  81 */     LeadPoint[] refPt = null;
/*  82 */     int size = referencePoints != null ? referencePoints.length : 0;
/*  83 */     if (size > 0) {
/*  84 */       refPt = new LeadPoint[size];
/*  85 */       for (int i = 0; i < size; i++) {
/*  86 */         refPt[i] = new LeadPoint(referencePoints[i].getX(), referencePoints[i].getY());
/*     */       }
/*     */     }
/*  89 */     LeadPoint[] trnsPt = null;
/*  90 */     size = transformedPoints != null ? transformedPoints.length : 0;
/*  91 */     if (size > 0) {
/*  92 */       trnsPt = new LeadPoint[size];
/*  93 */       for (int i = 0; i < size; i++) {
/*  94 */         trnsPt[i] = new LeadPoint(transformedPoints[i].getX(), transformedPoints[i].getY());
/*     */       }
/*     */     }
/*  97 */     int[] xtran = new int[1];
/*  98 */     int[] ytran = new int[1];
/*  99 */     int[] angle = new int[1];
/* 100 */     int[] xscale = new int[1];
/* 101 */     int[] yscale = new int[1];
/*     */ 
/* 103 */     xtran[0] = 0;
/* 104 */     ytran[0] = 0;
/* 105 */     angle[0] = 0;
/* 106 */     xscale[0] = 0;
/* 107 */     yscale[0] = 0;
/*     */ 
/* 109 */     int ret = ltimgcor.GetTransformationParameters(image.getCurrentBitmapHandle(), refPt, trnsPt, xtran, ytran, angle, xscale, yscale, 0);
/* 110 */     image.updateCurrentBitmapHandle();
/* 111 */     RasterException.checkErrorCode(ret);
/*     */ 
/* 113 */     TransformationParameters tp = new TransformationParameters();
/* 114 */     tp.setXTranslation(xtran[0]);
/* 115 */     tp.setYTranslation(ytran[0]);
/* 116 */     tp.setAngle(angle[0]);
/* 117 */     tp.setXScale(xscale[0]);
/* 118 */     tp.setYScale(yscale[0]);
/*     */ 
/* 120 */     return tp;
/*     */   }
/*     */ 
/*     */   public static boolean isRegistrationMark(RasterImage image, RegistrationMarkCommandType type, int minScale, int maxScale, int width, int height) {
/* 124 */     int ret = ltimgcor.IsRegMarkBitmap(image.getCurrentBitmapHandle(), type.getValue(), minScale, maxScale, width, height, 0);
/* 125 */     image.updateCurrentBitmapHandle();
/*     */ 
/* 127 */     if (ret < 0) {
/* 128 */       RasterException.checkErrorCode(ret);
/*     */     }
/* 130 */     return ret != 0;
/*     */   }
/*     */ 
/*     */   public static LeadPoint[] getRegistrationMarksCenterMass(RasterImage image, LeadPoint[] markPoints) {
/* 134 */     LeadPoint[] pts = null;
/* 135 */     LeadPoint[] cmp = null;
/* 136 */     int length = markPoints != null ? markPoints.length : 0;
/* 137 */     if (length > 0)
/*     */     {
/* 139 */       pts = new LeadPoint[length];
/* 140 */       cmp = new LeadPoint[length];
/* 141 */       for (int i = 0; i < length; i++) {
/* 142 */         pts[i] = new LeadPoint(markPoints[i].getX(), markPoints[i].getY());
/*     */       }
/*     */     }
/* 145 */     int ret = ltimgcor.GetMarksCenterMassBitmap(image.getCurrentBitmapHandle(), pts, cmp, length, 0);
/* 146 */     image.updateCurrentBitmapHandle();
/* 147 */     RasterException.checkErrorCode(ret);
/*     */ 
/* 149 */     LeadPoint[] result = new LeadPoint[length];
/* 150 */     if (cmp != null) {
/* 151 */       for (int i = 0; i < length; i++) {
/* 152 */         result[i] = new LeadPoint(cmp[i].getX(), cmp[i].getY());
/*     */       }
/*     */     }
/* 155 */     return result;
/*     */   }
/*     */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.CoreUtilities
 * JD-Core Version:    0.6.2
 */