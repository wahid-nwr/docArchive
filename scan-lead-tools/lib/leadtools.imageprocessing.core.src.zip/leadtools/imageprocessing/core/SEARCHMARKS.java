/*     */ package leadtools.imageprocessing.core;
/*     */ 
/*     */ import leadtools.LeadPoint;
/*     */ import leadtools.LeadRect;
/*     */ 
/*     */ class SEARCHMARKS
/*     */ {
/*     */   int _uType;
/*     */   int _uWidth;
/*     */   int _uHeight;
/*     */   int _uMinScale;
/*     */   int _uMaxScale;
/*     */   LeadRect _rcRect;
/*     */   int _uSearchMarkCount;
/*     */   LeadPoint[] _markDetectedPoints;
/*     */   int _uMarkDetectedCount;
/*     */ 
/*     */   public SEARCHMARKS()
/*     */   {
/* 166 */     this._uType = 0;
/* 167 */     this._uWidth = 0;
/* 168 */     this._uHeight = 0;
/* 169 */     this._uMinScale = 0;
/* 170 */     this._uMaxScale = 0;
/* 171 */     this._rcRect = null;
/* 172 */     this._uSearchMarkCount = 0;
/* 173 */     this._markDetectedPoints = null;
/* 174 */     this._uMarkDetectedCount = 0;
/*     */   }
/*     */ 
/*     */   public void setPoint(int index, int x, int y) {
/* 178 */     if ((index < 0) || (index >= this._uMarkDetectedCount) || (this._uMarkDetectedCount == 0)) {
/* 179 */       return;
/*     */     }
/* 181 */     if (this._markDetectedPoints == null) {
/* 182 */       this._markDetectedPoints = new LeadPoint[this._uMarkDetectedCount];
/*     */     }
/* 184 */     this._markDetectedPoints[index] = new LeadPoint(x, y);
/*     */   }
/*     */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.SEARCHMARKS
 * JD-Core Version:    0.6.2
 */