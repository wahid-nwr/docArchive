/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum LineRemoveCommandType
/*    */ {
/*  4 */   HORIZONTAL(1), 
/*  5 */   VERTICAL(2);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, LineRemoveCommandType> mappings;
/*    */ 
/* 11 */   private static HashMap<Integer, LineRemoveCommandType> getMappings() { if (mappings == null)
/*    */     {
/* 13 */       synchronized (LineRemoveCommandType.class)
/*    */       {
/* 15 */         if (mappings == null)
/*    */         {
/* 17 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 21 */     return mappings;
/*    */   }
/*    */ 
/*    */   private LineRemoveCommandType(int value)
/*    */   {
/* 26 */     this.intValue = value;
/* 27 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue()
/*    */   {
/* 32 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static LineRemoveCommandType forValue(int value)
/*    */   {
/* 37 */     return (LineRemoveCommandType)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.LineRemoveCommandType
 * JD-Core Version:    0.6.2
 */