/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class FastFourierTransformCommand extends RasterCommand
/*    */ {
/*    */   private int _flags;
/*    */   private FourierTransformInformation _fourierTransformInformation;
/*    */ 
/*    */   public FastFourierTransformCommand()
/*    */   {
/* 13 */     this._flags = FastFourierTransformCommandFlags.NONE.getValue();
/* 14 */     this._fourierTransformInformation = null;
/*    */   }
/*    */ 
/*    */   public FastFourierTransformCommand(FourierTransformInformation fourierTransformInformation, int flags) {
/* 18 */     this._flags = flags;
/* 19 */     this._fourierTransformInformation = fourierTransformInformation;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 24 */     return "Fast Fourier Transform";
/*    */   }
/*    */ 
/*    */   public int getFlags() {
/* 28 */     return this._flags;
/*    */   }
/*    */ 
/*    */   public void setFlags(int value) {
/* 32 */     this._flags = value;
/*    */   }
/*    */ 
/*    */   public FourierTransformInformation getFourierTransformInformation() {
/* 36 */     return this._fourierTransformInformation;
/*    */   }
/*    */   public void setFourierTransformInformation(FourierTransformInformation value) {
/* 39 */     this._fourierTransformInformation = value;
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 44 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 47 */       FTARRAY unmanagedFTArray = this._fourierTransformInformation.getUnmanaged();
/* 48 */       ret = ltimgcor.FFTBitmap(bitmap, unmanagedFTArray.uWidth, unmanagedFTArray.uHeight, unmanagedFTArray.acxData, this._flags);
/* 49 */       return ret;
/*    */     }
/*    */     finally {
/* 52 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.FastFourierTransformCommand
 * JD-Core Version:    0.6.2
 */