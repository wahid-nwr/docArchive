/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterColor;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class HighQualityRotateCommand extends RasterCommand
/*    */ {
/*    */   private int _angle;
/*    */   private int _flags;
/*    */   private RasterColor _fillColor;
/*    */ 
/*    */   public HighQualityRotateCommand()
/*    */   {
/* 15 */     this._angle = 2250;
/* 16 */     this._flags = HighQualityRotateCommandFlags.FASTEST.getValue();
/* 17 */     this._fillColor = new RasterColor(0, 0, 0);
/*    */   }
/*    */ 
/*    */   public HighQualityRotateCommand(int angle, int flags, RasterColor fillColor) {
/* 21 */     this._angle = angle;
/* 22 */     this._flags = flags;
/* 23 */     this._fillColor = fillColor;
/*    */   }
/*    */ 
/*    */   public int getAngle() {
/* 27 */     return this._angle;
/*    */   }
/*    */ 
/*    */   public void setAngle(int value) {
/* 31 */     this._angle = value;
/*    */   }
/*    */ 
/*    */   public int getFlags() {
/* 35 */     return this._flags;
/*    */   }
/*    */ 
/*    */   public void setFlags(int value) {
/* 39 */     this._flags = value;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 44 */     return "HighQualityRotate";
/*    */   }
/*    */ 
/*    */   public RasterColor getFillColor() {
/* 48 */     return this._fillColor;
/*    */   }
/*    */ 
/*    */   public void setFillColor(RasterColor value) {
/* 52 */     this._fillColor = value;
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 57 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 60 */       ret = ltimgcor.HighQualityRotateBitmap(bitmap, this._angle, this._flags, this._fillColor.toRgb());
/* 61 */       return ret;
/*    */     }
/*    */     finally {
/* 64 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.HighQualityRotateCommand
 * JD-Core Version:    0.6.2
 */