/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterColor;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class KMeansCommand extends RasterCommand
/*    */ {
/*    */   private int _clusters;
/*    */   private KMeansCommandFlags _type;
/*    */   private ArrayList<RasterColor> _outArray;
/*    */   private ArrayList<RasterColor> _inArray;
/*    */ 
/*    */   public String toString()
/*    */   {
/* 20 */     return "KMeansCommand";
/*    */   }
/*    */ 
/*    */   public KMeansCommand() {
/* 24 */     this._clusters = 5;
/* 25 */     this._type = KMeansCommandFlags.KMEANS_RANDOM;
/* 26 */     this._outArray = null;
/* 27 */     this._inArray = null;
/*    */   }
/*    */ 
/*    */   public KMeansCommand(int Clusters, KMeansCommandFlags Type, ArrayList<RasterColor> InCenters) {
/* 31 */     this._clusters = Clusters;
/* 32 */     this._type = Type;
/* 33 */     this._outArray = null;
/* 34 */     this._inArray = InCenters;
/*    */   }
/*    */ 
/*    */   public int getClusters() {
/* 38 */     return this._clusters;
/*    */   }
/*    */ 
/*    */   public void setClusters(int value) {
/* 42 */     this._clusters = value;
/*    */   }
/*    */ 
/*    */   public KMeansCommandFlags getType() {
/* 46 */     return this._type;
/*    */   }
/*    */ 
/*    */   public void setType(KMeansCommandFlags value) {
/* 50 */     this._type = value;
/*    */   }
/*    */ 
/*    */   public ArrayList<RasterColor> getOutCenters() {
/* 54 */     return this._outArray;
/*    */   }
/*    */ 
/*    */   public void setInCenters(ArrayList<RasterColor> value) {
/* 58 */     this._inArray = value;
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 63 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 66 */       int[] inCenters = null;
/*    */ 
/* 68 */       if (this._inArray != null) {
/* 69 */         inCenters = new int[this._clusters];
/* 70 */         for (int i = 0; i < this._clusters; i++) {
/* 71 */           inCenters[i] = ((RasterColor)this._inArray.get(i)).toRgb();
/*    */         }
/*    */       }
/* 74 */       KMeansCommandResults results = new KMeansCommandResults(0, null);
/* 75 */       ret = ltimgcor.KMeansBitmapSegmentation(bitmap, this._clusters, results, inCenters, this._type.getValue());
/*    */       int i;
/* 76 */       if (results._outCenters != null) {
/* 77 */         this._outArray = new ArrayList(results._outCount);
/*    */ 
/* 79 */         for (i = 0; i < results._outCount; i++) {
/* 80 */           this._outArray.set(i, RasterColor.fromColorRef(results._outCenters[i]));
/*    */         }
/*    */       }
/* 83 */       return ret;
/*    */     }
/*    */     finally {
/* 86 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.KMeansCommand
 * JD-Core Version:    0.6.2
 */