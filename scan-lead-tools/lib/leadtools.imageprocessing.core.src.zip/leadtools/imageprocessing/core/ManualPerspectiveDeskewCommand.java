/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.LeadPoint;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ import leadtools.ltkrn;
/*    */ 
/*    */ public class ManualPerspectiveDeskewCommand extends RasterCommand
/*    */ {
/*    */   private LeadPoint[] _inputPoints;
/*    */   private LeadPoint[] _mappingPoints;
/*    */   private RasterImage _outImage;
/*    */ 
/*    */   public ManualPerspectiveDeskewCommand()
/*    */   {
/* 16 */     this._inputPoints = null;
/* 17 */     this._mappingPoints = null;
/* 18 */     this._outImage = null;
/*    */   }
/*    */ 
/*    */   public ManualPerspectiveDeskewCommand(LeadPoint[] inputPoints, LeadPoint[] mappingPoints) {
/* 22 */     this._inputPoints = ((LeadPoint[])inputPoints.clone());
/* 23 */     this._mappingPoints = ((LeadPoint[])mappingPoints.clone());
/* 24 */     this._outImage = null;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 29 */     return "Manual 3D Deskew";
/*    */   }
/*    */ 
/*    */   public LeadPoint[] getInputPoints() {
/* 33 */     return this._inputPoints;
/*    */   }
/*    */ 
/*    */   public void setInputPoints(LeadPoint[] value) {
/* 37 */     this._inputPoints = ((LeadPoint[])value.clone());
/*    */   }
/*    */ 
/*    */   public LeadPoint[] getMappingPoints() {
/* 41 */     return this._mappingPoints;
/*    */   }
/*    */ 
/*    */   public void setMappingPoints(LeadPoint[] value) {
/* 45 */     this._mappingPoints = ((LeadPoint[])value.clone());
/*    */   }
/*    */ 
/*    */   public RasterImage getOutputImage() {
/* 49 */     return this._outImage;
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 54 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 57 */       LeadPoint[] inPoints = new LeadPoint[4];
/* 58 */       LeadPoint[] mappingPoints = new LeadPoint[4];
/*    */ 
/* 60 */       if ((this._inputPoints.length < 4) || (this._mappingPoints.length < 4)) {
/* 61 */         int i = L_ERROR.ERROR_INV_PARAMETER.getValue(); return i;
/*    */       }
/* 63 */       for (int i = 0; i < 4; i++) {
/* 64 */         mappingPoints[i] = this._mappingPoints[i].clone();
/*    */       }
/*    */ 
/* 67 */       for (int i = 0; i < 4; i++) {
/* 68 */         inPoints[i] = this._inputPoints[i].clone();
/*    */       }
/*    */ 
/* 71 */       long[] outBitmap = new long[1];
/* 72 */       outBitmap[0] = ltkrn.AllocBitmapHandle();
/* 73 */       ret = ltimgcor.ManualPerspectiveDeskew(bitmap, inPoints, mappingPoints, outBitmap);
/* 74 */       if ((ret == L_ERROR.SUCCESS.getValue()) && 
/* 75 */         (outBitmap[0] != 0L)) {
/* 76 */         this._outImage = RasterImage.createFromBitmapHandle(outBitmap[0]);
/* 77 */         ltkrn.FreeBitmapHandle(outBitmap[0]);
/*    */       }
/*    */ 
/* 81 */       int j = ret; return j;
/*    */     }
/*    */     finally
/*    */     {
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.ManualPerspectiveDeskewCommand
 * JD-Core Version:    0.6.2
 */