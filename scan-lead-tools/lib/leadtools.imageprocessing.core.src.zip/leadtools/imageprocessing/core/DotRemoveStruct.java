/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ class DotRemoveStruct
/*    */ {
/*    */   public int _uFlags;
/*    */   public int _iMinDotWidth;
/*    */   public int _iMinDotHeight;
/*    */   public int _iMaxDotWidth;
/*    */   public int _iMaxDotHeight;
/*    */   public long _bitmapRegion;
/*    */   public long _rgn;
/*    */   public long _leadregion;
/*    */ 
/*    */   public DotRemoveStruct()
/*    */   {
/* 14 */     this._uFlags = 0;
/* 15 */     this._iMinDotWidth = 0;
/* 16 */     this._iMinDotHeight = 0;
/* 17 */     this._iMaxDotWidth = 0;
/* 18 */     this._iMaxDotHeight = 0;
/* 19 */     this._bitmapRegion = 0L;
/* 20 */     this._rgn = 0L;
/* 21 */     this._leadregion = 0L;
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.DotRemoveStruct
 * JD-Core Version:    0.6.2
 */