/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.LeadRect;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class MICRCodeDetectionCommand extends RasterCommand
/*    */ {
/*    */   private LeadRect _micrzone;
/*    */   private LeadRect _roi;
/*    */ 
/*    */   public MICRCodeDetectionCommand()
/*    */   {
/* 14 */     this._micrzone = LeadRect.getEmpty();
/* 15 */     this._roi = LeadRect.getEmpty();
/*    */   }
/*    */ 
/*    */   public LeadRect getMICRZone() {
/* 19 */     return this._micrzone;
/*    */   }
/*    */ 
/*    */   public void setSearchingZone(LeadRect value) {
/* 23 */     this._roi = value;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 28 */     return "Detect MICR Code";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 33 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 36 */       LeadRect inRect = LeadRect.fromLTRB(this._roi.getLeft(), this._roi.getTop(), this._roi.getRight(), this._roi.getBottom());
/* 37 */       LeadRect outRect = LeadRect.getEmpty();
/*    */ 
/* 39 */       ret = ltimgcor.MICRDetection(bitmap, inRect, outRect, 0);
/*    */       int i;
/* 40 */       if (ret != L_ERROR.SUCCESS.getValue()) {
/* 41 */         return ret;
/*    */       }
/* 43 */       this._micrzone = LeadRect.fromLTRB(outRect.getLeft(), outRect.getTop(), outRect.getRight(), outRect.getBottom());
/* 44 */       return ret;
/*    */     }
/*    */     finally {
/* 47 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.MICRCodeDetectionCommand
 * JD-Core Version:    0.6.2
 */