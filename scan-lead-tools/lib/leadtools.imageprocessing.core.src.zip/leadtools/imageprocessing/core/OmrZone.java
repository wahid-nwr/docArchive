/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.LeadRect;
/*    */ 
/*    */ public class OmrZone
/*    */ {
/*    */   private LeadRect _bounds;
/*    */   private int _confidence;
/*    */   private OmrZoneState _state;
/*    */ 
/*    */   public LeadRect getBounds()
/*    */   {
/* 11 */     return this._bounds;
/*    */   }
/*    */ 
/*    */   public void setBounds(LeadRect value) {
/* 15 */     this._bounds = value.clone();
/*    */   }
/*    */ 
/*    */   public int getConfidence() {
/* 19 */     return this._confidence;
/*    */   }
/*    */ 
/*    */   public void setConfidence(int value) {
/* 23 */     this._confidence = value;
/*    */   }
/*    */ 
/*    */   public OmrZoneState getState() {
/* 27 */     return this._state;
/*    */   }
/*    */ 
/*    */   public void setState(OmrZoneState value) {
/* 31 */     this._state = value;
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.OmrZone
 * JD-Core Version:    0.6.2
 */