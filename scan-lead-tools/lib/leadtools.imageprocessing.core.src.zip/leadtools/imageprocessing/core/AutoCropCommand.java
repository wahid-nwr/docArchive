/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class AutoCropCommand extends RasterCommand
/*    */ {
/*    */   private int _threshold;
/*    */ 
/*    */   public AutoCropCommand()
/*    */   {
/* 13 */     this._threshold = 0;
/*    */   }
/*    */ 
/*    */   public AutoCropCommand(int threshold) {
/* 17 */     this._threshold = threshold;
/*    */   }
/*    */ 
/*    */   public int getThreshold() {
/* 21 */     return this._threshold;
/*    */   }
/*    */   public void setThreshold(int value) {
/* 24 */     this._threshold = value;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 29 */     return "Auto Crop";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 34 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 37 */       ret = ltimgcor.AutoTrimBitmap(bitmap, this._threshold, 0);
/*    */ 
/* 39 */       if ((ret == L_ERROR.ERROR_NO_CHANGE.getValue()) || (ret == L_ERROR.ERROR_IMAGE_EMPTY.getValue()))
/* 40 */         ret = L_ERROR.SUCCESS.getValue();
/* 41 */       return ret;
/*    */     }
/*    */     finally {
/* 44 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.AutoCropCommand
 * JD-Core Version:    0.6.2
 */