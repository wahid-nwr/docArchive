/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ class FTARRAY
/*    */ {
/*    */   public int uWidth;
/*    */   public int uHeight;
/*    */   public LCOMPLEX[] acxData;
/*    */ 
/*    */   FTARRAY()
/*    */   {
/* 16 */     this.uWidth = 0;
/* 17 */     this.uHeight = 0;
/* 18 */     this.acxData = new LCOMPLEX[1];
/* 19 */     for (int i = 0; i < this.acxData.length; i++)
/* 20 */       this.acxData[i] = new LCOMPLEX();
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.FTARRAY
 * JD-Core Version:    0.6.2
 */