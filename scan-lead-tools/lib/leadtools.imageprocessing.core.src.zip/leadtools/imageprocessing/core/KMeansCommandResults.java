/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ class KMeansCommandResults
/*    */ {
/* 92 */   public int[] _outCenters = null;
/*    */   public int _outCount;
/*    */ 
/*    */   public KMeansCommandResults(int count, int[] outCenters)
/*    */   {
/* 96 */     this._outCenters = null;
/* 97 */     this._outCount = count;
/* 98 */     if ((count > 0) && (outCenters != null)) {
/* 99 */       this._outCenters = new int[count];
/* 100 */       for (int i = 0; i < count; i++)
/* 101 */         this._outCenters[i] = outCenters[i];
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.KMeansCommandResults
 * JD-Core Version:    0.6.2
 */