/*     */ package leadtools.imageprocessing.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import leadtools.L_ERROR;
/*     */ import leadtools.LeadRect;
/*     */ import leadtools.RasterImage;
/*     */ import leadtools.RasterImageChangedFlags;
/*     */ import leadtools.RasterRegion;
/*     */ import leadtools.imageprocessing.RasterCommand;
/*     */ import leadtools.ltkrn;
/*     */ 
/*     */ public class DotRemoveCommand extends RasterCommand
/*     */ {
/*     */   private int _flags;
/*     */   private int _minimumDotWidth;
/*     */   private int _minimumDotHeight;
/*     */   private int _maximumDotWidth;
/*     */   private int _maximumDotHeight;
/*     */   private RasterImage _imageRegion;
/*     */   private RasterRegion _region;
/*     */   private RasterImage _image;
/*     */   private ArrayList<DotRemoveCommandListener> _dotRemove;
/*     */ 
/*     */   public void addDotRemoveCommandListener(DotRemoveCommandListener listener)
/*     */   {
/*  26 */     this._dotRemove.add(listener);
/*     */   }
/*     */ 
/*     */   public void removeDotRemoveCommandListener(DotRemoveCommandListener listener) {
/*  30 */     this._dotRemove.remove(listener);
/*     */   }
/*     */ 
/*     */   public int getFlags() {
/*  34 */     return this._flags;
/*     */   }
/*     */ 
/*     */   public void setFlags(int value) {
/*  38 */     this._flags = value;
/*     */   }
/*     */ 
/*     */   public int getMinimumDotWidth() {
/*  42 */     return this._minimumDotWidth;
/*     */   }
/*     */ 
/*     */   public void setMinimumDotWidth(int value) {
/*  46 */     this._minimumDotWidth = value;
/*     */   }
/*     */ 
/*     */   public int getMinimumDotHeight() {
/*  50 */     return this._minimumDotHeight;
/*     */   }
/*     */ 
/*     */   public void setMinimumDotHeight(int value) {
/*  54 */     this._minimumDotHeight = value;
/*     */   }
/*     */ 
/*     */   public int getMaximumDotWidth() {
/*  58 */     return this._maximumDotWidth;
/*     */   }
/*     */ 
/*     */   public void setMaximumDotWidth(int value) {
/*  62 */     this._maximumDotWidth = value;
/*     */   }
/*     */ 
/*     */   public int getMaximumDotHeight() {
/*  66 */     return this._maximumDotHeight;
/*     */   }
/*     */ 
/*     */   public void setMaximumDotHeight(int value) {
/*  70 */     this._maximumDotHeight = value;
/*     */   }
/*     */ 
/*     */   public RasterRegion getRegion() {
/*  74 */     return this._region;
/*     */   }
/*     */ 
/*     */   public RasterImage getImageRegion() {
/*  78 */     return this._imageRegion;
/*     */   }
/*     */ 
/*     */   public DotRemoveCommand() {
/*  82 */     this._flags = (DotRemoveCommandFlags.USE_SIZE.getValue() | DotRemoveCommandFlags.USE_DIAGONALS.getValue());
/*  83 */     this._minimumDotWidth = 6;
/*  84 */     this._minimumDotHeight = 6;
/*  85 */     this._maximumDotWidth = 8;
/*  86 */     this._maximumDotHeight = 8;
/*  87 */     this._imageRegion = null;
/*  88 */     this._region = null;
/*  89 */     this._dotRemove = new ArrayList();
/*     */   }
/*     */ 
/*     */   public DotRemoveCommand(int flags, int minimumDotWidth, int minimumDotHeight, int maximumDotWidth, int maximumDotHeight) {
/*  93 */     this._flags = flags;
/*  94 */     this._minimumDotWidth = minimumDotWidth;
/*  95 */     this._minimumDotHeight = minimumDotHeight;
/*  96 */     this._maximumDotWidth = maximumDotWidth;
/*  97 */     this._maximumDotHeight = maximumDotHeight;
/*  98 */     this._dotRemove = new ArrayList();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 103 */     return "Dot Remove";
/*     */   }
/*     */ 
/*     */   private final int DoCallback(int leadRegion, int left, int top, int right, int bottom, int iWhiteCount, int iBlackCount)
/*     */   {
/* 109 */     int ret = L_ERROR.SUCCESS.getValue();
/*     */ 
/* 111 */     Iterator i$ = this._dotRemove.iterator(); if (i$.hasNext()) { DotRemoveCommandListener listener = (DotRemoveCommandListener)i$.next();
/* 112 */       LeadRect rc = LeadRect.fromLTRB(left, top, right, bottom);
/* 113 */       DotRemoveCommandEvent args = new DotRemoveCommandEvent(this, this._image, leadRegion != 0 ? new RasterRegion(leadRegion, false) : null, rc, iWhiteCount, iBlackCount);
/* 114 */       listener.onDotRemoveEvent(args);
/* 115 */       return args.getStatus().getValue();
/*     */     }
/*     */ 
/* 118 */     return ret;
/*     */   }
/*     */ 
/*     */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*     */   {
/* 123 */     int ret = L_ERROR.SUCCESS.getValue();
/* 124 */     long bitmapRegion = 0L;
/*     */     try
/*     */     {
/* 127 */       this._image = image;
/* 128 */       DotRemoveStruct dotRemove = new DotRemoveStruct();
/* 129 */       dotRemove._uFlags = this._flags;
/* 130 */       dotRemove._iMinDotWidth = this._minimumDotWidth;
/* 131 */       dotRemove._iMinDotHeight = this._minimumDotHeight;
/* 132 */       dotRemove._iMaxDotWidth = this._maximumDotWidth;
/* 133 */       dotRemove._iMaxDotHeight = this._maximumDotHeight;
/*     */ 
/* 136 */       if (((this._flags & DotRemoveCommandFlags.SINGLE_REGION.getValue()) == DotRemoveCommandFlags.SINGLE_REGION.getValue()) && ((this._flags & DotRemoveCommandFlags.LEAD_REGION.getValue()) == DotRemoveCommandFlags.LEAD_REGION.getValue()))
/*     */       {
/* 139 */         bitmapRegion = ltkrn.AllocBitmapHandle();
/* 140 */         dotRemove._bitmapRegion = bitmapRegion;
/*     */       }
/*     */ 
/* 143 */       ret = ltimgcor.DotRemoveBitmap(bitmap, dotRemove, this._dotRemove.size() > 0 ? this : null, 0);
/* 144 */       if (ret == L_ERROR.SUCCESS.getValue())
/*     */       {
/* 146 */         this._imageRegion = null;
/* 147 */         this._region = null;
/*     */ 
/* 150 */         if (((this._flags & DotRemoveCommandFlags.SINGLE_REGION.getValue()) == DotRemoveCommandFlags.SINGLE_REGION.getValue()) && ((this._flags & DotRemoveCommandFlags.LEAD_REGION.getValue()) == DotRemoveCommandFlags.LEAD_REGION.getValue()))
/*     */         {
/* 153 */           this._imageRegion = RasterImage.createFromBitmapHandle(bitmapRegion, true);
/*     */         }
/* 156 */         else if ((this._flags & DotRemoveCommandFlags.SINGLE_REGION.getValue()) == DotRemoveCommandFlags.SINGLE_REGION.getValue())
/*     */         {
/* 158 */           if (dotRemove._leadregion != 0L) {
/* 159 */             this._region = new RasterRegion(dotRemove._leadregion, true);
/* 160 */             ltkrn.DeleteLeadRgn(dotRemove._leadregion);
/* 161 */             dotRemove._leadregion = 0L;
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 166 */       return ret;
/*     */     }
/*     */     finally {
/* 169 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/* 170 */       if (bitmapRegion != 0L)
/* 171 */         ltkrn.FreeBitmapHandle(bitmapRegion);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.DotRemoveCommand
 * JD-Core Version:    0.6.2
 */