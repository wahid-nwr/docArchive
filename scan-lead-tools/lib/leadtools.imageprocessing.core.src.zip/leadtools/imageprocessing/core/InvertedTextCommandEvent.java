/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.LeadEvent;
/*    */ import leadtools.LeadRect;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterRegion;
/*    */ 
/*    */ public class InvertedTextCommandEvent extends LeadEvent
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private RasterImage _image;
/*    */   private RasterRegion _region;
/*    */   private LeadRect _boundingRectangle;
/*    */   private int _whiteCount;
/*    */   private int _blackCount;
/*    */   private RemoveStatus _status;
/*    */ 
/*    */   public InvertedTextCommandEvent(Object source, RasterImage image, RasterRegion region, LeadRect boundingRectangle, int whiteCount, int blackCount)
/*    */   {
/* 18 */     super(source);
/* 19 */     this._image = image;
/* 20 */     this._region = region;
/* 21 */     this._boundingRectangle = boundingRectangle;
/* 22 */     this._whiteCount = whiteCount;
/* 23 */     this._blackCount = blackCount;
/* 24 */     this._status = RemoveStatus.REMOVE;
/*    */   }
/*    */ 
/*    */   public RasterImage getImage() {
/* 28 */     return this._image;
/*    */   }
/*    */ 
/*    */   public RasterRegion getRegion() {
/* 32 */     return this._region;
/*    */   }
/*    */ 
/*    */   public LeadRect getBoundingRectangle() {
/* 36 */     return this._boundingRectangle;
/*    */   }
/*    */ 
/*    */   public int getWhiteCount() {
/* 40 */     return this._whiteCount;
/*    */   }
/*    */ 
/*    */   public int getBlackCount() {
/* 44 */     return this._blackCount;
/*    */   }
/*    */ 
/*    */   public RemoveStatus getStatus() {
/* 48 */     return this._status;
/*    */   }
/*    */ 
/*    */   public void setStatus(RemoveStatus value) {
/* 52 */     this._status = value;
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.InvertedTextCommandEvent
 * JD-Core Version:    0.6.2
 */