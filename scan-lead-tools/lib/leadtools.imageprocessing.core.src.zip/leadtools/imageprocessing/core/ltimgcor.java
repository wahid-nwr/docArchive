package leadtools.imageprocessing.core;

import leadtools.LeadPoint;
import leadtools.LeadRect;
import leadtools.RasterColor;
import leadtools.RasterColor16;

public class ltimgcor
{
  public static native int AutoTrimBitmap(long paramLong, int paramInt1, int paramInt2);

  public static native int GetAutoTrimRect(long paramLong, int paramInt1, LeadRect paramLeadRect, int paramInt2);

  public static native int AutoBinarizeBitmap(long paramLong, int paramInt1, int paramInt2);

  public static native int BlankPageDetectorBitmap(long paramLong, boolean[] paramArrayOfBoolean, int[] paramArrayOfInt, PageMarginsStruct paramPageMarginsStruct, int paramInt);

  public static native int BorderRemoveBitmap(long paramLong, BorderRemoveStruct paramBorderRemoveStruct, Object paramObject, int paramInt);

  public static native int ColorizeGrayBitmap(long paramLong1, long paramLong2, LTGrayColorStruct[] paramArrayOfLTGrayColorStruct, int paramInt1, int paramInt2);

  public static native int DotRemoveBitmap(long paramLong, DotRemoveStruct paramDotRemoveStruct, Object paramObject, int paramInt);

  public static native int InvertedTextBitmap(long paramLong, InvertedTextStruct paramInvertedTextStruct, Object paramObject, int paramInt);

  public static native int LineRemoveBitmap(long paramLong, LineRemoveStruct paramLineRemoveStruct, Object paramObject, int paramInt);

  public static native int SmoothBitmap(long paramLong, SmoothStruct paramSmoothStruct, Object paramObject, int paramInt);

  public static native int ApplyLinearVOILUT(long paramLong, double paramDouble1, double paramDouble2, int paramInt);

  public static native int ApplyLinearModalityLUT(long paramLong, double paramDouble1, double paramDouble2, int paramInt);

  public static native int ApplyModalityLUT(long paramLong, int[] paramArrayOfInt, DicomLutDescriptor paramDicomLutDescriptor, int paramInt);

  public static native int ApplyVOILUT(long paramLong, int[] paramArrayOfInt, DicomLutDescriptor paramDicomLutDescriptor, int paramInt);

  public static native int ApplyTransformationParameters(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);

  public static native int ConvertBitmapSignedToUnsigned(long paramLong, int paramInt1, int paramInt2);

  public static native int ConvertBitmapUnsignedToSigned(long paramLong, int paramInt);

  public static native int CorrelationBitmap(long paramLong1, long paramLong2, LeadPoint[] paramArrayOfLeadPoint, int paramInt1, int[] paramArrayOfInt, int paramInt2, int paramInt3, int paramInt4, int paramInt5);

  public static native int CorrelationListBitmap(long paramLong1, long paramLong2, LeadPoint[] paramArrayOfLeadPoint, int[] paramArrayOfInt1, int paramInt1, int[] paramArrayOfInt2, int paramInt2, int paramInt3, int paramInt4, int paramInt5);

  public static native int DeskewBitmap(long paramLong, int[] paramArrayOfInt, int paramInt1, int paramInt2);

  public static native int DeskewBitmapExt(long paramLong, int[] paramArrayOfInt, int paramInt1, int paramInt2, int paramInt3, int paramInt4);

  public static native int DespeckleBitmap(long paramLong, int paramInt);

  public static native int DigitalSubtractBitmap(long paramLong1, long paramLong2, int paramInt);

  public static native int GetLinearVOILUT(long paramLong, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, int paramInt);

  public static native int HalfToneBitmap(long paramLong1, int paramInt1, int paramInt2, int paramInt3, long paramLong2, int paramInt4);

  public static native int HighQualityRotateBitmap(long paramLong, int paramInt1, int paramInt2, int paramInt3);

  public static native int InvertedPageBitmap(long paramLong, boolean[] paramArrayOfBoolean, int paramInt);

  public static native int MaxFilterBitmap(long paramLong, int paramInt1, int paramInt2);

  public static native int MedianFilterBitmap(long paramLong, int paramInt1, int paramInt2);

  public static native int MinFilterBitmap(long paramLong, int paramInt1, int paramInt2);

  public static native int ShiftMinimumToZero(long paramLong, int[] paramArrayOfInt, int paramInt);

  public static native int GetMinMaxBits(long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt);

  public static native int GetMinMaxVal(long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt);

  public static native int MultiScaleEnhancementBitmap(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);

  public static native int SizeBitmapInterpolate(long paramLong, int paramInt1, int paramInt2, int paramInt3);

  public static native int ShiftBitmapData(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);

  public static native int SubtractBackgroundBitmap(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4);

  public static native int TissueEqualizeBitmap(long paramLong, int paramInt);

  public static native int WindowLevelBitmap(long paramLong, int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int paramInt3, int paramInt4, int paramInt5);

  public static native int WindowLevelBitmapExt(long paramLong, int paramInt1, int paramInt2, short[] paramArrayOfShort1, short[] paramArrayOfShort2, short[] paramArrayOfShort3, int paramInt3, int paramInt4, int paramInt5);

  public static native int ShiftZeroToNegative(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);

  public static native int CountLUTColors(RasterColor[] paramArrayOfRasterColor, int paramInt1, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt2);

  public static native int CountLUTColorsExt(RasterColor16[] paramArrayOfRasterColor16, int paramInt1, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt2);

  public static native int GetBitmapBackgroundColor(long paramLong, LeadRect[] paramArrayOfLeadRect, int paramInt1, RasterColor[] paramArrayOfRasterColor, int paramInt2);

  public static native int BasicOrientation(long paramLong, boolean[] paramArrayOfBoolean);

  public static native int OMR(long paramLong, OMRZONEDATA[] paramArrayOfOMRZONEDATA, int paramInt1, int paramInt2);

  public static native int AutoDocumentBinarization(long paramLong);

  public static native int AutoZoneBitmap(long paramLong, AutoZoneData paramAutoZoneData, int paramInt, long[] paramArrayOfLong);

  public static native int GetBitmapColorType(long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt);

  public static native int SearchRegMarksBitmap(long paramLong, SEARCHMARKS[] paramArrayOfSEARCHMARKS, int paramInt1, int paramInt2);

  public static native int GetTransformationParameters(long paramLong, LeadPoint[] paramArrayOfLeadPoint1, LeadPoint[] paramArrayOfLeadPoint2, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4, int[] paramArrayOfInt5, int paramInt);

  public static native int IsRegMarkBitmap(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);

  public static native int GetMarksCenterMassBitmap(long paramLong, LeadPoint[] paramArrayOfLeadPoint1, LeadPoint[] paramArrayOfLeadPoint2, int paramInt1, int paramInt2);

  public static native int AnalyzeBarcode(long paramLong, int[] paramArrayOfInt, LeadRect paramLeadRect, int paramInt);

  public static native int MICRDetection(long paramLong, LeadRect paramLeadRect1, LeadRect paramLeadRect2, int paramInt);

  public static native int FFTBitmap(long paramLong, int paramInt1, int paramInt2, LCOMPLEX[] paramArrayOfLCOMPLEX, int paramInt3);

  public static native int CLAHE(long paramLong, float paramFloat1, int paramInt1, float paramFloat2, int paramInt2, int paramInt3);

  public static native int ManualPerspectiveDeskew(long paramLong, LeadPoint[] paramArrayOfLeadPoint1, LeadPoint[] paramArrayOfLeadPoint2, long[] paramArrayOfLong);

  public static native int PerspectiveDeskew(long paramLong);

  public static native int OtsuThreshold(long paramLong, int paramInt);

  public static native int LevelsetBitmapRgn(long paramLong, int paramInt1, int paramInt2);

  public static native int LambdaConnectedness(long paramLong, int paramInt);

  public static native int TADAnisotropicDiffusion(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4);

  public static native int BlurDetection(long paramLong, boolean[] paramArrayOfBoolean, double[] paramArrayOfDouble);

  public static native int ShrinkWrapTool(long paramLong, int paramInt1, LeadPoint paramLeadPoint, int paramInt2, int paramInt3);

  public static native int SRADAnisotropicDiffusion(long paramLong, int paramInt1, int paramInt2, LeadRect paramLeadRect);

  public static native int Keystone(long paramLong, LeadPoint[] paramArrayOfLeadPoint, long[] paramArrayOfLong);

  public static native int WatershedBitmap(long paramLong, WatershedPoints paramWatershedPoints);

  public static native int AlignImages(long paramLong1, long paramLong2, long[] paramArrayOfLong, LeadPoint[] paramArrayOfLeadPoint1, LeadPoint[] paramArrayOfLeadPoint2, int paramInt1, int paramInt2);

  public static native int KMeansBitmapSegmentation(long paramLong, int paramInt1, KMeansCommandResults paramKMeansCommandResults, int[] paramArrayOfInt, int paramInt2);

  public static native int TextBlurDetector(long paramLong, TextBlurDetectorResults[] paramArrayOfTextBlurDetectorResults);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.ltimgcor
 * JD-Core Version:    0.6.2
 */