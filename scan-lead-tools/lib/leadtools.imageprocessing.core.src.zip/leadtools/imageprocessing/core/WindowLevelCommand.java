/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterByteOrder;
/*    */ import leadtools.RasterColor;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class WindowLevelCommand extends RasterCommand
/*    */ {
/*    */   private RasterColor[] _lookupTable;
/*    */   private int _lowBit;
/*    */   private int _highBit;
/*    */   private RasterByteOrder _order;
/*    */ 
/*    */   public WindowLevelCommand()
/*    */   {
/* 17 */     this._lookupTable = new RasterColor[1];
/* 18 */     this._lowBit = 0;
/* 19 */     this._highBit = 15;
/* 20 */     this._order = RasterByteOrder.BGR;
/*    */   }
/*    */ 
/*    */   public WindowLevelCommand(int lowBit, int highBit, RasterColor[] lookupTable, RasterByteOrder order) {
/* 24 */     this._lookupTable = lookupTable;
/* 25 */     this._lowBit = lowBit;
/* 26 */     this._highBit = highBit;
/* 27 */     this._order = order;
/*    */   }
/*    */ 
/*    */   public int getLowBit() {
/* 31 */     return this._lowBit;
/*    */   }
/*    */ 
/*    */   public void setLowBit(int value) {
/* 35 */     this._lowBit = value;
/*    */   }
/*    */ 
/*    */   public int getHighBit() {
/* 39 */     return this._highBit;
/*    */   }
/*    */ 
/*    */   public void setHighBit(int value) {
/* 43 */     this._highBit = value;
/*    */   }
/*    */ 
/*    */   public RasterColor[] getLookupTable() {
/* 47 */     return this._lookupTable;
/*    */   }
/*    */   public void setLookupTable(RasterColor[] value) {
/* 50 */     this._lookupTable = value;
/*    */   }
/*    */ 
/*    */   public RasterByteOrder getOrder() {
/* 54 */     return this._order;
/*    */   }
/*    */ 
/*    */   public void setOrder(RasterByteOrder value) {
/* 58 */     this._order = value;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 63 */     return "WindowLevel";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 68 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 71 */       int length = this._lookupTable != null ? this._lookupTable.length : 0;
/*    */       int[] lutR;
/* 73 */       if (length != 0) {
/* 74 */         lutR = null;
/* 75 */         int[] lutG = null;
/* 76 */         int[] lutB = null;
/*    */ 
/* 78 */         lutR = new int[length];
/* 79 */         lutG = new int[length];
/* 80 */         lutB = new int[length];
/*    */ 
/* 82 */         for (int i = 0; i < length; i++) {
/* 83 */           lutR[i] = this._lookupTable[i].getR();
/* 84 */           lutG[i] = this._lookupTable[i].getG();
/* 85 */           lutB[i] = this._lookupTable[i].getB();
/*    */         }
/*    */ 
/* 88 */         ret = ltimgcor.WindowLevelBitmap(bitmap, this._lowBit, this._highBit, lutR, lutG, lutB, length, this._order.getValue(), 0);
/*    */       }
/*    */       else {
/* 91 */         ret = ltimgcor.WindowLevelBitmap(bitmap, this._lowBit, this._highBit, null, null, null, 0, this._order.getValue(), 0);
/*    */       }
/* 93 */       return ret;
/*    */     }
/*    */     finally {
/* 96 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.WindowLevelCommand
 * JD-Core Version:    0.6.2
 */