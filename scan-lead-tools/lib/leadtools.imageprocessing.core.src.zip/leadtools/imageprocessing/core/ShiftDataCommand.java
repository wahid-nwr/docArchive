/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ import leadtools.ltkrn;
/*    */ 
/*    */ public class ShiftDataCommand extends RasterCommand
/*    */ {
/*    */   private RasterImage _destinationImage;
/*    */   private int _sourceLowBit;
/*    */   private int _sourceHighBit;
/*    */   private int _destinationLowBit;
/*    */   private int _destinationBitsPerPixel;
/*    */ 
/*    */   public RasterImage getDestinationImage()
/*    */   {
/* 17 */     return this._destinationImage;
/*    */   }
/*    */ 
/*    */   public int getSourceLowBit() {
/* 21 */     return this._sourceLowBit;
/*    */   }
/*    */ 
/*    */   public void setSourceLowBit(int value) {
/* 25 */     this._sourceLowBit = value;
/*    */   }
/*    */ 
/*    */   public int getSourceHighBit() {
/* 29 */     return this._sourceHighBit;
/*    */   }
/*    */ 
/*    */   public void setSourceHighBit(int value) {
/* 33 */     this._sourceHighBit = value;
/*    */   }
/*    */ 
/*    */   public int getDestinationLowBit() {
/* 37 */     return this._destinationLowBit;
/*    */   }
/*    */ 
/*    */   public void setDestinationLowBit(int value) {
/* 41 */     this._destinationLowBit = value;
/*    */   }
/*    */ 
/*    */   public int getDestinationBitsPerPixel() {
/* 45 */     return this._destinationBitsPerPixel;
/*    */   }
/*    */ 
/*    */   public void setDestinationBitsPerPixel(int value) {
/* 49 */     this._destinationBitsPerPixel = value;
/*    */   }
/*    */ 
/*    */   public ShiftDataCommand() {
/* 53 */     this._destinationImage = null;
/* 54 */     this._sourceLowBit = 0;
/* 55 */     this._sourceHighBit = 7;
/* 56 */     this._destinationLowBit = 0;
/* 57 */     this._destinationBitsPerPixel = 0;
/*    */   }
/*    */ 
/*    */   public ShiftDataCommand(int sourceLowBit, int sourceHighBit, int destinationLowBit, int destinationBitsPerPixel) {
/* 61 */     this._destinationImage = null;
/* 62 */     this._sourceLowBit = sourceLowBit;
/* 63 */     this._sourceHighBit = sourceHighBit;
/* 64 */     this._destinationLowBit = destinationLowBit;
/* 65 */     this._destinationBitsPerPixel = destinationBitsPerPixel;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 70 */     return "Shift Data";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 75 */     int ret = L_ERROR.SUCCESS.getValue();
/* 76 */     long destBitmap = 0L;
/*    */     try
/*    */     {
/* 79 */       this._destinationImage = null;
/*    */ 
/* 81 */       destBitmap = ltkrn.AllocBitmapHandle();
/* 82 */       ret = ltimgcor.ShiftBitmapData(destBitmap, bitmap, this._sourceLowBit, this._sourceHighBit, this._destinationLowBit, this._destinationBitsPerPixel, 0);
/* 83 */       if (ret == L_ERROR.SUCCESS.getValue()) {
/* 84 */         this._destinationImage = RasterImage.createFromBitmapHandle(destBitmap);
/*    */       }
/* 86 */       return ret;
/*    */     }
/*    */     finally {
/* 89 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/* 90 */       ltkrn.FreeBitmapHandle(destBitmap);
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.ShiftDataCommand
 * JD-Core Version:    0.6.2
 */