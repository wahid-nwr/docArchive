/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.LeadRect;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class AutoCropRectangleCommand extends RasterCommand
/*    */ {
/*    */   private int _threshold;
/*    */   private LeadRect _rectangle;
/*    */ 
/*    */   public AutoCropRectangleCommand()
/*    */   {
/* 14 */     this._threshold = 128;
/* 15 */     this._rectangle = new LeadRect(0, 0, 0, 0);
/*    */   }
/*    */ 
/*    */   public AutoCropRectangleCommand(int threshold) {
/* 19 */     this._threshold = threshold;
/* 20 */     this._rectangle = new LeadRect(0, 0, 0, 0);
/*    */   }
/*    */ 
/*    */   public int getThreshold() {
/* 24 */     return this._threshold;
/*    */   }
/*    */ 
/*    */   public void setThreshold(int value) {
/* 28 */     this._threshold = value;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 33 */     return "Auto Crop Rectangle";
/*    */   }
/*    */ 
/*    */   public LeadRect getRectangle() {
/* 37 */     return this._rectangle;
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 42 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 45 */       ret = ltimgcor.GetAutoTrimRect(bitmap, this._threshold, this._rectangle, 0);
/* 46 */       return ret;
/*    */     }
/*    */     finally {
/* 49 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.AutoCropRectangleCommand
 * JD-Core Version:    0.6.2
 */