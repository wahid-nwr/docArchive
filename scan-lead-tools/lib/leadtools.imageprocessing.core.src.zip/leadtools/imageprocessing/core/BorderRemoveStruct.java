/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ class BorderRemoveStruct
/*    */ {
/*    */   public int _uFlags;
/*    */   public int _uBorderToRemove;
/*    */   public int _iBorderPercent;
/*    */   public int _iWhiteNoiseLength;
/*    */   public int _iVariance;
/*    */   public long _hRgn;
/*    */   public long _bitmapRegion;
/*    */ 
/*    */   public BorderRemoveStruct()
/*    */   {
/* 13 */     this._uFlags = 0;
/* 14 */     this._uBorderToRemove = 0;
/* 15 */     this._iBorderPercent = 0;
/* 16 */     this._iWhiteNoiseLength = 0;
/* 17 */     this._iVariance = 0;
/* 18 */     this._hRgn = 0L;
/* 19 */     this._bitmapRegion = 0L;
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.BorderRemoveStruct
 * JD-Core Version:    0.6.2
 */