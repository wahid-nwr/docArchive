/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class HalfToneCommand extends RasterCommand
/*    */ {
/*    */   private HalfToneCommandType _type;
/*    */   private int _angle;
/*    */   private int _dimension;
/*    */   private RasterImage _userDefinedImage;
/*    */ 
/*    */   public HalfToneCommand()
/*    */   {
/* 15 */     this._type = HalfToneCommandType.PRINT;
/* 16 */     this._angle = 0;
/* 17 */     this._dimension = 3;
/* 18 */     this._userDefinedImage = null;
/*    */   }
/*    */ 
/*    */   public HalfToneCommand(HalfToneCommandType type, int angle, int dimension, RasterImage userDefinedImage) {
/* 22 */     this._type = type;
/* 23 */     this._angle = angle;
/* 24 */     this._dimension = dimension;
/* 25 */     this._userDefinedImage = userDefinedImage;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 30 */     return "HalfTone";
/*    */   }
/*    */ 
/*    */   public HalfToneCommandType getType() {
/* 34 */     return this._type;
/*    */   }
/*    */ 
/*    */   public void setType(HalfToneCommandType value) {
/* 38 */     this._type = value;
/*    */   }
/*    */ 
/*    */   public int getAngle() {
/* 42 */     return this._angle;
/*    */   }
/*    */ 
/*    */   public void setAngle(int value) {
/* 46 */     this._angle = value;
/*    */   }
/*    */ 
/*    */   public int getDimension() {
/* 50 */     return this._dimension;
/*    */   }
/*    */ 
/*    */   public void setDimension(int value) {
/* 54 */     this._dimension = value;
/*    */   }
/*    */ 
/*    */   public RasterImage getUserDefinedImage() {
/* 58 */     return this._userDefinedImage;
/*    */   }
/*    */ 
/*    */   public void setUserDefinedImage(RasterImage value) {
/* 62 */     this._userDefinedImage = value;
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 67 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 70 */       RasterImage userImage = this._userDefinedImage;
/* 71 */       ret = ltimgcor.HalfToneBitmap(bitmap, this._type.getValue(), this._angle, this._dimension, userImage != null ? userImage.getBitmapList() : 0L, 0);
/* 72 */       return ret;
/*    */     }
/*    */     finally {
/* 75 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.HalfToneCommand
 * JD-Core Version:    0.6.2
 */