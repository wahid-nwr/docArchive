/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.LeadEvent;
/*    */ import leadtools.RasterImage;
/*    */ 
/*    */ public class SmoothCommandEvent extends LeadEvent
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private RasterImage _image;
/*    */   private SmoothCommandBumpNickType _bumpNick;
/* 11 */   private int _startRow = 0;
/* 12 */   private int _startColumn = 0;
/* 13 */   private int _length = 0;
/*    */   private SmoothCommandDirectionType _direction;
/*    */   private RemoveStatus _status;
/*    */ 
/*    */   public RasterImage getImage()
/*    */   {
/* 18 */     return this._image;
/*    */   }
/*    */ 
/*    */   public SmoothCommandBumpNickType getBumpNick() {
/* 22 */     return this._bumpNick;
/*    */   }
/*    */ 
/*    */   public int getStartRow() {
/* 26 */     return this._startRow;
/*    */   }
/*    */ 
/*    */   public int getStartColumn() {
/* 30 */     return this._startColumn;
/*    */   }
/*    */ 
/*    */   public int getLength() {
/* 34 */     return this._length;
/*    */   }
/*    */ 
/*    */   public SmoothCommandDirectionType getDirection() {
/* 38 */     return this._direction;
/*    */   }
/*    */ 
/*    */   public RemoveStatus getStatus() {
/* 42 */     return this._status;
/*    */   }
/*    */   public void setStatus(RemoveStatus value) {
/* 45 */     this._status = value;
/*    */   }
/*    */ 
/*    */   public SmoothCommandEvent(Object source, RasterImage image, SmoothCommandBumpNickType bumpNick, int startRow, int startColumn, int length, SmoothCommandDirectionType direction) {
/* 49 */     super(source);
/* 50 */     this._image = image;
/* 51 */     this._bumpNick = bumpNick;
/* 52 */     this._startRow = startRow;
/* 53 */     this._startColumn = startColumn;
/* 54 */     this._length = length;
/* 55 */     this._direction = direction;
/* 56 */     this._status = RemoveStatus.REMOVE;
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.SmoothCommandEvent
 * JD-Core Version:    0.6.2
 */