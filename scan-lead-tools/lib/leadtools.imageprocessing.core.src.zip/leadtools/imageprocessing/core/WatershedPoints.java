/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.LeadPoint;
/*    */ 
/*    */ class WatershedPoints
/*    */ {
/* 67 */   LeadPoint[][] _points = (LeadPoint[][])null;
/* 68 */   int[] _lengths = null;
/* 69 */   int _size = 0;
/*    */ 
/*    */   public WatershedPoints(int size) {
/* 72 */     this._size = size;
/* 73 */     if (size > 0) {
/* 74 */       this._lengths = new int[size];
/* 75 */       this._points = new LeadPoint[size][];
/*    */     }
/*    */   }
/*    */ 
/*    */   public int[] getLengths() {
/* 80 */     return this._lengths;
/*    */   }
/*    */ 
/*    */   public LeadPoint[] getPoints(int index) {
/* 84 */     if ((index >= 0) && (index < this._size)) {
/* 85 */       return this._points[index];
/*    */     }
/*    */ 
/* 88 */     return null;
/*    */   }
/*    */ 
/*    */   public void setPoints(int index, LeadPoint[] points) {
/* 92 */     if ((index < 0) || (index >= this._size)) {
/* 93 */       return;
/*    */     }
/* 95 */     int len = points.length;
/* 96 */     this._points[index] = new LeadPoint[len];
/* 97 */     this._lengths[index] = len;
/*    */ 
/* 99 */     for (int i = 0; i < len; i++)
/* 100 */       this._points[index][i] = points[i].clone();
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.WatershedPoints
 * JD-Core Version:    0.6.2
 */