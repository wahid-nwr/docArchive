/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.LeadEvent;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterRegion;
/*    */ 
/*    */ public class LineRemoveCommandEvent extends LeadEvent
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private RasterImage _image;
/*    */   private RasterRegion _region;
/*    */   private int _startRow;
/*    */   private int _startColumn;
/*    */   private int _length;
/*    */   private RemoveStatus _status;
/*    */ 
/*    */   public LineRemoveCommandEvent(Object source, RasterImage image, RasterRegion region, int startRow, int startColumn, int length)
/*    */   {
/* 17 */     super(source);
/* 18 */     this._image = image;
/* 19 */     this._region = region;
/* 20 */     this._startRow = startRow;
/* 21 */     this._startColumn = startColumn;
/* 22 */     this._length = length;
/* 23 */     this._status = RemoveStatus.REMOVE;
/*    */   }
/*    */ 
/*    */   public RasterImage getImage() {
/* 27 */     return this._image;
/*    */   }
/*    */ 
/*    */   public RasterRegion getRegion() {
/* 31 */     return this._region;
/*    */   }
/*    */ 
/*    */   public int getStartRow() {
/* 35 */     return this._startRow;
/*    */   }
/*    */ 
/*    */   public int getStartColumn() {
/* 39 */     return this._startColumn;
/*    */   }
/*    */ 
/*    */   public int getLength() {
/* 43 */     return this._length;
/*    */   }
/*    */ 
/*    */   public RemoveStatus getStatus() {
/* 47 */     return this._status;
/*    */   }
/*    */ 
/*    */   public void setStatus(RemoveStatus value) {
/* 51 */     this._status = value;
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.LineRemoveCommandEvent
 * JD-Core Version:    0.6.2
 */