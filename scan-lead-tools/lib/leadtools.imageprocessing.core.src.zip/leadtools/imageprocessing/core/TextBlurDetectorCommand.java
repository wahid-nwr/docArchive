/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.LeadRect;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class TextBlurDetectorCommand extends RasterCommand
/*    */ {
/*    */   private ArrayList<LeadRect> _nonBlurredBlocks;
/*    */   private ArrayList<LeadRect> _blurredBlocks;
/*    */   private LeadRect _combinedTextBlocks;
/*    */ 
/*    */   public String toString()
/*    */   {
/* 19 */     return "Text Blur Detector";
/*    */   }
/*    */ 
/*    */   public TextBlurDetectorCommand() {
/* 23 */     this._nonBlurredBlocks = null;
/* 24 */     this._blurredBlocks = null;
/* 25 */     this._combinedTextBlocks = LeadRect.getEmpty();
/*    */   }
/*    */ 
/*    */   public ArrayList<LeadRect> getInFocusBlocks() {
/* 29 */     return this._nonBlurredBlocks;
/*    */   }
/*    */ 
/*    */   public ArrayList<LeadRect> getOutOfFocusBlocks() {
/* 33 */     return this._blurredBlocks;
/*    */   }
/*    */ 
/*    */   public LeadRect getCombinedTextBlocks() {
/* 37 */     return this._combinedTextBlocks;
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 42 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 45 */       TextBlurDetectorResults[] results = new TextBlurDetectorResults[1];
/* 46 */       results[0] = new TextBlurDetectorResults(0, 0, 0, 0, 0, 0);
/* 47 */       ret = ltimgcor.TextBlurDetector(bitmap, results);
/* 48 */       if (ret != L_ERROR.SUCCESS.getValue()) {
/* 49 */         return ret;
/*    */       }
/* 51 */       if (results[0]._nonBlurredBlocks.length != 0)
/* 52 */         for (int i = 0; i < results[0]._nonBlurredBlockCount; i++)
/* 53 */           this._nonBlurredBlocks.add(results[0]._nonBlurredBlocks[i].clone());
/*    */       int i;
/* 56 */       if (results[0]._blurredBlocks.length != 0) {
/* 57 */         for (i = 0; i < results[0]._blurredBlockCount; i++) {
/* 58 */           this._blurredBlocks.add(results[0]._blurredBlocks[i].clone());
/*    */         }
/*    */       }
/*    */ 
/* 62 */       this._combinedTextBlocks = results[0]._combinedTextBlocks.clone();
/* 63 */       return ret;
/*    */     }
/*    */     finally {
/* 66 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.TextBlurDetectorCommand
 * JD-Core Version:    0.6.2
 */