/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum ShrinkWrapFlags
/*    */ {
/*  5 */   RGN_AND(0), 
/*  6 */   RGN_SET(1), 
/*  7 */   RGN_AND_NOT_BITMAP(2), 
/*  8 */   RGN_AND_NOT_RGN(3), 
/*  9 */   RGN_OR(4), 
/* 10 */   RGN_XOR(5), 
/* 11 */   RGN_SET_NOT(6), 
/* 12 */   SHRINK_RECT(8), 
/* 13 */   SHRINK_CIRCLE(16);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, ShrinkWrapFlags> mappings;
/*    */ 
/* 18 */   private static HashMap<Integer, ShrinkWrapFlags> getMappings() { if (mappings == null) {
/* 19 */       synchronized (ShrinkWrapFlags.class) {
/* 20 */         if (mappings == null) {
/* 21 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 25 */     return mappings; }
/*    */ 
/*    */   private ShrinkWrapFlags(int value)
/*    */   {
/* 29 */     this.intValue = value;
/* 30 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue() {
/* 34 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static ShrinkWrapFlags forValue(int value) {
/* 38 */     return (ShrinkWrapFlags)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.ShrinkWrapFlags
 * JD-Core Version:    0.6.2
 */