/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum BorderRemoveBorderFlags
/*    */ {
/*  6 */   NONE(0), 
/*  7 */   LEFT(1), 
/*  8 */   TOP(4), 
/*  9 */   RIGHT(2), 
/* 10 */   BOTTOM(8), 
/* 11 */   ALL(15);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, BorderRemoveBorderFlags> mappings;
/*    */ 
/* 17 */   private static HashMap<Integer, BorderRemoveBorderFlags> getMappings() { if (mappings == null) {
/* 18 */       synchronized (BorderRemoveBorderFlags.class) {
/* 19 */         if (mappings == null) {
/* 20 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 24 */     return mappings; }
/*    */ 
/*    */   private BorderRemoveBorderFlags(int value)
/*    */   {
/* 28 */     this.intValue = value;
/* 29 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue() {
/* 33 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static BorderRemoveBorderFlags forValue(int value) {
/* 37 */     return (BorderRemoveBorderFlags)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.BorderRemoveBorderFlags
 * JD-Core Version:    0.6.2
 */