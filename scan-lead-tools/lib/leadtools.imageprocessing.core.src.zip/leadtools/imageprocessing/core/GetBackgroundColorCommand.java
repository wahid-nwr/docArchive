/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.LeadRect;
/*    */ import leadtools.RasterColor;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ class GetBackgroundColorCommand extends RasterCommand
/*    */ {
/*    */   private List<LeadRect> _rectangles;
/*    */   private List<RasterColor> _backgroundColors;
/*    */ 
/*    */   public GetBackgroundColorCommand()
/*    */   {
/* 17 */     this._rectangles = new ArrayList();
/* 18 */     this._backgroundColors = new ArrayList();
/*    */   }
/*    */ 
/*    */   public List<LeadRect> getRectangles() {
/* 22 */     return this._rectangles;
/*    */   }
/*    */ 
/*    */   public List<RasterColor> getBackgroundColors() {
/* 26 */     return this._backgroundColors;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 31 */     return "Get Background Color";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 36 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */ 
/* 38 */     LeadRect[] LeadRects = null;
/* 39 */     RasterColor[] rgbs = null;
/*    */     try
/*    */     {
/* 43 */       this._backgroundColors.clear();
/*    */ 
/* 45 */       int count = this._rectangles.size();
/* 46 */       if (count > 0)
/*    */       {
/* 49 */         LeadRects = new LeadRect[count];
/* 50 */         rgbs = new RasterColor[count];
/*    */ 
/* 52 */         i = 0;
/* 53 */         for (LeadRect rectangle : this._rectangles)
/*    */         {
/* 55 */           LeadRects[i] = new LeadRect(rectangle.getLeft(), rectangle.getTop(), rectangle.getWidth(), rectangle.getHeight());
/* 56 */           i++;
/*    */         }
/*    */ 
/* 59 */         ret = ltimgcor.GetBitmapBackgroundColor(bitmap, LeadRects, count, rgbs, 0);
/*    */ 
/* 61 */         if (ret == L_ERROR.SUCCESS.getValue())
/*    */         {
/* 63 */           for (i = 0; i < count; i++) {
/* 64 */             RasterColor color = rgbs[i].clone();
/* 65 */             this._backgroundColors.add(color);
/*    */           }
/*    */         }
/*    */ 
/*    */       }
/*    */       else
/*    */       {
/* 72 */         ret = L_ERROR.SUCCESS.getValue();
/*    */       }
/* 74 */       int i = ret; return i;
/*    */     }
/*    */     finally
/*    */     {
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.GetBackgroundColorCommand
 * JD-Core Version:    0.6.2
 */