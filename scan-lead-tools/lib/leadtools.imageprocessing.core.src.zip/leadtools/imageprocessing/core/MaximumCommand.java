/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class MaximumCommand extends RasterCommand
/*    */ {
/*    */   private int _dimension;
/*    */ 
/*    */   public MaximumCommand()
/*    */   {
/* 12 */     this._dimension = 3;
/*    */   }
/*    */ 
/*    */   public int getDimension() {
/* 16 */     return this._dimension;
/*    */   }
/*    */ 
/*    */   public void setDimension(int value) {
/* 20 */     this._dimension = value;
/*    */   }
/*    */ 
/*    */   public MaximumCommand(int dimension) {
/* 24 */     this._dimension = dimension;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 29 */     return "Maximum";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 34 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 37 */       ret = ltimgcor.MaxFilterBitmap(bitmap, this._dimension, 0);
/* 38 */       return ret;
/*    */     }
/*    */     finally {
/* 41 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.MaximumCommand
 * JD-Core Version:    0.6.2
 */