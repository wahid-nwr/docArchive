/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ class LTGrayColorStruct
/*    */ {
/*    */   public int _uThreshold;
/*    */   public int _rgbBlue;
/*    */   public int _rgbGreen;
/*    */   public int _rgbRed;
/*    */ 
/*    */   public LTGrayColorStruct()
/*    */   {
/* 87 */     this._uThreshold = 0;
/* 88 */     this._rgbBlue = 0;
/* 89 */     this._rgbGreen = 0;
/* 90 */     this._rgbRed = 0;
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.LTGrayColorStruct
 * JD-Core Version:    0.6.2
 */