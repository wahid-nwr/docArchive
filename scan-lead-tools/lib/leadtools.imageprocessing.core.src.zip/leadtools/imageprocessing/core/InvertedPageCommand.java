/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class InvertedPageCommand extends RasterCommand
/*    */ {
/*    */   private int _flags;
/*    */   private boolean _isInverted;
/*    */ 
/*    */   public InvertedPageCommand()
/*    */   {
/* 13 */     this._flags = InvertedPageCommandFlags.NONE.getValue();
/* 14 */     this._isInverted = false;
/*    */   }
/*    */ 
/*    */   public InvertedPageCommand(int flags) {
/* 18 */     this._flags = flags;
/* 19 */     this._isInverted = false;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 24 */     return "InvertedPage";
/*    */   }
/*    */ 
/*    */   public int getFlags() {
/* 28 */     return this._flags;
/*    */   }
/*    */ 
/*    */   public void setFlags(int value) {
/* 32 */     this._flags = value;
/*    */   }
/*    */ 
/*    */   public boolean isInverted() {
/* 36 */     return this._isInverted;
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 41 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 44 */       boolean[] isInverted = new boolean[1];
/*    */ 
/* 46 */       ret = ltimgcor.InvertedPageBitmap(bitmap, isInverted, this._flags);
/* 47 */       if (ret == L_ERROR.SUCCESS.getValue()) {
/* 48 */         this._isInverted = isInverted[0];
/*    */       }
/*    */ 
/* 51 */       return ret;
/*    */     }
/*    */     finally {
/* 54 */       image.updateCurrentBitmapHandle();
/* 55 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.InvertedPageCommand
 * JD-Core Version:    0.6.2
 */