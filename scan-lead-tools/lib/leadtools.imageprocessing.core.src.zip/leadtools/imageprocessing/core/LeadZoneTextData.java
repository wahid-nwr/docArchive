/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import leadtools.LeadRect;
/*    */ 
/*    */ public class LeadZoneTextData
/*    */ {
/*    */   private List<LeadRect> _textLines;
/*    */ 
/*    */   public LeadZoneTextData()
/*    */   {
/* 12 */     this._textLines = new ArrayList();
/*    */   }
/*    */ 
/*    */   public List<LeadRect> getTextLines() {
/* 16 */     return this._textLines;
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.LeadZoneTextData
 * JD-Core Version:    0.6.2
 */