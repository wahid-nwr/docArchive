package leadtools.imageprocessing.core;

public abstract interface BorderRemoveCommandListener
{
  public abstract void onBorderRemoveEvent(BorderRemoveCommandEvent paramBorderRemoveCommandEvent);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.BorderRemoveCommandListener
 * JD-Core Version:    0.6.2
 */