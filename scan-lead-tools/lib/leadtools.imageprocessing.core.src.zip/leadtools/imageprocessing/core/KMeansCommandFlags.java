/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum KMeansCommandFlags
/*    */ {
/*  5 */   KMEANS_RANDOM(1), 
/*  6 */   KMEANS_UNIFORM(2), 
/*  7 */   KMEANS_USERDEFINED(3);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, KMeansCommandFlags> mappings;
/*    */ 
/* 12 */   private static HashMap<Integer, KMeansCommandFlags> getMappings() { if (mappings == null) {
/* 13 */       synchronized (KMeansCommandFlags.class) {
/* 14 */         if (mappings == null) {
/* 15 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 19 */     return mappings; }
/*    */ 
/*    */   private KMeansCommandFlags(int value)
/*    */   {
/* 23 */     this.intValue = value;
/* 24 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue() {
/* 28 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static KMeansCommandFlags forValue(int value) {
/* 32 */     return (KMeansCommandFlags)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.KMeansCommandFlags
 * JD-Core Version:    0.6.2
 */