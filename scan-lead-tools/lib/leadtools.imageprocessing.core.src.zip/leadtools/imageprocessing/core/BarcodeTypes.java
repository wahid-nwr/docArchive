/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ public enum BarcodeTypes
/*    */ {
/*  4 */   UNKOWN(0), 
/*  5 */   LINEAR_BARCODE(1), 
/*  6 */   QR_BARCODE(2), 
/*  7 */   DATAMATRIX_BARCODE(3);
/*    */ 
/*    */   private int intValue;
/*    */ 
/*    */   private BarcodeTypes(int value) {
/* 12 */     this.intValue = value;
/*    */   }
/*    */ 
/*    */   public int getValue() {
/* 16 */     return this.intValue;
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.BarcodeTypes
 * JD-Core Version:    0.6.2
 */