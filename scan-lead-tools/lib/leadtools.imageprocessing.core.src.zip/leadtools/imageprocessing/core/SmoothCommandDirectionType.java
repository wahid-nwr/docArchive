/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum SmoothCommandDirectionType
/*    */ {
/*  4 */   HORIZONTAL(0), 
/*  5 */   VERTICAL(1);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, SmoothCommandDirectionType> mappings;
/*    */ 
/* 10 */   private static HashMap<Integer, SmoothCommandDirectionType> getMappings() { if (mappings == null)
/*    */     {
/* 12 */       synchronized (SmoothCommandDirectionType.class) {
/* 13 */         if (mappings == null) {
/* 14 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 18 */     return mappings; }
/*    */ 
/*    */   private SmoothCommandDirectionType(int value)
/*    */   {
/* 22 */     this.intValue = value;
/* 23 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue() {
/* 27 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static SmoothCommandDirectionType forValue(int value) {
/* 31 */     return (SmoothCommandDirectionType)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.SmoothCommandDirectionType
 * JD-Core Version:    0.6.2
 */