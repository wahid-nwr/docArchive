/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class MinimumCommand extends RasterCommand
/*    */ {
/*    */   private int _dimension;
/*    */ 
/*    */   public int getDimension()
/*    */   {
/* 12 */     return this._dimension;
/*    */   }
/*    */ 
/*    */   public void setDimension(int value) {
/* 16 */     this._dimension = value;
/*    */   }
/*    */ 
/*    */   public MinimumCommand() {
/* 20 */     this._dimension = 0;
/*    */   }
/*    */ 
/*    */   public MinimumCommand(int dimension) {
/* 24 */     this._dimension = dimension;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 29 */     return "Minimum";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 34 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 37 */       ret = ltimgcor.MinFilterBitmap(bitmap, this._dimension, 0);
/* 38 */       return ret;
/*    */     }
/*    */     finally {
/* 41 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.MinimumCommand
 * JD-Core Version:    0.6.2
 */