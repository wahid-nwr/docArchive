/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum ModalityLookupTableCommandFlags
/*    */ {
/*  5 */   NONE(0), 
/*  6 */   SIGNED_LOOKUP_TABLE(1), 
/*  7 */   UPDATE_MIN_MAX(2), 
/*  8 */   USE_FULL_RANGE(4), 
/*  9 */   ALLOW_RANGE_EXPANSION(8);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, ModalityLookupTableCommandFlags> mappings;
/*    */ 
/* 15 */   private static HashMap<Integer, ModalityLookupTableCommandFlags> getMappings() { if (mappings == null)
/*    */     {
/* 17 */       synchronized (ModalityLookupTableCommandFlags.class)
/*    */       {
/* 19 */         if (mappings == null)
/*    */         {
/* 21 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 25 */     return mappings;
/*    */   }
/*    */ 
/*    */   private ModalityLookupTableCommandFlags(int value)
/*    */   {
/* 30 */     this.intValue = value;
/* 31 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue()
/*    */   {
/* 36 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static ModalityLookupTableCommandFlags forValue(int value)
/*    */   {
/* 41 */     return (ModalityLookupTableCommandFlags)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.ModalityLookupTableCommandFlags
 * JD-Core Version:    0.6.2
 */