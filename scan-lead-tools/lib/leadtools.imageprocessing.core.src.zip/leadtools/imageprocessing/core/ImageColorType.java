/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum ImageColorType
/*    */ {
/*  4 */   NONE(0), 
/*  5 */   BLACK_AND_WHITE(1), 
/*  6 */   GRAYSCALE(2), 
/*  7 */   COLOR(3);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, ImageColorType> mappings;
/*    */ 
/* 12 */   private static HashMap<Integer, ImageColorType> getMappings() { if (mappings == null) {
/* 13 */       synchronized (ImageColorType.class) {
/* 14 */         if (mappings == null) {
/* 15 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 19 */     return mappings; }
/*    */ 
/*    */   private ImageColorType(int value)
/*    */   {
/* 23 */     this.intValue = value;
/* 24 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue() {
/* 28 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static ImageColorType forValue(int value) {
/* 32 */     return (ImageColorType)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.ImageColorType
 * JD-Core Version:    0.6.2
 */