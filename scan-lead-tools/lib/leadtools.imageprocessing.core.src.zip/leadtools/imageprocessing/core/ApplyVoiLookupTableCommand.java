/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class ApplyVoiLookupTableCommand extends RasterCommand
/*    */ {
/*    */   private DicomLookupTableDescriptor _lookupTableDescriptor;
/*    */   private int[] _lookupTable;
/*    */   private int _flags;
/*    */ 
/*    */   public ApplyVoiLookupTableCommand()
/*    */   {
/* 14 */     this._lookupTableDescriptor = new DicomLookupTableDescriptor();
/* 15 */     this._lookupTable = new int[1];
/* 16 */     this._flags = VoiLookupTableCommandFlags.NONE.getValue();
/*    */   }
/*    */ 
/*    */   public ApplyVoiLookupTableCommand(DicomLookupTableDescriptor lookupTableDescriptor, int[] lookupTable, int flags) {
/* 20 */     this._lookupTableDescriptor = lookupTableDescriptor;
/* 21 */     this._lookupTable = lookupTable;
/* 22 */     this._flags = flags;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 27 */     return "Apply VOI LookupTable";
/*    */   }
/*    */ 
/*    */   public int getFlags() {
/* 31 */     return this._flags;
/*    */   }
/*    */ 
/*    */   public void setFlags(int value) {
/* 35 */     this._flags = value;
/*    */   }
/*    */ 
/*    */   public int[] getLookupTable() {
/* 39 */     return this._lookupTable;
/*    */   }
/*    */ 
/*    */   public void setLookupTable(int[] value) {
/* 43 */     this._lookupTable = value;
/*    */   }
/*    */ 
/*    */   public DicomLookupTableDescriptor getLookupTableDescriptor() {
/* 47 */     return this._lookupTableDescriptor;
/*    */   }
/*    */ 
/*    */   public void setLookupTableDescriptor(DicomLookupTableDescriptor value) {
/* 51 */     this._lookupTableDescriptor = value;
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 56 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */ 
/* 58 */     DicomLutDescriptor dLUTDescriptor = new DicomLutDescriptor();
/* 59 */     dLUTDescriptor._uNumberOfEntries = (this._lookupTable != null ? this._lookupTable.length : 0);
/* 60 */     dLUTDescriptor._nFirstStoredPixelValueMapped = this._lookupTableDescriptor.getFirstStoredPixelValueMapped();
/* 61 */     dLUTDescriptor._uEntryBits = this._lookupTableDescriptor.getEntryBits();
/*    */     try
/*    */     {
/* 64 */       ret = ltimgcor.ApplyVOILUT(bitmap, this._lookupTable, dLUTDescriptor, this._flags);
/* 65 */       return ret;
/*    */     }
/*    */     finally {
/* 68 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.ApplyVoiLookupTableCommand
 * JD-Core Version:    0.6.2
 */