/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.LeadPoint;
/*    */ import leadtools.LeadRect;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class SearchRegistrationMarksCommand extends RasterCommand
/*    */ {
/*    */   private SearchRegistrationMarksCommandData[] _searchMarks;
/*    */ 
/*    */   public SearchRegistrationMarksCommand()
/*    */   {
/* 14 */     this._searchMarks = null;
/*    */   }
/*    */ 
/*    */   public SearchRegistrationMarksCommand(SearchRegistrationMarksCommandData[] searchMarks) {
/* 18 */     this._searchMarks = searchMarks;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 23 */     return "Search Registration Marks";
/*    */   }
/*    */ 
/*    */   public SearchRegistrationMarksCommandData[] getSearchMarks() {
/* 27 */     return this._searchMarks;
/*    */   }
/*    */ 
/*    */   public void setSearchMarks(SearchRegistrationMarksCommandData[] value) {
/* 31 */     this._searchMarks = value;
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 36 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */ 
/* 38 */     int size = this._searchMarks != null ? this._searchMarks.length : 0;
/* 39 */     SEARCHMARKS[] p = new SEARCHMARKS[size];
/*    */ 
/* 41 */     for (int i = 0; i < size; i++) {
/* 42 */       p[i] = new SEARCHMARKS();
/* 43 */       p[i]._markDetectedPoints = new LeadPoint[this._searchMarks[i].getSearchMarkCount()];
/*    */ 
/* 45 */       if (this._searchMarks[i].getRectangle() != null)
/* 46 */         p[i]._rcRect = this._searchMarks[i].getRectangle().clone();
/*    */       else {
/* 48 */         p[i]._rcRect = LeadRect.getEmpty();
/*    */       }
/* 50 */       p[i]._uHeight = this._searchMarks[i].getHeight();
/* 51 */       p[i]._uWidth = this._searchMarks[i].getWidth();
/* 52 */       p[i]._uMaxScale = this._searchMarks[i].getMaximumScale();
/* 53 */       p[i]._uMinScale = this._searchMarks[i].getMinimumScale();
/* 54 */       p[i]._uSearchMarkCount = this._searchMarks[i].getSearchMarkCount();
/* 55 */       p[i]._uType = this._searchMarks[i].getType().getValue();
/* 56 */       p[i]._uMarkDetectedCount = 0;
/*    */     }
/*    */     try
/*    */     {
/* 60 */       ret = ltimgcor.SearchRegMarksBitmap(bitmap, p, size, 0);
/*    */       int i;
/* 61 */       if (ret == L_ERROR.SUCCESS.getValue()) {
/* 62 */         for (i = 0; i < size; i++) {
/* 63 */           this._searchMarks[i].setMarkDetectedCount(p[i]._uMarkDetectedCount);
/* 64 */           for (int j = 0; j < p[i]._uMarkDetectedCount; j++) {
/* 65 */             this._searchMarks[i].getMarkDetectedPoints()[j].setX(p[i]._markDetectedPoints[j].getX());
/* 66 */             this._searchMarks[i].getMarkDetectedPoints()[j].setY(p[i]._markDetectedPoints[j].getY());
/*    */           }
/*    */         }
/*    */       }
/* 70 */       return ret;
/*    */     }
/*    */     finally {
/* 73 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.SearchRegistrationMarksCommand
 * JD-Core Version:    0.6.2
 */