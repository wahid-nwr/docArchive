/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum BorderRemoveCommandFlags
/*    */ {
/*  5 */   NONE(0), 
/*  6 */   LEAD_REGION(4), 
/*  7 */   CALLBACK_REGION(8), 
/*  8 */   SINGLE_REGION(2), 
/*  9 */   IMAGE_UNCHANGED(16), 
/* 10 */   USE_VARIANCE(2048);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, BorderRemoveCommandFlags> mappings;
/*    */ 
/* 16 */   private static HashMap<Integer, BorderRemoveCommandFlags> getMappings() { if (mappings == null) {
/* 17 */       synchronized (BorderRemoveCommandFlags.class) {
/* 18 */         if (mappings == null) {
/* 19 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 23 */     return mappings; }
/*    */ 
/*    */   private BorderRemoveCommandFlags(int value)
/*    */   {
/* 27 */     this.intValue = value;
/* 28 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue() {
/* 32 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static BorderRemoveCommandFlags forValue(int value) {
/* 36 */     return (BorderRemoveCommandFlags)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.BorderRemoveCommandFlags
 * JD-Core Version:    0.6.2
 */