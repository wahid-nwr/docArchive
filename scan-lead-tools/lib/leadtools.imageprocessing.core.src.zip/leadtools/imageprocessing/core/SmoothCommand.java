/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.RasterRegion;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ import leadtools.ltkrn;
/*    */ 
/*    */ public class SmoothCommand extends RasterCommand
/*    */ {
/*    */   private int _flags;
/* 14 */   private int _length = 0;
/*    */   private RasterImage _imageRegion;
/*    */   private RasterRegion _region;
/*    */   private RasterImage _image;
/*    */   private ArrayList<SmoothCommandListener> _smooth;
/*    */ 
/*    */   public void addSmoothCommandListener(SmoothCommandListener listener)
/*    */   {
/* 21 */     this._smooth.add(listener);
/*    */   }
/*    */ 
/*    */   public void removeSmoothCommandListener(SmoothCommandListener listener) {
/* 25 */     this._smooth.remove(listener);
/*    */   }
/*    */ 
/*    */   public int getFlags() {
/* 29 */     return this._flags;
/*    */   }
/*    */   public void setFlags(int value) {
/* 32 */     this._flags = value;
/*    */   }
/*    */ 
/*    */   public int getLength() {
/* 36 */     return this._length;
/*    */   }
/*    */   public void setLength(int value) {
/* 39 */     this._length = value;
/*    */   }
/*    */ 
/*    */   public RasterImage getImageRegion() {
/* 43 */     return this._imageRegion;
/*    */   }
/*    */ 
/*    */   public RasterRegion getRegion() {
/* 47 */     return this._region;
/*    */   }
/*    */ 
/*    */   public SmoothCommand() {
/* 51 */     this._flags = SmoothCommandFlags.NONE.getValue();
/* 52 */     this._length = 1;
/* 53 */     this._imageRegion = null;
/* 54 */     this._region = null;
/* 55 */     this._smooth = new ArrayList();
/*    */   }
/*    */ 
/*    */   public SmoothCommand(int flags, int length) {
/* 59 */     this._flags = flags;
/* 60 */     this._length = length;
/* 61 */     this._smooth = new ArrayList();
/*    */   }
/*    */ 
/*    */   private final int DoCallback(int uBumpOrNick, int iStartRow, int iStartCol, int iLength, int uHorV)
/*    */   {
/* 67 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */ 
/* 69 */     Iterator i$ = this._smooth.iterator(); if (i$.hasNext()) { SmoothCommandListener listener = (SmoothCommandListener)i$.next();
/* 70 */       SmoothCommandEvent args = new SmoothCommandEvent(this, this._image, SmoothCommandBumpNickType.forValue(uBumpOrNick), iStartRow, iStartCol, iLength, SmoothCommandDirectionType.forValue(uHorV));
/* 71 */       listener.onSmoothEvent(args);
/* 72 */       return args.getStatus().getValue();
/*    */     }
/*    */ 
/* 75 */     return ret;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 80 */     return "Smooth";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 85 */     int ret = L_ERROR.SUCCESS.getValue();
/* 86 */     long RegionBitmap = 0L;
/*    */     try
/*    */     {
/* 89 */       this._image = image;
/* 90 */       SmoothStruct smooth = new SmoothStruct();
/* 91 */       smooth._uFlags = this._flags;
/* 92 */       smooth._iLength = this._length;
/*    */ 
/* 95 */       if (((this._flags & SmoothCommandFlags.SINGLE_REGION.getValue()) == SmoothCommandFlags.SINGLE_REGION.getValue()) && ((this._flags & SmoothCommandFlags.LEAD_REGION.getValue()) == SmoothCommandFlags.LEAD_REGION.getValue()))
/*    */       {
/* 98 */         RegionBitmap = ltkrn.AllocBitmapHandle();
/* 99 */         smooth._bitmapRegion = RegionBitmap;
/*    */       }
/*    */ 
/* 102 */       ret = ltimgcor.SmoothBitmap(bitmap, smooth, this._smooth.size() > 0 ? this : null, 0);
/*    */ 
/* 107 */       if (ret == L_ERROR.SUCCESS.getValue())
/*    */       {
/* 109 */         this._imageRegion = null;
/* 110 */         this._region = null;
/*    */ 
/* 112 */         if (((this._flags & SmoothCommandFlags.SINGLE_REGION.getValue()) == SmoothCommandFlags.SINGLE_REGION.getValue()) && ((this._flags & SmoothCommandFlags.LEAD_REGION.getValue()) == SmoothCommandFlags.LEAD_REGION.getValue()))
/*    */         {
/* 116 */           this._imageRegion = RasterImage.createFromBitmapHandle(RegionBitmap);
/*    */         }
/* 118 */         else if ((this._flags & SmoothCommandFlags.SINGLE_REGION.getValue()) == SmoothCommandFlags.SINGLE_REGION.getValue())
/*    */         {
/* 121 */           if (smooth._leadregion != 0L) {
/* 122 */             this._region = new RasterRegion(smooth._leadregion, true);
/* 123 */             ltkrn.DeleteLeadRgn(smooth._leadregion);
/*    */           }
/*    */         }
/*    */       }
/*    */ 
/* 128 */       return ret;
/*    */     }
/*    */     finally {
/* 131 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/* 132 */       if (RegionBitmap != 0L)
/* 133 */         ltkrn.FreeBitmapHandle(RegionBitmap);
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.SmoothCommand
 * JD-Core Version:    0.6.2
 */