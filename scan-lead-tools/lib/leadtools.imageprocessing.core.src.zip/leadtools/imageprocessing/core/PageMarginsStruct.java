/*     */ package leadtools.imageprocessing.core;
/*     */ 
/*     */ class PageMarginsStruct
/*     */ {
/*     */   public int _uTopMargin;
/*     */   public int _uBottomMargin;
/*     */   public int _uLeftMargin;
/*     */   public int _uRightMargin;
/*     */ 
/*     */   public PageMarginsStruct()
/*     */   {
/* 125 */     this._uTopMargin = 0;
/* 126 */     this._uBottomMargin = 0;
/* 127 */     this._uLeftMargin = 0;
/* 128 */     this._uRightMargin = 0;
/*     */   }
/*     */ 
/*     */   public PageMarginsStruct Default() {
/* 132 */     return new PageMarginsStruct();
/*     */   }
/*     */ 
/*     */   public PageMarginsStruct Clone() {
/* 136 */     PageMarginsStruct pageMargins = Default();
/*     */ 
/* 138 */     pageMargins._uTopMargin = this._uTopMargin;
/* 139 */     pageMargins._uBottomMargin = this._uBottomMargin;
/* 140 */     pageMargins._uLeftMargin = this._uLeftMargin;
/* 141 */     pageMargins._uRightMargin = this._uRightMargin;
/*     */ 
/* 143 */     return pageMargins;
/*     */   }
/*     */ 
/*     */   public int getTopMargin() {
/* 147 */     return this._uTopMargin;
/*     */   }
/*     */ 
/*     */   public void setTopMargin(int value) {
/* 151 */     this._uTopMargin = value;
/*     */   }
/*     */ 
/*     */   public int getBottomMargin() {
/* 155 */     return this._uBottomMargin;
/*     */   }
/*     */ 
/*     */   public void setBottomMargin(int value) {
/* 159 */     this._uBottomMargin = value;
/*     */   }
/*     */ 
/*     */   public int getLeftMargin() {
/* 163 */     return this._uLeftMargin;
/*     */   }
/*     */ 
/*     */   public void setLeftMargin(int value) {
/* 167 */     this._uLeftMargin = value;
/*     */   }
/*     */ 
/*     */   public int getRightMargin() {
/* 171 */     return this._uRightMargin;
/*     */   }
/*     */ 
/*     */   public void setRightMargin(int value) {
/* 175 */     this._uRightMargin = value;
/*     */   }
/*     */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.PageMarginsStruct
 * JD-Core Version:    0.6.2
 */