/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum VoiLookupTableCommandFlags
/*    */ {
/*  5 */   NONE(0), 
/*  6 */   UPDATE_MIN_MAX(1), 
/*  7 */   REVERSE_ORDER(2);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, VoiLookupTableCommandFlags> mappings;
/*    */ 
/* 13 */   private static HashMap<Integer, VoiLookupTableCommandFlags> getMappings() { if (mappings == null)
/*    */     {
/* 15 */       synchronized (VoiLookupTableCommandFlags.class)
/*    */       {
/* 17 */         if (mappings == null)
/*    */         {
/* 19 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 23 */     return mappings;
/*    */   }
/*    */ 
/*    */   private VoiLookupTableCommandFlags(int value)
/*    */   {
/* 28 */     this.intValue = value;
/* 29 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue()
/*    */   {
/* 34 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static VoiLookupTableCommandFlags forValue(int value)
/*    */   {
/* 39 */     return (VoiLookupTableCommandFlags)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.VoiLookupTableCommandFlags
 * JD-Core Version:    0.6.2
 */