/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ import leadtools.ltkrn;
/*    */ 
/*    */ public class TissueEqualizeCommand extends RasterCommand
/*    */ {
/*    */   private int _flags;
/*    */ 
/*    */   public int getFlags()
/*    */   {
/* 13 */     return this._flags;
/*    */   }
/*    */ 
/*    */   public void setFlags(int value) {
/* 17 */     this._flags = value;
/*    */   }
/*    */ 
/*    */   public TissueEqualizeCommand() {
/* 21 */     this._flags = TissueEqualizeCommandFlags.USE_INTENSIFY_OPTION.getValue();
/*    */   }
/*    */ 
/*    */   public TissueEqualizeCommand(int flags) {
/* 25 */     this._flags = flags;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 30 */     return "TissueEqualize";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 35 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 38 */       ret = ltimgcor.TissueEqualizeBitmap(bitmap, this._flags);
/*    */       long bitmap1;
/* 39 */       if (ret == L_ERROR.SUCCESS.getValue())
/*    */       {
/* 41 */         bitmap1 = bitmap;
/* 42 */         long bitmap2 = image.getCurrentBitmapHandle();
/* 43 */         ret = ltkrn.CopyBitmap(bitmap2, bitmap1, 0);
/*    */       }
/*    */ 
/* 46 */       return ret;
/*    */     }
/*    */     finally {
/* 49 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.TissueEqualizeCommand
 * JD-Core Version:    0.6.2
 */