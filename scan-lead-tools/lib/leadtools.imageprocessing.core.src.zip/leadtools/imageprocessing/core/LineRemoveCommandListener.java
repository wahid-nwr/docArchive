package leadtools.imageprocessing.core;

public abstract interface LineRemoveCommandListener
{
  public abstract void onLineRemoveEvent(LineRemoveCommandEvent paramLineRemoveCommandEvent);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.LineRemoveCommandListener
 * JD-Core Version:    0.6.2
 */