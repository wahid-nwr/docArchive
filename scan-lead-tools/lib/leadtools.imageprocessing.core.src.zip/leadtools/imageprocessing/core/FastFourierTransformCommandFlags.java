/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum FastFourierTransformCommandFlags
/*    */ {
/*  5 */   NONE(0), 
/*  6 */   FAST_FOURIER_TRANSFORM(1), 
/*  7 */   INVERSE_FAST_FOURIER_TRANSFORM(2), 
/*  8 */   BLUE(16), 
/*  9 */   GREEN(32), 
/* 10 */   RED(48), 
/* 11 */   GRAY(64), 
/* 12 */   MAGNITUDE(256), 
/* 13 */   PHASE(512), 
/* 14 */   BOTH(768), 
/* 15 */   CLIP(4096), 
/* 16 */   SCALE(8192);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, FastFourierTransformCommandFlags> mappings;
/*    */ 
/* 22 */   private static HashMap<Integer, FastFourierTransformCommandFlags> getMappings() { if (mappings == null) {
/* 23 */       synchronized (FastFourierTransformCommandFlags.class) {
/* 24 */         if (mappings == null) {
/* 25 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 29 */     return mappings; }
/*    */ 
/*    */   private FastFourierTransformCommandFlags(int value)
/*    */   {
/* 33 */     this.intValue = value;
/* 34 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue() {
/* 38 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static FastFourierTransformCommandFlags forValue(int value) {
/* 42 */     return (FastFourierTransformCommandFlags)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.FastFourierTransformCommandFlags
 * JD-Core Version:    0.6.2
 */