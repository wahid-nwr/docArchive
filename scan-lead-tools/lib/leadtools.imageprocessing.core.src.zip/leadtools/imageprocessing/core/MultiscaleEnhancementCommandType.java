/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum MultiscaleEnhancementCommandType
/*    */ {
/*  4 */   GAUSSIAN(0), 
/*  5 */   RESAMPLE(1), 
/*  6 */   BICUBIC(2), 
/*  7 */   NORMAL(3);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, MultiscaleEnhancementCommandType> mappings;
/*    */ 
/* 13 */   private static HashMap<Integer, MultiscaleEnhancementCommandType> getMappings() { if (mappings == null)
/*    */     {
/* 15 */       synchronized (MultiscaleEnhancementCommandType.class)
/*    */       {
/* 17 */         if (mappings == null)
/*    */         {
/* 19 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 23 */     return mappings; }
/*    */ 
/*    */   private MultiscaleEnhancementCommandType(int value)
/*    */   {
/* 27 */     this.intValue = value;
/* 28 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue() {
/* 32 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static MultiscaleEnhancementCommandType forValue(int value)
/*    */   {
/* 37 */     return (MultiscaleEnhancementCommandType)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.MultiscaleEnhancementCommandType
 * JD-Core Version:    0.6.2
 */