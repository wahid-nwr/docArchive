/*     */ package leadtools.imageprocessing.core;
/*     */ 
/*     */ import leadtools.LeadRect;
/*     */ 
/*     */ class TEXTZONEDATA
/*     */ {
/*     */   LeadRect[] _textLines;
/*     */   int _textLinesCount;
/*     */ 
/*     */   public TEXTZONEDATA()
/*     */   {
/* 247 */     this._textLines = null;
/* 248 */     this._textLinesCount = 0;
/*     */   }
/*     */ 
/*     */   public void Init(int count, LeadRect[] rects) {
/* 252 */     if (count <= 0) {
/* 253 */       return;
/*     */     }
/* 255 */     this._textLinesCount = count;
/* 256 */     this._textLines = new LeadRect[count];
/* 257 */     for (int i = 0; i < count; i++)
/* 258 */       this._textLines[i] = new LeadRect(rects[i].getLeft(), rects[i].getTop(), rects[i].getWidth(), rects[i].getHeight());
/*     */   }
/*     */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.TEXTZONEDATA
 * JD-Core Version:    0.6.2
 */