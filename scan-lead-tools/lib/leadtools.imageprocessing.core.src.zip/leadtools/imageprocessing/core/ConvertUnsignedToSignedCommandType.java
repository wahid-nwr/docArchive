/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum ConvertUnsignedToSignedCommandType
/*    */ {
/*  4 */   PROCESS_RANGE_ONLY(1), 
/*  5 */   PROCESS_OUTSIDE_RANGE(2);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, ConvertUnsignedToSignedCommandType> mappings;
/*    */ 
/* 11 */   private static HashMap<Integer, ConvertUnsignedToSignedCommandType> getMappings() { if (mappings == null)
/*    */     {
/* 13 */       synchronized (ConvertUnsignedToSignedCommandType.class)
/*    */       {
/* 15 */         if (mappings == null)
/*    */         {
/* 17 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 21 */     return mappings;
/*    */   }
/*    */ 
/*    */   private ConvertUnsignedToSignedCommandType(int value)
/*    */   {
/* 26 */     this.intValue = value;
/* 27 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue()
/*    */   {
/* 32 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static ConvertUnsignedToSignedCommandType forValue(int value)
/*    */   {
/* 37 */     return (ConvertUnsignedToSignedCommandType)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.ConvertUnsignedToSignedCommandType
 * JD-Core Version:    0.6.2
 */