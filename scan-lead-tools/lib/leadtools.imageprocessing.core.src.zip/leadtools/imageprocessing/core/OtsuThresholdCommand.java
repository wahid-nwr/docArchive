/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class OtsuThresholdCommand extends RasterCommand
/*    */ {
/*    */   private int _clusters;
/*    */ 
/*    */   public String toString()
/*    */   {
/* 14 */     return "OtsuThresholdCommand";
/*    */   }
/*    */ 
/*    */   public OtsuThresholdCommand() {
/* 18 */     this._clusters = 2;
/*    */   }
/*    */ 
/*    */   public OtsuThresholdCommand(int Clusters) {
/* 22 */     this._clusters = Clusters;
/*    */   }
/*    */ 
/*    */   public int getClusters() {
/* 26 */     return this._clusters;
/*    */   }
/*    */ 
/*    */   public void setClusters(int value) {
/* 30 */     this._clusters = value;
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 35 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 38 */       ret = ltimgcor.OtsuThreshold(bitmap, this._clusters);
/* 39 */       return ret;
/*    */     }
/*    */     finally {
/* 42 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.OtsuThresholdCommand
 * JD-Core Version:    0.6.2
 */