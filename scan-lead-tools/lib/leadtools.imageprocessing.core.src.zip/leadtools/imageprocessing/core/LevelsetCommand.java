/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class LevelsetCommand extends RasterCommand
/*    */ {
/*    */   private int _lambdaIn;
/*    */   private int _lambdaOut;
/*    */ 
/*    */   public LevelsetCommand()
/*    */   {
/* 14 */     this._lambdaIn = 1;
/* 15 */     this._lambdaOut = 1;
/*    */   }
/*    */ 
/*    */   public LevelsetCommand(int lambdaIn, int lambdaOut) {
/* 19 */     this._lambdaIn = lambdaIn;
/* 20 */     this._lambdaOut = lambdaOut;
/*    */   }
/*    */ 
/*    */   public void setLambdaIn(int value) {
/* 24 */     this._lambdaIn = value;
/*    */   }
/*    */ 
/*    */   public void setLambdaOut(int value) {
/* 28 */     this._lambdaOut = value;
/*    */   }
/*    */ 
/*    */   public int getLambdaIn() {
/* 32 */     return this._lambdaIn;
/*    */   }
/*    */ 
/*    */   public int getLambdaOut() {
/* 36 */     return this._lambdaOut;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 41 */     return "LevelsetCommand";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 46 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 49 */       ret = ltimgcor.LevelsetBitmapRgn(bitmap, this._lambdaIn, this._lambdaOut);
/* 50 */       return ret;
/*    */     }
/*    */     finally {
/* 53 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.LevelsetCommand
 * JD-Core Version:    0.6.2
 */