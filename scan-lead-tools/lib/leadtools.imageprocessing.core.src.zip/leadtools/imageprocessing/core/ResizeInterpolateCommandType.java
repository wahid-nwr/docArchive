/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum ResizeInterpolateCommandType
/*    */ {
/*  4 */   NORMAL(0), 
/*  5 */   RESAMPLE(2), 
/*  6 */   BICUBIC(4), 
/*  7 */   TRIANGLE(5), 
/*  8 */   HERMITE(6), 
/*  9 */   BELL(7), 
/* 10 */   QUADRATIC_B_SPLINE(8), 
/* 11 */   CUBIC_B_SPLINE(9), 
/* 12 */   BOX_FILTER(10), 
/* 13 */   LANCZOS(11), 
/* 14 */   MICHELL(12), 
/* 15 */   COSINE(13), 
/* 16 */   CATROM(14), 
/* 17 */   QUADRATIC(15), 
/* 18 */   CUBIC_CONVOLUTION(16), 
/* 19 */   BILINEAR(17), 
/* 20 */   BRESENHAM(18);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, ResizeInterpolateCommandType> mappings;
/*    */ 
/* 26 */   private static HashMap<Integer, ResizeInterpolateCommandType> getMappings() { if (mappings == null)
/*    */     {
/* 28 */       synchronized (ResizeInterpolateCommandType.class)
/*    */       {
/* 30 */         if (mappings == null)
/*    */         {
/* 32 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 36 */     return mappings;
/*    */   }
/*    */ 
/*    */   private ResizeInterpolateCommandType(int value)
/*    */   {
/* 41 */     this.intValue = value;
/* 42 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue()
/*    */   {
/* 47 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static ResizeInterpolateCommandType forValue(int value)
/*    */   {
/* 52 */     return (ResizeInterpolateCommandType)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.ResizeInterpolateCommandType
 * JD-Core Version:    0.6.2
 */