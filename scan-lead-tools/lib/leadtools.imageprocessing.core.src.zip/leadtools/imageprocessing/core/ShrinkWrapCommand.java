/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.LeadPoint;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class ShrinkWrapCommand extends RasterCommand
/*    */ {
/*    */   private int _threshold;
/*    */   private int _radius;
/*    */   private LeadPoint _center;
/*    */   private ShrinkWrapFlags _flags;
/*    */ 
/*    */   public ShrinkWrapCommand()
/*    */   {
/* 17 */     this._threshold = 50;
/*    */   }
/*    */ 
/*    */   public ShrinkWrapCommand(int threshold, LeadPoint center, int radius, ShrinkWrapFlags flags) {
/* 21 */     this._threshold = threshold;
/* 22 */     this._center = center;
/* 23 */     this._flags = flags;
/* 24 */     this._radius = radius;
/*    */   }
/*    */ 
/*    */   public void setThreshold(int value) {
/* 28 */     this._threshold = value;
/*    */   }
/*    */ 
/*    */   public int getThreshold()
/*    */   {
/* 33 */     return this._threshold;
/*    */   }
/*    */ 
/*    */   public void setRadius(int value) {
/* 37 */     this._radius = value;
/*    */   }
/*    */ 
/*    */   public int getRadius() {
/* 41 */     return this._radius;
/*    */   }
/*    */ 
/*    */   public void setFlags(ShrinkWrapFlags value) {
/* 45 */     this._flags = value;
/*    */   }
/*    */ 
/*    */   public ShrinkWrapFlags getFlags()
/*    */   {
/* 50 */     return this._flags;
/*    */   }
/*    */ 
/*    */   public void setCenter(LeadPoint value) {
/* 54 */     this._center = value;
/*    */   }
/*    */ 
/*    */   public LeadPoint getCenter() {
/* 58 */     return this._center;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 63 */     return "Shrink Wrap";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 68 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 71 */       ret = ltimgcor.ShrinkWrapTool(bitmap, this._threshold, this._center, this._radius, this._flags.getValue());
/* 72 */       return ret;
/*    */     }
/*    */     finally {
/* 75 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.ShrinkWrapCommand
 * JD-Core Version:    0.6.2
 */