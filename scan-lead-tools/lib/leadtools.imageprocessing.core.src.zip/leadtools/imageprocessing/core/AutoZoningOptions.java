/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum AutoZoningOptions
/*    */ {
/*  5 */   NONE(0), 
/*  6 */   DETECT_TEXT(1), 
/*  7 */   DETECT_GRAPHICS(2), 
/*  8 */   DETECT_TABLE(4), 
/*  9 */   DETECT_ALL(7), 
/* 10 */   ALLOW_OVERLAP(16), 
/* 11 */   DONT_ALLOW_OVERLAP(0), 
/* 12 */   DETECT_ACCURATE_ZONES(0), 
/* 13 */   DETECT_GENERAL_ZONES(256), 
/* 14 */   DONT_RECOGNIZE_ONE_CELL_TABLE(0), 
/* 15 */   RECOGNIZE_ONE_CELL_TABLE(4096), 
/* 16 */   USE_MULTI_THREADING(0), 
/* 17 */   DONT_USE_MULTI_THREADING(-2147483648), 
/* 18 */   USE_NORMAL_TABLE_DETECTION(0), 
/* 19 */   USE_ADVANCED_TABLE_DETECTION(8192), 
/* 20 */   USE_TEXT_DETECTION_VERSION(32768), 
/* 21 */   USE_LINES_RECONSTRUCTION(16384), 
/* 22 */   ASIAN_AUTO_ZONE(512), 
/* 23 */   DETECT_CHECK_BOX(65536);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, AutoZoningOptions> mappings;
/*    */ 
/* 28 */   private static HashMap<Integer, AutoZoningOptions> getMappings() { if (mappings == null) {
/* 29 */       synchronized (AutoZoningOptions.class) {
/* 30 */         if (mappings == null) {
/* 31 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 35 */     return mappings; }
/*    */ 
/*    */   private AutoZoningOptions(int value)
/*    */   {
/* 39 */     this.intValue = value;
/* 40 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue() {
/* 44 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static AutoZoningOptions forValue(int value)
/*    */   {
/* 49 */     return (AutoZoningOptions)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.AutoZoningOptions
 * JD-Core Version:    0.6.2
 */