/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterColor;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class DeskewCommand extends RasterCommand
/*    */ {
/*    */   private int _angle;
/*    */   private RasterColor _fillColor;
/*    */   private int _flags;
/*    */   private int _angleResolution;
/*    */   private int _angleRange;
/*    */ 
/*    */   public int getAngle()
/*    */   {
/* 17 */     return this._angle;
/*    */   }
/*    */ 
/*    */   public int getAngleRange() {
/* 21 */     return this._angleRange;
/*    */   }
/*    */ 
/*    */   public void setAngleRange(int value) {
/* 25 */     this._angleRange = value;
/*    */   }
/*    */ 
/*    */   public int getAngleResolution() {
/* 29 */     return this._angleResolution;
/*    */   }
/*    */ 
/*    */   public void setAngleResolution(int value) {
/* 33 */     this._angleResolution = value;
/*    */   }
/*    */ 
/*    */   public RasterColor getFillColor() {
/* 37 */     return this._fillColor;
/*    */   }
/*    */ 
/*    */   public void setFillColor(RasterColor value) {
/* 41 */     this._fillColor = value;
/*    */   }
/*    */ 
/*    */   public int getFlags() {
/* 45 */     return this._flags;
/*    */   }
/*    */ 
/*    */   public void setFlags(int value) {
/* 49 */     this._flags = value;
/*    */   }
/*    */ 
/*    */   public DeskewCommand() {
/* 53 */     this._fillColor = new RasterColor(0, 0, 0);
/* 54 */     this._flags = (DeskewCommandFlags.DESKEW_IMAGE.getValue() | DeskewCommandFlags.FILL_EXPOSED_AREA.getValue());
/* 55 */     this._angle = 0;
/* 56 */     this._angleResolution = 20;
/* 57 */     this._angleRange = 2000;
/*    */   }
/*    */ 
/*    */   public DeskewCommand(RasterColor fillColor, int flags) {
/* 61 */     this._fillColor = fillColor;
/* 62 */     this._flags = flags;
/* 63 */     this._angle = 0;
/* 64 */     this._angleResolution = 20;
/* 65 */     this._angleRange = 2000;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 70 */     return "Deskew";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 75 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 78 */       int fillColor = this._fillColor.toRgb();
/* 79 */       int[] angle = new int[1];
/* 80 */       angle[0] = this._angle;
/*    */       int flags;
/* 82 */       if ((this._flags & DeskewCommandFlags.USE_EXTENDED_DESKEW.getValue()) == DeskewCommandFlags.USE_EXTENDED_DESKEW.getValue())
/*    */       {
/* 84 */         flags = this._flags;
/* 85 */         flags = this._flags ^ DeskewCommandFlags.USE_EXTENDED_DESKEW.getValue();
/* 86 */         ret = ltimgcor.DeskewBitmapExt(bitmap, angle, this._angleRange, this._angleResolution, fillColor, flags);
/*    */       }
/*    */       else
/*    */       {
/* 90 */         ret = ltimgcor.DeskewBitmap(bitmap, angle, fillColor, this._flags);
/*    */       }
/*    */ 
/* 93 */       if (ret == L_ERROR.SUCCESS.getValue())
/* 94 */         this._angle = angle[0];
/* 95 */       return ret;
/*    */     }
/*    */     finally {
/* 98 */       image.updateCurrentBitmapHandle();
/* 99 */       if ((this._flags & DeskewCommandFlags.RETURN_ANGLE_ONLY.getValue()) != DeskewCommandFlags.RETURN_ANGLE_ONLY.getValue())
/* 100 */         changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.DeskewCommand
 * JD-Core Version:    0.6.2
 */