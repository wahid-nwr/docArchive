/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum ApplyTransformationParametersCommandFlags
/*    */ {
/*  5 */   NONE(0), 
/*  6 */   NORMAL(1), 
/*  7 */   RESAMPLE(2), 
/*  8 */   BICUBIC(3), 
/*  9 */   FAVOR_BLACK(16), 
/* 10 */   FAVOR_WHITE(32);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, ApplyTransformationParametersCommandFlags> mappings;
/*    */ 
/* 16 */   private static HashMap<Integer, ApplyTransformationParametersCommandFlags> getMappings() { if (mappings == null) {
/* 17 */       synchronized (ApplyTransformationParametersCommandFlags.class) {
/* 18 */         if (mappings == null) {
/* 19 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 23 */     return mappings; }
/*    */ 
/*    */   private ApplyTransformationParametersCommandFlags(int value)
/*    */   {
/* 27 */     this.intValue = value;
/* 28 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue() {
/* 32 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static ApplyTransformationParametersCommandFlags forValue(int value) {
/* 36 */     return (ApplyTransformationParametersCommandFlags)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.ApplyTransformationParametersCommandFlags
 * JD-Core Version:    0.6.2
 */