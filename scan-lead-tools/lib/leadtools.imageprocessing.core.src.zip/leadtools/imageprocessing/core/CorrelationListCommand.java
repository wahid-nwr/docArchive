/*     */ package leadtools.imageprocessing.core;
/*     */ 
/*     */ import leadtools.L_ERROR;
/*     */ import leadtools.LeadPoint;
/*     */ import leadtools.RasterImage;
/*     */ import leadtools.RasterImageChangedFlags;
/*     */ import leadtools.imageprocessing.RasterCommand;
/*     */ 
/*     */ public class CorrelationListCommand extends RasterCommand
/*     */ {
/*     */   private LeadPoint[] _points;
/*     */   private int _numberOfPoints;
/*     */   private int _xStep;
/*     */   private int _yStep;
/*     */   private int _threshold;
/*     */   private RasterImage _correlationImage;
/*     */   private int[] _listIndex;
/*     */ 
/*     */   public CorrelationListCommand()
/*     */   {
/*  19 */     this._correlationImage = null;
/*  20 */     this._points = null;
/*  21 */     this._listIndex = null;
/*  22 */     this._numberOfPoints = 0;
/*  23 */     this._xStep = 0;
/*  24 */     this._yStep = 0;
/*  25 */     this._threshold = 0;
/*     */   }
/*     */ 
/*     */   public CorrelationListCommand(RasterImage correlationImage, LeadPoint[] points, int[] listIndex, int xStep, int yStep, int threshold) {
/*  29 */     this._correlationImage = correlationImage;
/*  30 */     this._xStep = xStep;
/*  31 */     this._yStep = yStep;
/*  32 */     this._threshold = threshold;
/*  33 */     this._numberOfPoints = 0;
/*     */ 
/*  35 */     if (listIndex.length > 0) {
/*  36 */       this._listIndex = new int[listIndex.length];
/*  37 */       for (int i = 0; i < listIndex.length; i++) {
/*  38 */         this._listIndex[i] = listIndex[i];
/*     */       }
/*     */     }
/*  41 */     if (points.length > 0) {
/*  42 */       this._points = new LeadPoint[points.length];
/*  43 */       for (int i = 0; i < points.length; i++)
/*  44 */         if (points[i] != null)
/*  45 */           this._points[i] = points[i].clone();
/*     */         else
/*  47 */           this._points[i] = new LeadPoint();
/*     */     }
/*     */   }
/*     */ 
/*     */   public CorrelationListCommand(LeadPoint[] points, int[] listIndex, int xStep, int yStep, int threshold)
/*     */   {
/*  53 */     this._points = points;
/*  54 */     this._listIndex = listIndex;
/*  55 */     this._xStep = xStep;
/*  56 */     this._yStep = yStep;
/*  57 */     this._threshold = threshold;
/*  58 */     this._numberOfPoints = 0;
/*     */ 
/*  60 */     if (listIndex.length > 0) {
/*  61 */       this._listIndex = new int[listIndex.length];
/*  62 */       for (int i = 0; i < listIndex.length; i++) {
/*  63 */         this._listIndex[i] = listIndex[i];
/*     */       }
/*     */     }
/*  66 */     if (points.length > 0) {
/*  67 */       this._points = new LeadPoint[points.length];
/*  68 */       for (int i = 0; i < points.length; i++)
/*  69 */         if (points[i] != null)
/*  70 */           this._points[i] = points[i].clone();
/*     */         else
/*  72 */           this._points[i] = new LeadPoint();
/*     */     }
/*     */   }
/*     */ 
/*     */   public LeadPoint[] getPoints()
/*     */   {
/*  78 */     return this._points;
/*     */   }
/*     */ 
/*     */   public void setPoints(LeadPoint[] value) {
/*  82 */     if (value.length > 0) {
/*  83 */       this._points = new LeadPoint[value.length];
/*     */ 
/*  85 */       for (int i = 0; i < value.length; i++)
/*  86 */         if (value[i] == null)
/*  87 */           this._points[i] = new LeadPoint();
/*     */         else
/*  89 */           this._points[i] = value[i].clone();
/*     */     }
/*     */   }
/*     */ 
/*     */   public int[] getListIndex()
/*     */   {
/*  95 */     return this._listIndex;
/*     */   }
/*     */ 
/*     */   public void setListIndex(int[] value) {
/*  99 */     if (value.length > 0) {
/* 100 */       this._listIndex = new int[value.length];
/* 101 */       for (int i = 0; i < value.length; i++)
/* 102 */         this._listIndex[i] = value[i];
/*     */     }
/*     */   }
/*     */ 
/*     */   public RasterImage getCorrelationImage() {
/* 107 */     return this._correlationImage;
/*     */   }
/*     */ 
/*     */   public void setCorrelationImage(RasterImage value) {
/* 111 */     this._correlationImage = value;
/*     */   }
/*     */ 
/*     */   public int getNumberOfPoints() {
/* 115 */     return this._numberOfPoints;
/*     */   }
/*     */ 
/*     */   public int getXStep() {
/* 119 */     return this._xStep;
/*     */   }
/*     */ 
/*     */   public void setXStep(int value) {
/* 123 */     this._xStep = value;
/*     */   }
/*     */ 
/*     */   public int getYStep() {
/* 127 */     return this._yStep;
/*     */   }
/*     */ 
/*     */   public void setYStep(int value) {
/* 131 */     this._yStep = value;
/*     */   }
/*     */ 
/*     */   public int getThreshold() {
/* 135 */     return this._threshold;
/*     */   }
/*     */ 
/*     */   public void setThreshold(int value) {
/* 139 */     this._threshold = value;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 144 */     return "Correlation List";
/*     */   }
/*     */ 
/*     */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*     */   {
/* 149 */     RasterImage sourceImage = this._correlationImage;
/* 150 */     int ret = L_ERROR.SUCCESS.getValue();
/*     */     try
/*     */     {
/* 153 */       int length = this._points != null ? this._points.length : 0;
/* 154 */       int[] nNumOfPoints = new int[1];
/* 155 */       nNumOfPoints[0] = this._numberOfPoints;
/*     */ 
/* 157 */       ret = ltimgcor.CorrelationListBitmap(bitmap, sourceImage != null ? sourceImage.getBitmapList() : 0L, this._points, this._listIndex, length, nNumOfPoints, this._xStep, this._yStep, this._threshold, 0);
/*     */ 
/* 169 */       if (ret == L_ERROR.SUCCESS.getValue()) {
/* 170 */         this._numberOfPoints = nNumOfPoints[0];
/*     */       }
/*     */ 
/* 173 */       return ret;
/*     */     }
/*     */     finally {
/* 176 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.CorrelationListCommand
 * JD-Core Version:    0.6.2
 */