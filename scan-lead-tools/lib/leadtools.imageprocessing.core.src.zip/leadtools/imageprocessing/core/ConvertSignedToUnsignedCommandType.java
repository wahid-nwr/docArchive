/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum ConvertSignedToUnsignedCommandType
/*    */ {
/*  4 */   SHIFT_ZERO_TO_CENTER(0), 
/*  5 */   SHIFT_MINIMUM_TO_ZERO(1), 
/*  6 */   SHIFT_NEGATIVE_TO_ZERO(2), 
/*  7 */   SHIFT_RANGE_ONLY(3), 
/*  8 */   SHIFT_RANGE_PROCESS_OUTSIDE(4);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, ConvertSignedToUnsignedCommandType> mappings;
/*    */ 
/* 14 */   private static HashMap<Integer, ConvertSignedToUnsignedCommandType> getMappings() { if (mappings == null)
/*    */     {
/* 16 */       synchronized (ConvertSignedToUnsignedCommandType.class)
/*    */       {
/* 18 */         if (mappings == null)
/*    */         {
/* 20 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 24 */     return mappings;
/*    */   }
/*    */ 
/*    */   private ConvertSignedToUnsignedCommandType(int value)
/*    */   {
/* 29 */     this.intValue = value;
/* 30 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue()
/*    */   {
/* 35 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static ConvertSignedToUnsignedCommandType forValue(int value)
/*    */   {
/* 40 */     return (ConvertSignedToUnsignedCommandType)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.ConvertSignedToUnsignedCommandType
 * JD-Core Version:    0.6.2
 */