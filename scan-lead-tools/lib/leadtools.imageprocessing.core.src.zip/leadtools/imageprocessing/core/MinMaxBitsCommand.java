/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class MinMaxBitsCommand extends RasterCommand
/*    */ {
/*    */   private int _minimumBit;
/*    */   private int _maximumBit;
/*    */ 
/*    */   public MinMaxBitsCommand()
/*    */   {
/* 13 */     this._minimumBit = 0;
/* 14 */     this._maximumBit = 0;
/*    */   }
/*    */ 
/*    */   public int getMinimumBit() {
/* 18 */     return this._minimumBit;
/*    */   }
/*    */ 
/*    */   public int getMaximumBit() {
/* 22 */     return this._maximumBit;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 27 */     return "Minimum and Maximum Bits";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 32 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 35 */       int[] x = new int[1];
/* 36 */       int[] y = new int[1];
/* 37 */       ret = ltimgcor.GetMinMaxBits(bitmap, x, y, 0);
/*    */ 
/* 39 */       if (ret == L_ERROR.SUCCESS.getValue()) {
/* 40 */         this._minimumBit = x[0];
/* 41 */         this._maximumBit = y[0];
/*    */       }
/* 43 */       return ret;
/*    */     }
/*    */     finally {
/* 46 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.MinMaxBitsCommand
 * JD-Core Version:    0.6.2
 */