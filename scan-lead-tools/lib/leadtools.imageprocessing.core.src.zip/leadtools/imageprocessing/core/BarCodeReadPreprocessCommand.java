/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.LeadRect;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class BarCodeReadPreprocessCommand extends RasterCommand
/*    */ {
/*    */   private BarcodeTypes _bctype;
/*    */   private LeadRect _bcloc;
/*    */   private BarCodeReadPreprocessOptions _options;
/*    */ 
/*    */   public BarcodeTypes getBarcodeType()
/*    */   {
/* 15 */     return this._bctype;
/*    */   }
/*    */ 
/*    */   public LeadRect getBarcodeLocation() {
/* 19 */     return this._bcloc;
/*    */   }
/*    */ 
/*    */   public BarCodeReadPreprocessOptions getOptions() {
/* 23 */     return this._options;
/*    */   }
/*    */ 
/*    */   public void setOptions(BarCodeReadPreprocessOptions value) {
/* 27 */     this._options = value;
/*    */   }
/*    */ 
/*    */   public BarCodeReadPreprocessCommand() {
/* 31 */     this._bctype = BarcodeTypes.UNKOWN;
/* 32 */     this._options = BarCodeReadPreprocessOptions.USE_DEFAULT;
/* 33 */     this._bcloc = LeadRect.getEmpty();
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 38 */     return "Barcode Read Preprocess";
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 43 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 46 */       int[] type = new int[1];
/* 47 */       ret = ltimgcor.AnalyzeBarcode(bitmap, type, this._bcloc, this._options.getValue());
/* 48 */       return ret;
/*    */     }
/*    */     finally {
/* 51 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.BarCodeReadPreprocessCommand
 * JD-Core Version:    0.6.2
 */