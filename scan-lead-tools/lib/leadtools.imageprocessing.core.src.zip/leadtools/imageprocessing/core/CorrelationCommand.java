/*     */ package leadtools.imageprocessing.core;
/*     */ 
/*     */ import leadtools.L_ERROR;
/*     */ import leadtools.LeadPoint;
/*     */ import leadtools.RasterImage;
/*     */ import leadtools.RasterImageChangedFlags;
/*     */ import leadtools.imageprocessing.RasterCommand;
/*     */ 
/*     */ public class CorrelationCommand extends RasterCommand
/*     */ {
/*     */   private RasterImage _correlationImage;
/*     */   private LeadPoint[] _points;
/*     */   private int _numberOfPoints;
/*     */   private int _xStep;
/*     */   private int _yStep;
/*     */   private int _threshold;
/*     */ 
/*     */   public CorrelationCommand()
/*     */   {
/*  18 */     this._correlationImage = null;
/*  19 */     this._points = null;
/*  20 */     this._numberOfPoints = 0;
/*  21 */     this._xStep = 0;
/*  22 */     this._yStep = 0;
/*  23 */     this._threshold = 0;
/*     */   }
/*     */ 
/*     */   public CorrelationCommand(RasterImage correlationImage, LeadPoint[] points, int xStep, int yStep, int threshold) {
/*  27 */     this._correlationImage = correlationImage;
/*  28 */     this._xStep = xStep;
/*  29 */     this._yStep = yStep;
/*  30 */     this._threshold = threshold;
/*  31 */     this._numberOfPoints = 0;
/*     */ 
/*  33 */     if (points.length > 0) {
/*  34 */       this._points = new LeadPoint[points.length];
/*  35 */       for (int i = 0; i < points.length; i++)
/*  36 */         if (points[i] != null)
/*  37 */           this._points[i] = points[i].clone();
/*     */         else
/*  39 */           this._points[i] = new LeadPoint();
/*     */     }
/*     */   }
/*     */ 
/*     */   public RasterImage getCorrelationImage()
/*     */   {
/*  45 */     return this._correlationImage;
/*     */   }
/*     */ 
/*     */   public void setCorrelationImage(RasterImage value) {
/*  49 */     this._correlationImage = value;
/*     */   }
/*     */ 
/*     */   public LeadPoint[] getPoints() {
/*  53 */     return this._points;
/*     */   }
/*     */ 
/*     */   public void setPoints(LeadPoint[] value) {
/*  57 */     if (value.length > 0) {
/*  58 */       this._points = new LeadPoint[value.length];
/*     */ 
/*  60 */       for (int i = 0; i < value.length; i++)
/*     */       {
/*  62 */         if (value[i] == null)
/*  63 */           this._points[i] = new LeadPoint();
/*     */         else
/*  65 */           this._points[i] = value[i].clone();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getNumberOfPoints() {
/*  71 */     return this._numberOfPoints;
/*     */   }
/*     */ 
/*     */   public int getXStep() {
/*  75 */     return this._xStep;
/*     */   }
/*     */ 
/*     */   public void setXStep(int value) {
/*  79 */     this._xStep = value;
/*     */   }
/*     */ 
/*     */   public int getYStep() {
/*  83 */     return this._yStep;
/*     */   }
/*     */ 
/*     */   public void setYStep(int value) {
/*  87 */     this._yStep = value;
/*     */   }
/*     */ 
/*     */   public int getThreshold() {
/*  91 */     return this._threshold;
/*     */   }
/*     */ 
/*     */   public void setThreshold(int value) {
/*  95 */     this._threshold = value;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 100 */     return "Correlation";
/*     */   }
/*     */ 
/*     */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*     */   {
/* 105 */     int ret = L_ERROR.SUCCESS.getValue();
/* 106 */     long correlationImage = 0L;
/*     */     try
/*     */     {
/* 109 */       if (this._correlationImage != null) {
/* 110 */         correlationImage = this._correlationImage.getCurrentBitmapHandle();
/*     */       }
/* 112 */       int length = this._points != null ? this._points.length : 0;
/*     */ 
/* 114 */       int[] numberOfPoints = new int[1];
/*     */ 
/* 116 */       ret = ltimgcor.CorrelationBitmap(bitmap, correlationImage, this._points, length, numberOfPoints, this._xStep, this._yStep, this._threshold, 0);
/* 117 */       if (ret == L_ERROR.SUCCESS.getValue()) {
/* 118 */         this._numberOfPoints = numberOfPoints[0];
/*     */       }
/*     */ 
/* 121 */       return ret;
/*     */     }
/*     */     finally {
/* 124 */       if (this._correlationImage != null) {
/* 125 */         this._correlationImage.updateCurrentBitmapHandle();
/*     */       }
/* 127 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.CorrelationCommand
 * JD-Core Version:    0.6.2
 */