/*     */ package leadtools.imageprocessing.core;
/*     */ 
/*     */ import leadtools.LeadRect;
/*     */ 
/*     */ class LEADZONEDATA
/*     */ {
/*     */   public int _index;
/*     */   public int _zoneType;
/*     */   public LeadRect _location;
/*     */   public TEXTZONEDATA _textZoneData;
/*     */   public TABLEZONEDATA _tableZoneData;
/*     */ 
/*     */   public LEADZONEDATA()
/*     */   {
/* 333 */     this._index = 0;
/* 334 */     this._zoneType = 0;
/* 335 */     this._location = new LeadRect(0, 0, 0, 0);
/* 336 */     this._textZoneData = new TEXTZONEDATA();
/* 337 */     this._tableZoneData = new TABLEZONEDATA();
/*     */   }
/*     */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.LEADZONEDATA
 * JD-Core Version:    0.6.2
 */