/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import leadtools.L_ERROR;
/*    */ import leadtools.RasterImage;
/*    */ import leadtools.RasterImageChangedFlags;
/*    */ import leadtools.imageprocessing.RasterCommand;
/*    */ 
/*    */ public class ApplyTransformationParametersCommand extends RasterCommand
/*    */ {
/*    */   private int _xTranslation;
/*    */   private int _yTranslation;
/*    */   private int _angle;
/*    */   private int _xScale;
/*    */   private int _yScale;
/*    */   private int _flags;
/*    */ 
/*    */   public ApplyTransformationParametersCommand()
/*    */   {
/* 18 */     this._xTranslation = 0;
/* 19 */     this._yTranslation = 0;
/* 20 */     this._angle = 0;
/* 21 */     this._xScale = 100;
/* 22 */     this._yScale = 100;
/* 23 */     this._flags = ApplyTransformationParametersCommandFlags.NONE.getValue();
/*    */   }
/*    */ 
/*    */   public ApplyTransformationParametersCommand(int xTranslation, int yTranslation, int angle, int xScale, int yScale, int flags) {
/* 27 */     this._xTranslation = xTranslation;
/* 28 */     this._yTranslation = yTranslation;
/* 29 */     this._angle = angle;
/* 30 */     this._xScale = xScale;
/* 31 */     this._yScale = yScale;
/* 32 */     this._flags = flags;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 37 */     return "Apply Transformation Parameters";
/*    */   }
/*    */ 
/*    */   public int getXTranslation() {
/* 41 */     return this._xTranslation;
/*    */   }
/*    */ 
/*    */   public void setXTranslation(int value) {
/* 45 */     this._xTranslation = value;
/*    */   }
/*    */ 
/*    */   public int getYTranslation() {
/* 49 */     return this._yTranslation;
/*    */   }
/*    */ 
/*    */   public void setYTranslation(int value) {
/* 53 */     this._yTranslation = value;
/*    */   }
/*    */ 
/*    */   public int getAngle() {
/* 57 */     return this._angle;
/*    */   }
/*    */ 
/*    */   public void setAngle(int value) {
/* 61 */     this._angle = value;
/*    */   }
/*    */ 
/*    */   public int getXScale() {
/* 65 */     return this._xScale;
/*    */   }
/*    */ 
/*    */   public void setXScale(int value) {
/* 69 */     this._xScale = value;
/*    */   }
/*    */ 
/*    */   public int getYScale() {
/* 73 */     return this._yScale;
/*    */   }
/*    */ 
/*    */   public void setYScale(int value) {
/* 77 */     this._yScale = value;
/*    */   }
/*    */ 
/*    */   public int getFlags() {
/* 81 */     return this._flags;
/*    */   }
/*    */ 
/*    */   public void setFlags(int value) {
/* 85 */     this._flags = value;
/*    */   }
/*    */ 
/*    */   protected int runCommand(RasterImage image, long bitmap, int[] changedFlags)
/*    */   {
/* 90 */     int ret = L_ERROR.SUCCESS.getValue();
/*    */     try
/*    */     {
/* 93 */       ret = ltimgcor.ApplyTransformationParameters(bitmap, this._xTranslation, this._yTranslation, this._angle, this._xScale, this._yScale, this._flags);
/* 94 */       return ret;
/*    */     }
/*    */     finally {
/* 97 */       changedFlags[0] |= RasterImageChangedFlags.DATA;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.ApplyTransformationParametersCommand
 * JD-Core Version:    0.6.2
 */