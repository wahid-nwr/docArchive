/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum CLAHECommandFlags
/*    */ {
/*  5 */   APPLY_NORMAL_DISTRIBUTION(4), 
/*  6 */   APPLY_EXPONENTIAL_DISTRIBUTION(2), 
/*  7 */   APPLY_RAYLIEH_DISTRIBUTION(1), 
/*  8 */   APPLY_SIGMOID_DISTRIBUTION(8);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, CLAHECommandFlags> mappings;
/*    */ 
/* 13 */   private static HashMap<Integer, CLAHECommandFlags> getMappings() { if (mappings == null) {
/* 14 */       synchronized (CLAHECommandFlags.class) {
/* 15 */         if (mappings == null) {
/* 16 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 21 */     return mappings; }
/*    */ 
/*    */   private CLAHECommandFlags(int value)
/*    */   {
/* 25 */     this.intValue = value;
/* 26 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue() {
/* 30 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static CLAHECommandFlags forValue(int value) {
/* 34 */     return (CLAHECommandFlags)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.CLAHECommandFlags
 * JD-Core Version:    0.6.2
 */