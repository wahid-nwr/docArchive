/*    */ package leadtools.imageprocessing.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public enum BlankPageDetectorCommandFlags
/*    */ {
/*  5 */   NONE(0), 
/*  6 */   DETECT_EMPTY_PAGE(0), 
/*  7 */   DETECT_NOISY_PAGE(1), 
/*  8 */   DONT_USE_BLEED_THROUGH(0), 
/*  9 */   USE_BLEED_THROUGH(16), 
/* 10 */   DONT_DETECT_LINED_PAGE(0), 
/* 11 */   DETECT_LINED_PAGE(256), 
/* 12 */   DONT_USE_ACTIVE_AREA(0), 
/* 13 */   USE_ACTIVE_AREA(4096), 
/* 14 */   USE_DEFAULT_MARGINS(0), 
/* 15 */   USE_USER_MARGINS(65536);
/*    */ 
/*    */   private int intValue;
/*    */   private static HashMap<Integer, BlankPageDetectorCommandFlags> mappings;
/*    */ 
/* 21 */   private static HashMap<Integer, BlankPageDetectorCommandFlags> getMappings() { if (mappings == null) {
/* 22 */       synchronized (BlankPageDetectorCommandFlags.class) {
/* 23 */         if (mappings == null) {
/* 24 */           mappings = new HashMap();
/*    */         }
/*    */       }
/*    */     }
/* 28 */     return mappings; }
/*    */ 
/*    */   private BlankPageDetectorCommandFlags(int value)
/*    */   {
/* 32 */     this.intValue = value;
/* 33 */     getMappings().put(Integer.valueOf(value), this);
/*    */   }
/*    */ 
/*    */   public int getValue() {
/* 37 */     return this.intValue;
/*    */   }
/*    */ 
/*    */   public static BlankPageDetectorCommandFlags forValue(int value) {
/* 41 */     return (BlankPageDetectorCommandFlags)getMappings().get(Integer.valueOf(value));
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.imageprocessing.core.jar
 * Qualified Name:     leadtools.imageprocessing.core.BlankPageDetectorCommandFlags
 * JD-Core Version:    0.6.2
 */