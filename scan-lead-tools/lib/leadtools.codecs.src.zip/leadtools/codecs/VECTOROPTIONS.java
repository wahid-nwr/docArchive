package leadtools.codecs;

import leadtools.internal.IsInternal;

@IsInternal
class VECTOROPTIONS
{
  public int uStructSize;
  public VEC2DOPTIONS Vec2DOptions;
  public int nBitsPerPixel;
  public boolean bForceBackgroundColor;
  public int BackgroundColor;
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.VECTOROPTIONS
 * JD-Core Version:    0.6.2
 */