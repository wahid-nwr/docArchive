package leadtools.codecs;

import leadtools.internal.IsInternal;

@IsInternal
class LOADSVGOPTIONS
{
  public int uStructSize;
  public int uFlags;
  public long SvgHandle;
  public int uMaximumElements;
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.LOADSVGOPTIONS
 * JD-Core Version:    0.6.2
 */