/*   */ package leadtools.codecs;
/*   */ 
/*   */ import leadtools.internal.IsInternal;
/*   */ 
/*   */ @IsInternal
/*   */ class FILEPLTOPTIONS
/*   */ {
/*   */   public int uStructSize;
/* 8 */   public int[] PenWidth = new int[8];
/* 9 */   public int[] PenColor = new int[8];
/*   */   public boolean bPenColorOverride;
/*   */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.FILEPLTOPTIONS
 * JD-Core Version:    0.6.2
 */