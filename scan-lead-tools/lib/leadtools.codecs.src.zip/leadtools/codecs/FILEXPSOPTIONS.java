package leadtools.codecs;

import leadtools.internal.IsInternal;

@IsInternal
class FILEXPSOPTIONS
{
  public int uStructSize;
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.FILEXPSOPTIONS
 * JD-Core Version:    0.6.2
 */