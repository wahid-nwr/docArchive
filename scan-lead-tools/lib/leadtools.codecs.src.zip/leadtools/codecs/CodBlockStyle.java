package leadtools.codecs;

class CodBlockStyle
{
  public boolean bSelectiveACBypass;
  public boolean bResetContextOnBoundaries;
  public boolean bTerminationOnEachPass;
  public boolean bVerticallyCausalContext;
  public boolean bPredictableTermination;
  public boolean bErrorResilienceSymbol;
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.CodBlockStyle
 * JD-Core Version:    0.6.2
 */