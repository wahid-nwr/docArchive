package leadtools.codecs;

public abstract interface CodecsSaveImageListener
{
  public abstract void onSaveImage(CodecsSaveImageEvent paramCodecsSaveImageEvent);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.CodecsSaveImageListener
 * JD-Core Version:    0.6.2
 */