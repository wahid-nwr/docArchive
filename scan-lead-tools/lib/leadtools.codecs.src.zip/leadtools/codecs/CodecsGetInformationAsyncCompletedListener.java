package leadtools.codecs;

public abstract interface CodecsGetInformationAsyncCompletedListener
{
  public abstract void onGetInformationAsyncCompleted(CodecsGetInformationAsyncCompletedEvent paramCodecsGetInformationAsyncCompletedEvent);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.CodecsGetInformationAsyncCompletedListener
 * JD-Core Version:    0.6.2
 */