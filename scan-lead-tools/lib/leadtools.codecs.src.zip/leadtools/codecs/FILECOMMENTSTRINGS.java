package leadtools.codecs;

import leadtools.internal.IsInternal;

@IsInternal
class FILECOMMENTSTRINGS
{
  public String pString;
  public int uLength;
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.FILECOMMENTSTRINGS
 * JD-Core Version:    0.6.2
 */