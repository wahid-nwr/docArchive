package leadtools.codecs;

import leadtools.internal.IsInternal;

@IsInternal
class FILEPDFOPTIONS
{
  public boolean bUseLibFonts;
  public int nDisplayDepth;
  public int nTextAlpha;
  public int nGraphicsAlpha;
  public String szPassword;
  public int uFlags;
  public boolean bCallbackEnabled;
  public long pCallbackUserData;
  public String szOutputFullPath;
  public boolean bUseImageData;
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.FILEPDFOPTIONS
 * JD-Core Version:    0.6.2
 */