package leadtools.codecs;

import leadtools.internal.IsInternal;

@IsInternal
class PRIVATETAG
{
  public short uTag;
  public short uType;
  public int uCount;
  public byte[] pData;
  public PRIVATETAG pNext;
  public PRIVATETAG pPrev;
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.PRIVATETAG
 * JD-Core Version:    0.6.2
 */