package leadtools.codecs;

public abstract interface CodecsLoadSvgAsyncCompletedListener
{
  public abstract void onLoadSvgAsyncCompleted(CodecsLoadSvgAsyncCompletedEvent paramCodecsLoadSvgAsyncCompletedEvent);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.CodecsLoadSvgAsyncCompletedListener
 * JD-Core Version:    0.6.2
 */