package leadtools.codecs;

public abstract interface CodecsRedirectSeekListener
{
  public abstract void onRedirectSeek(CodecsRedirectSeekEvent paramCodecsRedirectSeekEvent);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.CodecsRedirectSeekListener
 * JD-Core Version:    0.6.2
 */