package leadtools.codecs;

import leadtools.internal.IsInternal;

@IsInternal
class FILEPTKOPTIONS
{
  public int uStructSize;
  int nPTKResolution;
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.FILEPTKOPTIONS
 * JD-Core Version:    0.6.2
 */