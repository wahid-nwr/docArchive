package leadtools.codecs;

import leadtools.internal.IsInternal;

@IsInternal
class FILEPSTOPTIONS
{
  public int uStructSize;
  public long uMessageNumber;
  public int uFlags;
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.FILEPSTOPTIONS
 * JD-Core Version:    0.6.2
 */