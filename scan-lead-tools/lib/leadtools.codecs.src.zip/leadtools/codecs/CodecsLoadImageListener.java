package leadtools.codecs;

public abstract interface CodecsLoadImageListener
{
  public abstract void onLoadImage(CodecsLoadImageEvent paramCodecsLoadImageEvent);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.CodecsLoadImageListener
 * JD-Core Version:    0.6.2
 */