package leadtools.codecs;

public abstract interface CodecsRedirectCloseListener
{
  public abstract void onRedirectClose(CodecsRedirectCloseEvent paramCodecsRedirectCloseEvent);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.CodecsRedirectCloseListener
 * JD-Core Version:    0.6.2
 */