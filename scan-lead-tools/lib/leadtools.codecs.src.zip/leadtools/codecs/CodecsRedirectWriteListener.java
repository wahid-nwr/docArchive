package leadtools.codecs;

public abstract interface CodecsRedirectWriteListener
{
  public abstract void onRedirectWrite(CodecsRedirectWriteEvent paramCodecsRedirectWriteEvent);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.CodecsRedirectWriteListener
 * JD-Core Version:    0.6.2
 */