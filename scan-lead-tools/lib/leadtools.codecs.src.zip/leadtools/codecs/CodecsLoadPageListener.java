package leadtools.codecs;

public abstract interface CodecsLoadPageListener
{
  public abstract void onLoadPage(CodecsPageEvent paramCodecsPageEvent);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.CodecsLoadPageListener
 * JD-Core Version:    0.6.2
 */