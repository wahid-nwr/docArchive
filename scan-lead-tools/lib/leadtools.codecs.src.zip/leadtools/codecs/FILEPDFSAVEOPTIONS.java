package leadtools.codecs;

import leadtools.internal.IsInternal;

@IsInternal
class FILEPDFSAVEOPTIONS
{
  public int uStructSize;
  public String szUserPassword;
  public String szOwnerPassword;
  public boolean b128bit;
  public int dwEncryptFlags;
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.FILEPDFSAVEOPTIONS
 * JD-Core Version:    0.6.2
 */