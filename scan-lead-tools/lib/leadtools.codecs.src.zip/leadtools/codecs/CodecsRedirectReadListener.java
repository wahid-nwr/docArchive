package leadtools.codecs;

public abstract interface CodecsRedirectReadListener
{
  public abstract void onRedirectRead(CodecsRedirectReadEvent paramCodecsRedirectReadEvent);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.CodecsRedirectReadListener
 * JD-Core Version:    0.6.2
 */