package leadtools.codecs;

import leadtools.internal.IsInternal;

@IsInternal
public class DIMENSION
{
  public int nWidth;
  public int nHeight;
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.DIMENSION
 * JD-Core Version:    0.6.2
 */