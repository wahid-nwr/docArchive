package leadtools.codecs;

import leadtools.internal.IsInternal;

@IsInternal
class FILEVFFOPTIONS
{
  int uStructSize;
  CodecsVffView View;
  int uFlags;
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.FILEVFFOPTIONS
 * JD-Core Version:    0.6.2
 */