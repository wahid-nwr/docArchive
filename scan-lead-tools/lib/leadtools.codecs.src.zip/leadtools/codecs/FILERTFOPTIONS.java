package leadtools.codecs;

import leadtools.internal.IsInternal;

@IsInternal
public class FILERTFOPTIONS
{
  public int uStructSize;
  public int crBackColor;
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.FILERTFOPTIONS
 * JD-Core Version:    0.6.2
 */