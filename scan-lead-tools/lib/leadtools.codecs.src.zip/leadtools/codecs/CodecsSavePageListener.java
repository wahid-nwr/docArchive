package leadtools.codecs;

public abstract interface CodecsSavePageListener
{
  public abstract void onSavePage(CodecsPageEvent paramCodecsPageEvent);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.CodecsSavePageListener
 * JD-Core Version:    0.6.2
 */