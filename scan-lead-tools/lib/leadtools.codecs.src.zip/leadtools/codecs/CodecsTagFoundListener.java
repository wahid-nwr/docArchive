package leadtools.codecs;

public abstract interface CodecsTagFoundListener
{
  public abstract void onTagFound(CodecsEnumTagsEvent paramCodecsEnumTagsEvent);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.CodecsTagFoundListener
 * JD-Core Version:    0.6.2
 */