package leadtools.codecs;

public abstract interface CodecsRedirectOpenListener
{
  public abstract void onRedirectOpen(CodecsRedirectOpenEvent paramCodecsRedirectOpenEvent);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.CodecsRedirectOpenListener
 * JD-Core Version:    0.6.2
 */