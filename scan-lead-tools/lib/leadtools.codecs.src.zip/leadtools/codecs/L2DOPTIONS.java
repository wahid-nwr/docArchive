package leadtools.codecs;

import leadtools.internal.IsInternal;

@IsInternal
class L2DOPTIONS
{
  public int nViewWidth;
  public int nViewHeight;
  public int nViewMode;
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.L2DOPTIONS
 * JD-Core Version:    0.6.2
 */