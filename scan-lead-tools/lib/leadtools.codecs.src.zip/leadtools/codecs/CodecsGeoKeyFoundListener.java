package leadtools.codecs;

public abstract interface CodecsGeoKeyFoundListener
{
  public abstract void onGeoKeyFound(CodecsEnumGeoKeysEvent paramCodecsEnumGeoKeysEvent);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.CodecsGeoKeyFoundListener
 * JD-Core Version:    0.6.2
 */