/*    */ package leadtools.codecs;
/*    */ 
/*    */ import leadtools.LeadEvent;
/*    */ 
/*    */ public class CodecsRedirectCloseEvent extends LeadEvent
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public CodecsRedirectCloseEvent(Object source)
/*    */   {
/* 11 */     super(source);
/*    */   }
/*    */ 
/*    */   public void init()
/*    */   {
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.CodecsRedirectCloseEvent
 * JD-Core Version:    0.6.2
 */