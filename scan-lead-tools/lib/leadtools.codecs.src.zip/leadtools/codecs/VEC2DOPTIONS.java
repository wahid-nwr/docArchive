package leadtools.codecs;

import leadtools.internal.IsInternal;

@IsInternal
class VEC2DOPTIONS
{
  public int uStructSize;
  public int nViewWidth;
  public int nViewHeight;
  public CodecsVectorViewMode ViewMode;
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.VEC2DOPTIONS
 * JD-Core Version:    0.6.2
 */