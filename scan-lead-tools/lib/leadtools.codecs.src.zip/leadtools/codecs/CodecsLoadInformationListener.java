package leadtools.codecs;

public abstract interface CodecsLoadInformationListener
{
  public abstract void onLoadInformation(CodecsLoadInformationEvent paramCodecsLoadInformationEvent);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.CodecsLoadInformationListener
 * JD-Core Version:    0.6.2
 */