package leadtools.codecs;

public abstract interface CodecsLoadAsyncCompletedListener
{
  public abstract void onLoadAsyncCompleted(CodecsLoadAsyncCompletedEvent paramCodecsLoadAsyncCompletedEvent);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.CodecsLoadAsyncCompletedListener
 * JD-Core Version:    0.6.2
 */