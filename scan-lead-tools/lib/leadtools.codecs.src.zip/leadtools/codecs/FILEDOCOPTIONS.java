package leadtools.codecs;

import leadtools.internal.IsInternal;

@IsInternal
class FILEDOCOPTIONS
{
  public int uStructSize;
  public int nBitsPerPixel;
  public int uFlags;
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.FILEDOCOPTIONS
 * JD-Core Version:    0.6.2
 */