/*    */ package leadtools.codecs;
/*    */ 
/*    */ public class CodecsXpsLoadOptions
/*    */ {
/*    */   CodecsXpsLoadOptions(CodecsOptions owner)
/*    */   {
/*    */   }
/*    */ 
/*    */   CodecsXpsLoadOptions copy(CodecsOptions owner)
/*    */   {
/* 11 */     CodecsXpsLoadOptions copy = new CodecsXpsLoadOptions(owner);
/* 12 */     return copy;
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.codecs.jar
 * Qualified Name:     leadtools.codecs.CodecsXpsLoadOptions
 * JD-Core Version:    0.6.2
 */