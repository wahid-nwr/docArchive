// INTERNAL ERROR //

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.sane.jar
 * Qualified Name:     leadtools.sane.SaneStatus
 * JD-Core Version:    0.6.2
 */