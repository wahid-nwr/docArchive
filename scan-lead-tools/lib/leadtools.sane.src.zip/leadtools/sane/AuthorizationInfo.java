/*     */ package leadtools.sane;
/*     */ 
/*     */ public class AuthorizationInfo
/*     */ {
/*     */   String _password;
/*     */   String _userName;
/*     */ 
/*     */   public AuthorizationInfo(String arg1, String password)
/*     */   {
/*  64 */     this._userName = userName; this._password = password;
/*     */   }
/*     */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.sane.jar
 * Qualified Name:     leadtools.sane.AuthorizationInfo
 * JD-Core Version:    0.6.2
 */