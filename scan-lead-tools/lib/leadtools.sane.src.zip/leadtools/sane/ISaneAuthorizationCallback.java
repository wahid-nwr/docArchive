package leadtools.sane;

public abstract interface ISaneAuthorizationCallback
{
  public abstract AuthorizationInfo onAuthorization(String paramString);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.sane.jar
 * Qualified Name:     leadtools.sane.ISaneAuthorizationCallback
 * JD-Core Version:    0.6.2
 */