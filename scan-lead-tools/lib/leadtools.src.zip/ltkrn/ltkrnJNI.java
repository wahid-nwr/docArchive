package ltkrn;

public class ltkrnJNI
{
  public static final native void L_POINT_x_set(long paramLong, L_POINT paramL_POINT, int paramInt);

  public static final native int L_POINT_x_get(long paramLong, L_POINT paramL_POINT);

  public static final native void L_POINT_y_set(long paramLong, L_POINT paramL_POINT, int paramInt);

  public static final native int L_POINT_y_get(long paramLong, L_POINT paramL_POINT);

  public static final native long new_L_POINT();

  public static final native void delete_L_POINT(long paramLong);

  public static final native void L_SIZE_cx_set(long paramLong, L_SIZE paramL_SIZE, int paramInt);

  public static final native int L_SIZE_cx_get(long paramLong, L_SIZE paramL_SIZE);

  public static final native void L_SIZE_cy_set(long paramLong, L_SIZE paramL_SIZE, int paramInt);

  public static final native int L_SIZE_cy_get(long paramLong, L_SIZE paramL_SIZE);

  public static final native long new_L_SIZE();

  public static final native void delete_L_SIZE(long paramLong);

  public static final native void L_RECT_left_set(long paramLong, L_RECT paramL_RECT, int paramInt);

  public static final native int L_RECT_left_get(long paramLong, L_RECT paramL_RECT);

  public static final native void L_RECT_top_set(long paramLong, L_RECT paramL_RECT, int paramInt);

  public static final native int L_RECT_top_get(long paramLong, L_RECT paramL_RECT);

  public static final native void L_RECT_right_set(long paramLong, L_RECT paramL_RECT, int paramInt);

  public static final native int L_RECT_right_get(long paramLong, L_RECT paramL_RECT);

  public static final native void L_RECT_bottom_set(long paramLong, L_RECT paramL_RECT, int paramInt);

  public static final native int L_RECT_bottom_get(long paramLong, L_RECT paramL_RECT);

  public static final native long new_L_RECT();

  public static final native void delete_L_RECT(long paramLong);

  public static final native void L_RGBQUAD_rgbBlue_set(long paramLong, L_RGBQUAD paramL_RGBQUAD, short paramShort);

  public static final native short L_RGBQUAD_rgbBlue_get(long paramLong, L_RGBQUAD paramL_RGBQUAD);

  public static final native void L_RGBQUAD_rgbGreen_set(long paramLong, L_RGBQUAD paramL_RGBQUAD, short paramShort);

  public static final native short L_RGBQUAD_rgbGreen_get(long paramLong, L_RGBQUAD paramL_RGBQUAD);

  public static final native void L_RGBQUAD_rgbRed_set(long paramLong, L_RGBQUAD paramL_RGBQUAD, short paramShort);

  public static final native short L_RGBQUAD_rgbRed_get(long paramLong, L_RGBQUAD paramL_RGBQUAD);

  public static final native void L_RGBQUAD_rgbReserved_set(long paramLong, L_RGBQUAD paramL_RGBQUAD, short paramShort);

  public static final native short L_RGBQUAD_rgbReserved_get(long paramLong, L_RGBQUAD paramL_RGBQUAD);

  public static final native long new_L_RGBQUAD();

  public static final native void delete_L_RGBQUAD(long paramLong);

  public static final native void L_RGBQUAD16_rgbBlue_set(long paramLong, L_RGBQUAD16 paramL_RGBQUAD16, int paramInt);

  public static final native int L_RGBQUAD16_rgbBlue_get(long paramLong, L_RGBQUAD16 paramL_RGBQUAD16);

  public static final native void L_RGBQUAD16_rgbGreen_set(long paramLong, L_RGBQUAD16 paramL_RGBQUAD16, int paramInt);

  public static final native int L_RGBQUAD16_rgbGreen_get(long paramLong, L_RGBQUAD16 paramL_RGBQUAD16);

  public static final native void L_RGBQUAD16_rgbRed_set(long paramLong, L_RGBQUAD16 paramL_RGBQUAD16, int paramInt);

  public static final native int L_RGBQUAD16_rgbRed_get(long paramLong, L_RGBQUAD16 paramL_RGBQUAD16);

  public static final native void L_RGBQUAD16_rgbReserved_set(long paramLong, L_RGBQUAD16 paramL_RGBQUAD16, int paramInt);

  public static final native int L_RGBQUAD16_rgbReserved_get(long paramLong, L_RGBQUAD16 paramL_RGBQUAD16);

  public static final native long new_L_RGBQUAD16();

  public static final native void delete_L_RGBQUAD16(long paramLong);

  public static final native void L_POINTD_x_set(long paramLong, L_POINTD paramL_POINTD, double paramDouble);

  public static final native double L_POINTD_x_get(long paramLong, L_POINTD paramL_POINTD);

  public static final native void L_POINTD_y_set(long paramLong, L_POINTD paramL_POINTD, double paramDouble);

  public static final native double L_POINTD_y_get(long paramLong, L_POINTD paramL_POINTD);

  public static final native long new_L_POINTD();

  public static final native void delete_L_POINTD(long paramLong);

  public static final native void L_SIZED_width_set(long paramLong, L_SIZED paramL_SIZED, double paramDouble);

  public static final native double L_SIZED_width_get(long paramLong, L_SIZED paramL_SIZED);

  public static final native void L_SIZED_height_set(long paramLong, L_SIZED paramL_SIZED, double paramDouble);

  public static final native double L_SIZED_height_get(long paramLong, L_SIZED paramL_SIZED);

  public static final native long new_L_SIZED();

  public static final native void delete_L_SIZED(long paramLong);

  public static final native void L_RECTD_x_set(long paramLong, L_RECTD paramL_RECTD, double paramDouble);

  public static final native double L_RECTD_x_get(long paramLong, L_RECTD paramL_RECTD);

  public static final native void L_RECTD_y_set(long paramLong, L_RECTD paramL_RECTD, double paramDouble);

  public static final native double L_RECTD_y_get(long paramLong, L_RECTD paramL_RECTD);

  public static final native void L_RECTD_width_set(long paramLong, L_RECTD paramL_RECTD, double paramDouble);

  public static final native double L_RECTD_width_get(long paramLong, L_RECTD paramL_RECTD);

  public static final native void L_RECTD_height_set(long paramLong, L_RECTD paramL_RECTD, double paramDouble);

  public static final native double L_RECTD_height_get(long paramLong, L_RECTD paramL_RECTD);

  public static final native long new_L_RECTD();

  public static final native void delete_L_RECTD(long paramLong);

  public static final native void L_LENGTHD_value_set(long paramLong, L_LENGTHD paramL_LENGTHD, double paramDouble);

  public static final native double L_LENGTHD_value_get(long paramLong, L_LENGTHD paramL_LENGTHD);

  public static final native long new_L_LENGTHD();

  public static final native void delete_L_LENGTHD(long paramLong);

  public static final native void L_MATRIX_m11_set(long paramLong, L_MATRIX paramL_MATRIX, double paramDouble);

  public static final native double L_MATRIX_m11_get(long paramLong, L_MATRIX paramL_MATRIX);

  public static final native void L_MATRIX_m12_set(long paramLong, L_MATRIX paramL_MATRIX, double paramDouble);

  public static final native double L_MATRIX_m12_get(long paramLong, L_MATRIX paramL_MATRIX);

  public static final native void L_MATRIX_m21_set(long paramLong, L_MATRIX paramL_MATRIX, double paramDouble);

  public static final native double L_MATRIX_m21_get(long paramLong, L_MATRIX paramL_MATRIX);

  public static final native void L_MATRIX_m22_set(long paramLong, L_MATRIX paramL_MATRIX, double paramDouble);

  public static final native double L_MATRIX_m22_get(long paramLong, L_MATRIX paramL_MATRIX);

  public static final native void L_MATRIX_offsetX_set(long paramLong, L_MATRIX paramL_MATRIX, double paramDouble);

  public static final native double L_MATRIX_offsetX_get(long paramLong, L_MATRIX paramL_MATRIX);

  public static final native void L_MATRIX_offsetY_set(long paramLong, L_MATRIX paramL_MATRIX, double paramDouble);

  public static final native double L_MATRIX_offsetY_get(long paramLong, L_MATRIX paramL_MATRIX);

  public static final native void L_MATRIX_type_set(long paramLong, L_MATRIX paramL_MATRIX, int paramInt);

  public static final native int L_MATRIX_type_get(long paramLong, L_MATRIX paramL_MATRIX);

  public static final native void L_MATRIX_padding_set(long paramLong, L_MATRIX paramL_MATRIX, int paramInt);

  public static final native int L_MATRIX_padding_get(long paramLong, L_MATRIX paramL_MATRIX);

  public static final native long new_L_MATRIX();

  public static final native void delete_L_MATRIX(long paramLong);

  public static final native void L_Point_Make(long paramLong, L_POINT paramL_POINT, int paramInt1, int paramInt2);

  public static final native void L_Point_Empty(long paramLong, L_POINT paramL_POINT);

  public static final native int L_Point_IsEmpty(long paramLong, L_POINT paramL_POINT);

  public static final native int L_Point_IsEqual(long paramLong1, L_POINT paramL_POINT1, long paramLong2, L_POINT paramL_POINT2);

  public static final native void L_Point_ToPointD(long paramLong1, L_POINT paramL_POINT, long paramLong2, L_POINTD paramL_POINTD);

  public static final native void L_Size_Make(long paramLong, L_SIZE paramL_SIZE, int paramInt1, int paramInt2);

  public static final native void L_Size_Empty(long paramLong, L_SIZE paramL_SIZE);

  public static final native int L_Size_IsEmpty(long paramLong, L_SIZE paramL_SIZE);

  public static final native int L_Size_IsEqual(long paramLong1, L_SIZE paramL_SIZE1, long paramLong2, L_SIZE paramL_SIZE2);

  public static final native void L_Size_ToSizeD(long paramLong1, L_SIZE paramL_SIZE, long paramLong2, L_SIZED paramL_SIZED);

  public static final native void L_Rect_Make(long paramLong, L_RECT paramL_RECT, int paramInt1, int paramInt2, int paramInt3, int paramInt4);

  public static final native void L_Rect_FromLTRB(long paramLong, L_RECT paramL_RECT, int paramInt1, int paramInt2, int paramInt3, int paramInt4);

  public static final native void L_Rect_Empty(long paramLong, L_RECT paramL_RECT);

  public static final native int L_Rect_IsEmpty(long paramLong, L_RECT paramL_RECT);

  public static final native int L_Rect_IsEqual(long paramLong1, L_RECT paramL_RECT1, long paramLong2, L_RECT paramL_RECT2);

  public static final native int L_Rect_Width(long paramLong, L_RECT paramL_RECT);

  public static final native int L_Rect_Height(long paramLong, L_RECT paramL_RECT);

  public static final native void L_Rect_TopLeft(long paramLong1, L_RECT paramL_RECT, long paramLong2, L_POINT paramL_POINT);

  public static final native void L_Rect_TopRight(long paramLong1, L_RECT paramL_RECT, long paramLong2, L_POINT paramL_POINT);

  public static final native void L_Rect_BottomRight(long paramLong1, L_RECT paramL_RECT, long paramLong2, L_POINT paramL_POINT);

  public static final native void L_Rect_BottomLeft(long paramLong1, L_RECT paramL_RECT, long paramLong2, L_POINT paramL_POINT);

  public static final native void L_Rect_Location(long paramLong1, L_RECT paramL_RECT, long paramLong2, L_POINT paramL_POINT);

  public static final native void L_Rect_Size(long paramLong1, L_RECT paramL_RECT, long paramLong2, L_SIZE paramL_SIZE);

  public static final native int L_Rect_ContainsPoint(long paramLong1, L_RECT paramL_RECT, long paramLong2, L_POINT paramL_POINT);

  public static final native int L_Rect_ContainsRect(long paramLong1, L_RECT paramL_RECT1, long paramLong2, L_RECT paramL_RECT2);

  public static final native void L_Rect_Inflate(long paramLong1, L_RECT paramL_RECT, long paramLong2, L_SIZE paramL_SIZE);

  public static final native void L_Rect_Intersect(long paramLong1, L_RECT paramL_RECT1, long paramLong2, L_RECT paramL_RECT2, long paramLong3, L_RECT paramL_RECT3);

  public static final native int L_Rect_IntersectsWith(long paramLong1, L_RECT paramL_RECT1, long paramLong2, L_RECT paramL_RECT2);

  public static final native void L_Rect_Union(long paramLong1, L_RECT paramL_RECT1, long paramLong2, L_RECT paramL_RECT2, long paramLong3, L_RECT paramL_RECT3);

  public static final native void L_Rect_Offset(long paramLong1, L_RECT paramL_RECT, long paramLong2, L_SIZE paramL_SIZE);

  public static final native void L_Rect_ToRectD(long paramLong1, L_RECT paramL_RECT, long paramLong2, L_RECTD paramL_RECTD);

  public static final native void L_PointD_Make(long paramLong, L_POINTD paramL_POINTD, double paramDouble1, double paramDouble2);

  public static final native void L_PointD_Empty(long paramLong, L_POINTD paramL_POINTD);

  public static final native int L_PointD_IsEmpty(long paramLong, L_POINTD paramL_POINTD);

  public static final native int L_PointD_IsEqual(long paramLong1, L_POINTD paramL_POINTD1, long paramLong2, L_POINTD paramL_POINTD2);

  public static final native void L_PointD_Multiply(long paramLong1, L_POINTD paramL_POINTD, long paramLong2, L_MATRIX paramL_MATRIX);

  public static final native void L_PointD_ToPoint(long paramLong1, L_POINTD paramL_POINTD, long paramLong2, L_POINT paramL_POINT);

  public static final native void L_SizeD_Make(long paramLong, L_SIZED paramL_SIZED, double paramDouble1, double paramDouble2);

  public static final native void L_SizeD_Empty(long paramLong, L_SIZED paramL_SIZED);

  public static final native int L_SizeD_IsEmpty(long paramLong, L_SIZED paramL_SIZED);

  public static final native int L_SizeD_IsEqual(long paramLong1, L_SIZED paramL_SIZED1, long paramLong2, L_SIZED paramL_SIZED2);

  public static final native void L_SizeD_ToSize(long paramLong1, L_SIZED paramL_SIZED, long paramLong2, L_SIZE paramL_SIZE);

  public static final native void L_RectD_Make(long paramLong, L_RECTD paramL_RECTD, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);

  public static final native void L_RectD_FromLTRB(long paramLong, L_RECTD paramL_RECTD, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);

  public static final native void L_RectD_Empty(long paramLong, L_RECTD paramL_RECTD);

  public static final native int L_RectD_IsEmpty(long paramLong, L_RECTD paramL_RECTD);

  public static final native int L_RectD_IsEqual(long paramLong1, L_RECTD paramL_RECTD1, long paramLong2, L_RECTD paramL_RECTD2);

  public static final native double L_RectD_Left(long paramLong, L_RECTD paramL_RECTD);

  public static final native double L_RectD_Right(long paramLong, L_RECTD paramL_RECTD);

  public static final native double L_RectD_Top(long paramLong, L_RECTD paramL_RECTD);

  public static final native double L_RectD_Bottom(long paramLong, L_RECTD paramL_RECTD);

  public static final native void L_RectD_TopLeft(long paramLong1, L_RECTD paramL_RECTD, long paramLong2, L_POINTD paramL_POINTD);

  public static final native void L_RectD_TopRight(long paramLong1, L_RECTD paramL_RECTD, long paramLong2, L_POINTD paramL_POINTD);

  public static final native void L_RectD_BottomRight(long paramLong1, L_RECTD paramL_RECTD, long paramLong2, L_POINTD paramL_POINTD);

  public static final native void L_RectD_BottomLeft(long paramLong1, L_RECTD paramL_RECTD, long paramLong2, L_POINTD paramL_POINTD);

  public static final native void L_RectD_Location(long paramLong1, L_RECTD paramL_RECTD, long paramLong2, L_POINTD paramL_POINTD);

  public static final native void L_RectD_Size(long paramLong1, L_RECTD paramL_RECTD, long paramLong2, L_SIZED paramL_SIZED);

  public static final native int L_RectD_ContainsPoint(long paramLong1, L_RECTD paramL_RECTD, long paramLong2, L_POINTD paramL_POINTD);

  public static final native int L_RectD_ContainsRect(long paramLong1, L_RECTD paramL_RECTD1, long paramLong2, L_RECTD paramL_RECTD2);

  public static final native int L_RectD_IntersectsWith(long paramLong1, L_RECTD paramL_RECTD1, long paramLong2, L_RECTD paramL_RECTD2);

  public static final native void L_RectD_Intersect(long paramLong1, L_RECTD paramL_RECTD1, long paramLong2, L_RECTD paramL_RECTD2, long paramLong3, L_RECTD paramL_RECTD3);

  public static final native void L_RectD_Union(long paramLong1, L_RECTD paramL_RECTD1, long paramLong2, L_RECTD paramL_RECTD2, long paramLong3, L_RECTD paramL_RECTD3);

  public static final native void L_RectD_Offset(long paramLong1, L_RECTD paramL_RECTD, long paramLong2, L_SIZED paramL_SIZED);

  public static final native void L_RectD_Inflate(long paramLong1, L_RECTD paramL_RECTD, long paramLong2, L_SIZED paramL_SIZED);

  public static final native void L_RectD_Scale(long paramLong, L_RECTD paramL_RECTD, double paramDouble1, double paramDouble2);

  public static final native void L_RectD_Transform(long paramLong1, L_RECTD paramL_RECTD, long paramLong2, L_MATRIX paramL_MATRIX);

  public static final native void L_RectD_ToRect(long paramLong1, L_RECTD paramL_RECTD, long paramLong2, L_RECT paramL_RECT);

  public static final native void L_LengthD_Make(long paramLong, L_LENGTHD paramL_LENGTHD, double paramDouble);

  public static final native int L_LengthD_IsEqual(long paramLong1, L_LENGTHD paramL_LENGTHD1, long paramLong2, L_LENGTHD paramL_LENGTHD2);

  public static final native void L_Matrix_Set(long paramLong, L_MATRIX paramL_MATRIX, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6);

  public static final native void L_Matrix_Identity(long paramLong, L_MATRIX paramL_MATRIX);

  public static final native int L_Matrix_IsIdentity(long paramLong, L_MATRIX paramL_MATRIX);

  public static final native double L_Matrix_Determinant(long paramLong, L_MATRIX paramL_MATRIX);

  public static final native int L_Matrix_HasInverse(long paramLong, L_MATRIX paramL_MATRIX);

  public static final native double L_Matrix_GetM11(long paramLong, L_MATRIX paramL_MATRIX);

  public static final native void L_Matrix_SetM11(long paramLong, L_MATRIX paramL_MATRIX, double paramDouble);

  public static final native double L_Matrix_GetM12(long paramLong, L_MATRIX paramL_MATRIX);

  public static final native void L_Matrix_SetM12(long paramLong, L_MATRIX paramL_MATRIX, double paramDouble);

  public static final native double L_Matrix_GetM21(long paramLong, L_MATRIX paramL_MATRIX);

  public static final native void L_Matrix_SetM21(long paramLong, L_MATRIX paramL_MATRIX, double paramDouble);

  public static final native double L_Matrix_GetM22(long paramLong, L_MATRIX paramL_MATRIX);

  public static final native void L_Matrix_SetM22(long paramLong, L_MATRIX paramL_MATRIX, double paramDouble);

  public static final native double L_Matrix_GetOffsetX(long paramLong, L_MATRIX paramL_MATRIX);

  public static final native void L_Matrix_SetOffsetX(long paramLong, L_MATRIX paramL_MATRIX, double paramDouble);

  public static final native double L_Matrix_GetOffsetY(long paramLong, L_MATRIX paramL_MATRIX);

  public static final native void L_Matrix_SetOffsetY(long paramLong, L_MATRIX paramL_MATRIX, double paramDouble);

  public static final native void L_Matrix_Multiply(long paramLong1, L_MATRIX paramL_MATRIX1, long paramLong2, L_MATRIX paramL_MATRIX2, long paramLong3, L_MATRIX paramL_MATRIX3);

  public static final native void L_Matrix_Append(long paramLong1, L_MATRIX paramL_MATRIX1, long paramLong2, L_MATRIX paramL_MATRIX2);

  public static final native void L_Matrix_Prepend(long paramLong1, L_MATRIX paramL_MATRIX1, long paramLong2, L_MATRIX paramL_MATRIX2);

  public static final native void L_Matrix_Rotate(long paramLong, L_MATRIX paramL_MATRIX, double paramDouble);

  public static final native void L_Matrix_RotatePrepend(long paramLong, L_MATRIX paramL_MATRIX, double paramDouble);

  public static final native void L_Matrix_RotateAt(long paramLong, L_MATRIX paramL_MATRIX, double paramDouble1, double paramDouble2, double paramDouble3);

  public static final native void L_Matrix_RotateAtPrepend(long paramLong, L_MATRIX paramL_MATRIX, double paramDouble1, double paramDouble2, double paramDouble3);

  public static final native void L_Matrix_Scale(long paramLong, L_MATRIX paramL_MATRIX, double paramDouble1, double paramDouble2);

  public static final native void L_Matrix_ScalePrepend(long paramLong, L_MATRIX paramL_MATRIX, double paramDouble1, double paramDouble2);

  public static final native void L_Matrix_ScaleAt(long paramLong, L_MATRIX paramL_MATRIX, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);

  public static final native void L_Matrix_ScaleAtPrepend(long paramLong, L_MATRIX paramL_MATRIX, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);

  public static final native void L_Matrix_Skew(long paramLong, L_MATRIX paramL_MATRIX, double paramDouble1, double paramDouble2);

  public static final native void L_Matrix_SkewPrepend(long paramLong, L_MATRIX paramL_MATRIX, double paramDouble1, double paramDouble2);

  public static final native void L_Matrix_Translate(long paramLong, L_MATRIX paramL_MATRIX, double paramDouble1, double paramDouble2);

  public static final native void L_Matrix_TranslatePrepend(long paramLong, L_MATRIX paramL_MATRIX, double paramDouble1, double paramDouble2);

  public static final native void L_Matrix_TransformPoint(long paramLong1, L_MATRIX paramL_MATRIX, long paramLong2, L_POINTD paramL_POINTD);

  public static final native void L_Matrix_TransformVector(long paramLong1, L_MATRIX paramL_MATRIX, long paramLong2, L_POINTD paramL_POINTD);

  public static final native void L_Matrix_TransformPoints(long paramLong1, L_MATRIX paramL_MATRIX, long paramLong2, L_POINTD paramL_POINTD, long paramLong3);

  public static final native void L_Matrix_TransformRect(long paramLong1, L_MATRIX paramL_MATRIX, long paramLong2, L_RECTD paramL_RECTD);

  public static final native int L_Matrix_Invert(long paramLong, L_MATRIX paramL_MATRIX);

  public static final native int L_Matrix_IsEqual(long paramLong1, L_MATRIX paramL_MATRIX1, long paramLong2, L_MATRIX paramL_MATRIX2);

  public static final native int L_Double_AreClose(double paramDouble1, double paramDouble2);

  public static final native int L_Double_LessThan(double paramDouble1, double paramDouble2);

  public static final native int L_Double_GreaterThan(double paramDouble1, double paramDouble2);

  public static final native int L_Double_LessThanOrClose(double paramDouble1, double paramDouble2);

  public static final native int L_Double_GreaterThanOrClose(double paramDouble1, double paramDouble2);

  public static final native int L_Double_IsOne(double paramDouble);

  public static final native int L_Double_IsZero(double paramDouble);

  public static final native int L_Double_AreClosePoints(long paramLong1, L_POINTD paramL_POINTD1, long paramLong2, L_POINTD paramL_POINTD2);

  public static final native int L_Double_AreCloseSizes(long paramLong1, L_SIZED paramL_SIZED1, long paramLong2, L_SIZED paramL_SIZED2);

  public static final native int L_Double_AreCloseRects(long paramLong1, L_RECTD paramL_RECTD1, long paramLong2, L_RECTD paramL_RECTD2);

  public static final native int L_Double_IsBetweenZeroAndOne(double paramDouble);

  public static final native int L_Double_DoubleToInt(double paramDouble);

  public static final native int L_Double_RectHasNaN(long paramLong, L_RECTD paramL_RECTD);

  public static final native int L_Double_IsNaN(double paramDouble);

  public static final native int L_Double_IsInfinity(double paramDouble);

  public static final native double L_Double_NormalizeAngle(double paramDouble);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.jar
 * Qualified Name:     ltkrn.ltkrnJNI
 * JD-Core Version:    0.6.2
 */