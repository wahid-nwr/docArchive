package leadtools;

public abstract interface ISvgDocument
{
  public abstract long getHandle();

  public abstract void dispose();
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.jar
 * Qualified Name:     leadtools.ISvgDocument
 * JD-Core Version:    0.6.2
 */