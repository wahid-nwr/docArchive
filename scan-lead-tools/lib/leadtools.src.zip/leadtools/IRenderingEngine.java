package leadtools;

public abstract interface IRenderingEngine
{
  public abstract long getHandle();
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.jar
 * Qualified Name:     leadtools.IRenderingEngine
 * JD-Core Version:    0.6.2
 */