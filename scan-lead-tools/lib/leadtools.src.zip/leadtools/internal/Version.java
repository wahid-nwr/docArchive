package leadtools.internal;

public class Version
{
  public static final int MAJOR = 19;
  public static final int MINOR = 0;
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.jar
 * Qualified Name:     leadtools.internal.Version
 * JD-Core Version:    0.6.2
 */