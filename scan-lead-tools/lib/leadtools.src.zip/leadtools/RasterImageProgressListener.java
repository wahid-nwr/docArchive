package leadtools;

public abstract interface RasterImageProgressListener
{
  public abstract void RasterImageProgressAlert(RasterImageProgressEvent paramRasterImageProgressEvent);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.jar
 * Qualified Name:     leadtools.RasterImageProgressListener
 * JD-Core Version:    0.6.2
 */