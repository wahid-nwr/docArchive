package leadtools;

public abstract interface RasterImagePagesChangedListener
{
  public abstract void onImagePagesChanged(RasterImagePagesChangedEvent paramRasterImagePagesChangedEvent);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.jar
 * Qualified Name:     leadtools.RasterImagePagesChangedListener
 * JD-Core Version:    0.6.2
 */