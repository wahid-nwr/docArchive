package leadtools;

public abstract interface RasterCollectionEventListener<T>
{
  public abstract void onRasterCollectionChanged(RasterCollectionEvent<T> paramRasterCollectionEvent);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.jar
 * Qualified Name:     leadtools.RasterCollectionEventListener
 * JD-Core Version:    0.6.2
 */