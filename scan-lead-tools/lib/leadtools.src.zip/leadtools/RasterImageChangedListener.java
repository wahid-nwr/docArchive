package leadtools;

public abstract interface RasterImageChangedListener
{
  public abstract void onImageChangedAlert(RasterImageChangedEvent paramRasterImageChangedEvent);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.jar
 * Qualified Name:     leadtools.RasterImageChangedListener
 * JD-Core Version:    0.6.2
 */