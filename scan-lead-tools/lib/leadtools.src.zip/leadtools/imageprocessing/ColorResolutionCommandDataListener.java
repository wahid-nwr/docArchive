package leadtools.imageprocessing;

public abstract interface ColorResolutionCommandDataListener
{
  public abstract void onData(ColorResolutionCommandDataEvent paramColorResolutionCommandDataEvent);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.jar
 * Qualified Name:     leadtools.imageprocessing.ColorResolutionCommandDataListener
 * JD-Core Version:    0.6.2
 */