/*    */ package leadtools;
/*    */ 
/*    */ public final class RefObject<T>
/*    */ {
/*    */   public T argvalue;
/*    */ 
/*    */   public RefObject(T refarg)
/*    */   {
/* 13 */     this.argvalue = refarg;
/*    */   }
/*    */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.jar
 * Qualified Name:     leadtools.RefObject
 * JD-Core Version:    0.6.2
 */