package leadtools;

public abstract interface AsyncLoadCompletedListener
{
  public abstract void onAsyncLoadCompleted(AsyncCompletedEvent paramAsyncCompletedEvent);
}

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.jar
 * Qualified Name:     leadtools.AsyncLoadCompletedListener
 * JD-Core Version:    0.6.2
 */