/*   */ package leadtools;
/*   */ 
/*   */ public enum LeadStreamAccess
/*   */ {
/* 4 */   READ, 
/* 5 */   WRITE, 
/* 6 */   READ_WRITE;
/*   */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.jar
 * Qualified Name:     leadtools.LeadStreamAccess
 * JD-Core Version:    0.6.2
 */