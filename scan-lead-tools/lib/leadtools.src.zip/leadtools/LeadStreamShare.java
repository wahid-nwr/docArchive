/*   */ package leadtools;
/*   */ 
/*   */ public enum LeadStreamShare
/*   */ {
/* 4 */   NONE, 
/* 5 */   READ, 
/* 6 */   WRITE, 
/* 7 */   READ_WRITE;
/*   */ }

/* Location:           /home/wahid/Downloads/docArchive/scan/lib/leadtools.jar
 * Qualified Name:     leadtools.LeadStreamShare
 * JD-Core Version:    0.6.2
 */